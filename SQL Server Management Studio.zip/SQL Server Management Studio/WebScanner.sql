select * from [WebScannerNasdaq] where symbol='NVDA'
order by [TimeStamp] desc

select * from [WebScannerTradingView] where symbol='NVDA'
order by [TimeStamp] desc
-- truncate table [WebScannerNasdaq]
-- truncate table [WebScannerTradingView]

select symbol, count(*), min(lastSale), max(lastSale), min(volume),max(volume)
from [WebScannerNasdaq]
group by symbol
-- having min(volume)<>max(volume) or min(lastSale)<>max(lastSale)
having min(lastSale)<>max(lastSale)
-- order by 4 desc

select symbol, count(*), min([Close]), max([Close]), min(volume),max(volume), min(Recommend), max(Recommend)
from [WebScannerTradingView]
group by symbol
having min(volume)<>max(volume) or min(Recommend)<>max(Recommend)


