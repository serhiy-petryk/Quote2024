use dbQ2024Tests;
/*
����������, ���� ���� ����������� ������ ��� "[Close]*[Volume]>=50000000", �� ���������� ������ >0.8%/�������� �������� ��� �������,
� ���� ��������� ������ ��� "[Close]*[Volume]<=50000000", �� ���������� ������ >1%/�������� �������� ��� ��������
*/

/* Check base data - OK
select year(h1.date), count(*)
from dbQ2024..HourPolygon5 h1
inner join dbQ2024..HourPolygon5 h2 on h1.Symbol=h2.Symbol and h1.Date=h2.Date and h1.[To]=h2.[Time]
inner join dbQ2024..SymbolsPolygon s on h1.Symbol=s.Symbol and h1.Date between s.Date and isnull(s.[To], '2099-12-31')
inner join (select * from dbQ2024..TradingDays where IsShortened is null) d on h1.Date=d.Date
left join (select x1.*, x2.IsShortened from dbQ2024..DayPolygon x1
			inner join dbQ2024..TradingDays x2 on x1.Date=x2.Date) k on k.Symbol=h1.Symbol and k.Date=d.Prev1
where h1.TradeCount>=500 and h1.[Close]*h1.[Volume]>=5000000 and h1.[close]>=5.0
and h1.Date<='2024-01-01'
and h2.OpenNextDelayInMinutes is not null and h2.[Time] not in ('15:45:00', '12:45:00')
group by year(h1.date) order by 1
-- 2021	1851071
-- 2022	1797052
-- 2023	1638447

select year(date), count(*) from dbQ2024Tests..temp_OpenCloseHourSlice_2024_03 group by year(date) order by 1 -- 5286570
-- 2021	1851071
-- 2022	1797052
-- 2023	1638447
*/

-- Base SQL (no moving average) --
-- drop table temp_OpenCloseHourSlice_2024_03
-- 3:24 min: 5'286'570 rows (h1.TradeCount>=500 and h1.[Close]*h1.[Volume]>=5000000 and h1.[close]>=5.0), 2021-2023year, no Shortened days
-- 5:21 min (with prevDay data): 5'286'570 rows (h1.TradeCount>=500 and h1.[Close]*h1.[Volume]>=5000000 and h1.[close]>=5.0), 2021-2023year, no Shortened days
/*select 
(h1.[Open]-h1.[Close])/(h1.[Open]+h1.[Close]) * 200.0 PrevOC,
(h1.[High]-h1.[Low])/(h1.[High]+h1.[Low]) * 200.0 PrevHL,
(h2.[HighBefore]-h2.[LowBefore])/(h2.[HighBefore]+h2.[LowBefore]) * 200.0 BeforeHL,
(h2.[OpenNext]-h2.[Final])/h2.[OpenNext] * 100.0 ProfitReal,
iif(h2.Final is null, 1,0) NoFinal,
h1.OpenDelayInMinutes OpenDelayInMinutes1,
h2.Final, h2.FinalDelayInMinutes,
(h2.[Open]-h2.[Close])/h2.[Open] * 100.0 Profit,
(h2.[OpenNext]-h2.[Close])/h2.[OpenNext] * 100.0 ProfitNext,
h1.[Close]*h1.[Volume]/1000000.0 Turnover,
--iif(k.Symbol is null, 0.0 ,k.[Close]*k.[Volume]/1000000.0) PrevDayTurnover,
--iif(k.Symbol is null, 0 ,k.TradeCount) PrevDayTradeCount,
format(h2.date, 'yyyy-MM') as Period,
case when h1.[Open]>h1.[Close] then 'Down' else 'Up' end as UpDown,
h1.Symbol, s.Exchange, s.MyType, h1.[Date], h2.[Time] Time2, h2.[To] To2,
h1.HighBefore, h1.LowBefore,
h2.OpenNext, h2.OpenNextDelayInMinutes, h2.HighNext, h2.LowNext,
h2.PrevWma_10, h2.Wma_10, h2.PrevWma_20, h2.Wma_20, h2.PrevWma_30, h2.Wma_30, 
h2.PrevEma_10, h2.Ema_10, h2.PrevEma_20, h2.Ema_20, h2.PrevEma_30, h2.Ema_30, 
h2.PrevEma2_10, h2.Ema2_10, h2.PrevEma2_20, h2.Ema2_20, h2.PrevEma2_30, h2.Ema2_30, 
h2.CloseAtWma_20, h2.CloseAtEma_20, h2.CloseAtEma2_20,
h2.CloseAtWma_30,h2.CloseAtEma_30, h2.CloseAtEma2_30,
k.[Open] PrevDayOpen, k.High PrevDayHigh, k.Low PrevDayLow, k.[Close] PrevDayClose, k.Volume PrevDayVolume,
k.TradeCount PrevDayTradeCount, k.volume/1000000.0 * k.[close] PrevDayTurnover,k.IsShortened PrevDayIsShortened,
h1.[Open] Open1, h1.High High1, h1.Low Low1, h1.[Close] Close1, h1.Volume Volume1, h1.[Count] Count1, h1.TradeCount TradeCount1, h1.volume/1000000.0 * h1.[close] Turnover1,
h2.[Open] Open2, h2.High High2, h2.Low Low2, h2.[Close] Close2, h2.Volume Volume2, h2.[Count] Count2, h2.TradeCount TradeCount2, h2.volume/1000000.0 * h2.[close] Turnover2
into temp_OpenCloseHourSlice_2024_03
from dbQ2024Tests2..HourPolygon h1
inner join dbQ2024Tests2..HourPolygon h2 on h1.Symbol=h2.Symbol and h1.Date=h2.Date and h1.[To]=h2.[Time]
inner join dbQ2024..SymbolsPolygon s on h1.Symbol=s.Symbol and h1.Date between s.Date and isnull(s.[To], '2099-12-31')
inner join (select * from dbQ2024..TradingDays where IsShortened is null) d on h1.Date=d.Date
left join (select x1.*, x2.IsShortened from dbQ2024..DayPolygon x1
			inner join dbQ2024..TradingDays x2 on x1.Date=x2.Date) k on k.Symbol=h1.Symbol and k.Date=d.Prev1
where h1.TradeCount>=500 and h1.[Close]*h1.[Volume]>=5000000 and h1.[close]>=5.0
and h1.Date<='2024-01-01'
and h2.OpenNextDelayInMinutes is not null and h2.[Time] not in ('15:45:00', '12:45:00')*/

-- select * from temp_OpenCloseHourSlice_2024_03 where PrevDayOpen is null

-- select * from DbQ2024..HourPolygon where time='09:30:00'
/* Original to compare
;with CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY a.Date, a.[Time2] ORDER BY a.PrevHL desc), a.*
	   FROM temp_OpenCloseHourSlice_2024_03 a
	   -- inner join dbQ2024..TradingDays d on a.Date=d.Date
	   inner join (select * from dbQ2024Minute..MinutePolygonLog where RowStatus in (2,5)
	   and [Close]*[Volume]>=50000000 AND TradeCount>=5000 ) b
	   on a.Symbol=b.Symbol and b.Date=a.Date
	   where year(a.Date)=2023
 	   and a.TradeCount1>=1000
	   and a.Close1>=5.0
	   and a.Turnover1 between 5 and 30
	   -- and TradeCount1>2000
	   -- and PrevWma_20<Wma_20
	   -- and OpenNext>Open2
	   -- and Open2>Wma_20
	   and a.PrevHL>7 -- PrevHL>7 = 0.86 for 1420 rows
	   and a.UpDown='Up'
	   -- and PrevOC>3 -- PrevOC<=-4.7 = 0.83 for 1380 rows
	   and a.OpenNextDelayInMinutes<3
	   -- and Close1 between 5 and 100
    )
    SELECT CAST('0:0:0' as Time(0)) Time,
		avg(ProfitReal) ProfitReal, avg(ProfitNext) ProfitNext, sum(NoFinal) NoFinal,
		Avg(PrevHL) AvgPrevHL, Avg(PrevOC) AvgPrevOC, count(*) Recs, min(TradeCount2) MinTradeCount2,
		Avg(Volume1/TradeCount1) OneTradeShares, Avg(Volume1/TradeCount1*Close1) OneTradeValue
	FROM CTE WHERE RN <=5
	UNION
    SELECT Time2,
		avg(ProfitReal) ProfitReal, avg(ProfitNext) ProfitNext, sum(NoFinal) NoFinal,
		Avg(PrevHL) AvgPrevHL, Avg(PrevOC) AvgPrevOC, count(*) Recs, min(TradeCount2) MinTradeCount2,
		Avg(Volume1/TradeCount1) OneTradeShares, Avg(Volume1/TradeCount1*Close1) OneTradeValue
	FROM CTE WHERE RN <=5
	group by [Time2]
*/
/*;with CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY a.Date, a.[Time2] ORDER BY a.PrevHL DESC ), a.*,
	   iif(high2>(open2+0.005), -0.01, open2-close2)/open2*100 SellProfit,
	   iif(high2>(open2+0.005), 0,1) SellWins,
	   iif(low2<(open2-0.005), -0.01, close2-open2)/open2*100 BuyProfit,
	   iif(low2<(open2-0.005), 0,1) BuyWins,
-- 	   iif(high2>(open2+0.005), -0.01, open2-CloseAtWma_20)/open2*100 SellProfitWma20
	   (open2-isnull(CloseAtWma_20,close2))/open2*100 SellProfitWma20

	   FROM temp_OpenCloseHourSlice_2024_03 a
	   where year(a.Date)=2023
	   and a.Close1>=5.0
	   and PrevDayOpen is not null
	   and a.Count1 >= iif(Time2='10:00:00', 20-OpenDelayInMinutes1,50)
 	   -- and a.TradeCount1>=500
-- 	   and (a.PrevDayTurnover>=50 and a.PrevDayTradeCount>=5000)
	   -- and a.Turnover1 between 5 and 50
	   -- and a.Turnover1<0.3*b.Turnover
	   --and a.TradeCount1>0.5*a.PrevDayTradeCount

	   -- and TradeCount1>5000
	   and PrevWma_20>Wma_20
	   -- and OpenNext<Open2
	   -- and Open2<=Close1
	   -- and Open2<Wma_20
	   and a.PrevHL>5 -- PrevHL>7 = 0.86 for 1420 rows
	   and a.UpDown='Down'
	   -- and PrevOC>3 -- PrevOC<=-4.7 = 0.83 for 1380 rows
	   -- and a.OpenNextDelayInMinutes<2
	   -- and Close1 between 5 and 100
    )
	--select * from cte where RN<=5 -- and NoFinal=1;
    SELECT '--' "--", '00:00:00',-- CAST('0:0:0' as Time(0)) Time,
		ROUND(avg(ProfitReal),4) ProfitReal,
		ROUND(avg(SellProfit),4) SellProfit,
		sum(SellWins) SellWins,
		ROUND(avg(SellProfitWma20),4) SellProfitWma20,
		ROUND(avg(BuyProfit),4) BuyProfit,
		sum(BuyWins) BuyWins,
		ROUND(avg(ProfitNext),4) ProfitNext, sum(NoFinal) NoFinal,
		ROUND(Avg(PrevHL),4) AvgPrevHL, ROUND(Avg(PrevOC),4) AvgPrevOC,
		count(*) Recs, min(TradeCount2) MinTradeCount2,
		ROUND(Avg(Volume1/TradeCount1),1) OneTradeShares, ROUND(Avg(Volume1/TradeCount1*Close1),1) OneTradeValue
	FROM CTE WHERE RN <=5
	UNION
    SELECT '--' "--", Time2,
		ROUND(avg(ProfitReal),4) ProfitReal,
		ROUND(avg(SellProfit),4) SellProfit,
		sum(SellWins) SellWins,
		ROUND(avg(SellProfitWma20),4) SellProfitWma20,
		ROUND(avg(BuyProfit),4) BuyProfit,
		sum(BuyWins) BuyWins,
		ROUND(avg(ProfitNext),4) ProfitNext, sum(NoFinal) NoFinal,
		ROUND(Avg(PrevHL),4) AvgPrevHL, ROUND(Avg(PrevOC),4) AvgPrevOC,
		count(*) Recs, min(TradeCount2) MinTradeCount2,
		ROUND(Avg(Volume1/TradeCount1),1) OneTradeShares, ROUND(Avg(Volume1/TradeCount1*Close1),1) OneTradeValue
	FROM CTE WHERE RN <=5
	group by Time2

--2023 year
-- >=50, Up (CurrentDay): -0.78/1499 rows 
-- <=50, Up (CurrentDay): +1.34/1096 rows 
-- >=50, Up (PrevDay): +0.27/798 rows 
-- <=50, Up (PrevDay): -0.01/1345 rows 
-- 0.4/3662 rows

-- all rows + inner join prevDay of dayPolygon: 0.2465/7440 rows
-- a.Count1 >= iif(Time2='10:00:00', 25-OpenDelayInMinutes1,55): 0.1236/7440
-- a.Count1 >= iif(Time2='10:00:00', 20-OpenDelayInMinutes1,50): 0.1783/7440

-- all rows + Turnover prevDay >=50: 0.1819/7440 rows
-- a.PrevDayTurnover<=50 or a.PrevDayTradeCount<5000: 0.07/7440 rows
 
-- 0.1078 6736 all rows + inner join prevDay of dayPolygon: 0.241/7440 rows */

/*-- DOWN (!!! PrevEma_10>=Ema_10*1.002 (2061 rows): 0.60% (stop-1%), 0.72 (stop-0.2$))
;with CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY a.Date, a.[Time2] ORDER BY a.PrevHL DESC ), 
--       SELECT RN = ROW_NUMBER() OVER (PARTITION BY a.Date, a.[Time2] ORDER BY a.BeforeHL DESC ),
--       SELECT RN = ROW_NUMBER() OVER (PARTITION BY a.Date, a.[Time2] ORDER BY a.PrevEma_10/a.Ema_10 DESC ),
	   a.High1 - (a.High1-a.Low1)/3 NearHigh,
	   a.Low1 + (a.High1-a.Low1)/3 NearLow,
	   iif(high2>(open2*1.01-0.005), -open2*0.01-0.005, open2-close2)/open2*100 SellProfitPerc1,
	   iif(highNext>(openNext*1.01-0.005), -openNext*0.01-0.005, openNext-final)/openNext*100 SellProfitPerc1N,
	   iif(iif(high2>(open2*1.01-0.005), -open2*0.01-0.005, open2-close2)>0,1,0) SellWinsPerc1,
	   iif(iif(highNext>(openNext*1.01-0.005), -openNext*0.01-0.005, openNext-final)>0,1,0) SellWinsPerc1N,
	   iif(high2>(open2+0.005), -0.01, open2-close2)/open2*100 SellProfit1,
	   iif(high2>(open2+0.005), 0,1) SellWins1,
	   iif(high2>(open2+0.025), -0.03, open2-close2)/open2*100 SellProfit3,
	   iif(high2>(open2+0.025), 0,1) SellWins3,
	   iif(high2>(open2+0.095), -0.1, open2-close2)/open2*100 SellProfit10,
	   iif(high2>(open2+0.095), 0,1) SellWins10,
	   iif(high2>(open2+0.195), -0.2, open2-close2)/open2*100 SellProfit20,
	   iif(high2>(open2+0.195), -0.2, open2-Final)/open2*100 SellProfit20_Final,
	   iif(highNext>(openNext+0.195), -0.2, openNext-Final)/openNext*100 SellProfit20N,
	   iif(iif(high2>(open2+0.195), -0.2, open2-close2)>0, 1,0) SellWins20,
	   iif(iif(highNext>(openNext+0.195), -0.2, openNext-final)>0, 1,0) SellWins20N,
	   iif(low2<(open2-0.005), -0.01, close2-open2)/open2*100 BuyProfit1,
	   iif(low2<(open2-0.005), 0,1) BuyWins1,
	   a.*
	   FROM temp_OpenCloseHourSlice_2024_03 a
	   where year(a.Date)=2023
	   and a.Close1>=5.0
	   and PrevDayOpen is not null
	   and a.Count1 >= iif(Time2='10:00:00', 20-OpenDelayInMinutes1,50)
	   -- and a.Open2<(a.Low1 + (a.High1-a.Low1)/5)

 	   -- and a.TradeCount1>=500
-- 	   and (a.PrevDayTurnover>=50 and a.PrevDayTradeCount>=5000)
	   -- and a.Turnover1 between 5 and 50
	   -- and a.Turnover1<0.3*b.Turnover
	   --and a.TradeCount1>0.5*a.PrevDayTradeCount
	   -- and PrevDayVolume/5<Volume1
	   -- and PrevEma_10>Ema_10*1.001 and Open2>Low1*1.01
	   -- and TradeCount1>5000
	   -- and PrevWma_20>Wma_20*1.0025
	   -- and PrevWma_10>Wma_10*1.002
	   -- and PrevEma_10>Ema_10*1.002 -- !!! k=1.002 (2061 rows): 0.60% (stop-1%), 0.72 (stop-0.2$)
	   and PrevEma_10>=Ema_10*1.002 -- !!! k=1.002 (2061 rows): 0.60% (stop-1%), 0.72 (stop-0.2$)
	   -- and PrevEma_10>=Ema_10*1.0015 -- !!! k=1.0015 (3184 rows): 0.44% (stop-1%), 0.52 (stop-0.2$)
	   -- and OpenNext between 0.9993*Open2 and 1.01*Open2
	   -- and PrevEma_20>Ema_20*1.002
	   -- and PrevEma2_10>Ema2_10*1.001
	   -- and Wma_20>Wma_10 and Wma_30>Wma_20
	   -- and PrevWma_20>Wma_20*1.001
	   --and PrevWma_30>Wma_30*1.001
	   -- and PrevWma_30>Wma_30*1.001
	   -- and PrevEma_20>Ema_20*1.001
	   -- and PrevEma_30>Ema_30*1.001
	   -- and OpenNext>Open2
	   -- and Open2<=Close1
	   -- and Open2<Wma_20
	   -- and a.PrevHL>5 -- PrevHL>7 = 0.86 for 1420 rows
	   -- and a.UpDown='Down'
	   -- and PrevOC>3 -- PrevOC<=-4.7 = 0.83 for 1380 rows
	   and a.OpenNextDelayInMinutes<2
	   -- and Close1 between 5 and 100
    )
	/*select symbol, date, time2, PrevEma_10, Ema_10, open2, high2, low2, close2,
	Final, OpenNext, HighNext, LowNext, SellProfit20, SellProfit20N, SellWins20, SellWins20N
	from cte where RN<=5 order by date,time2, symbol;*/

    SELECT '--' "--", '00:00:00' Time,-- CAST('0:0:0' as Time(0)) Time,
		count(*) Recs,
		ROUND(avg(ProfitReal),4) ProfitReal,
		ROUND(avg(SellProfit20_Final),4) SellProfit20_Final,
		ROUND(avg(SellProfit20),4) SellProfit20,
		ROUND(avg(SellProfit20N),4) SellProfit20N,
	--	sum(SellWins20) SellWins20,
		ROUND(avg(SellProfitPerc1),4) SellProfitPerc1,
		ROUND(avg(SellProfitPerc1N),4) SellProfitPerc1N,
		sum(SellWinsPerc1) SellWinsPerc1,
		sum(SellWinsPerc1N) SellWinsPerc1N,
		ROUND(avg(SellProfit1),4) SellProfit1,
--		sum(SellWins1) SellWins1,
		ROUND(avg(SellProfit3),4) SellProfit3,
--		sum(SellWins3) SellWins3,
		ROUND(avg(SellProfit10),4) SellProfit10,
--		sum(SellWins10) SellWins10,
		ROUND(avg(BuyProfit1),4) BuyProfit1,
		--sum(BuyWins1) BuyWins1,
		ROUND(avg(ProfitNext),4) ProfitNext,
		sum(NoFinal) NoFinal,
		ROUND(Avg(PrevHL),4) AvgPrevHL, ROUND(Avg(PrevOC),4) AvgPrevOC,
		min(TradeCount2) MinTradeCount2,
		ROUND(Avg(Volume1/TradeCount1),1) OneTradeShares, ROUND(Avg(Volume1/TradeCount1*Close1),1) OneTradeValue
	FROM CTE WHERE RN <=5
	UNION
    SELECT '--' "--", Time2,
		count(*) Recs,
		ROUND(avg(ProfitReal),4) ProfitReal,
		ROUND(avg(SellProfit20_Final),4) SellProfit20_Final,
		ROUND(avg(SellProfit20),4) SellProfit20,
		ROUND(avg(SellProfit20N),4) SellProfit20N,
	--	sum(SellWins20) SellWins20,
		ROUND(avg(SellProfitPerc1),4) SellProfitPerc1,
		ROUND(avg(SellProfitPerc1N),4) SellProfitPerc1N,
		sum(SellWinsPerc1) SellWinsPerc1,
		sum(SellWinsPerc1N) SellWinsPerc1N,
		ROUND(avg(SellProfit1),4) SellProfit1,
--		sum(SellWins1) SellWins1,
		ROUND(avg(SellProfit3),4) SellProfit3,
--		sum(SellWins3) SellWins3,
		ROUND(avg(SellProfit10),4) SellProfit10,
--		sum(SellWins10) SellWins10,
		ROUND(avg(BuyProfit1),4) BuyProfit1,
		--sum(BuyWins1) BuyWins1,
		ROUND(avg(ProfitNext),4) ProfitNext,
		sum(NoFinal) NoFinal,
		ROUND(Avg(PrevHL),4) AvgPrevHL, ROUND(Avg(PrevOC),4) AvgPrevOC,
		min(TradeCount2) MinTradeCount2,
		ROUND(Avg(Volume1/TradeCount1),1) OneTradeShares, ROUND(Avg(Volume1/TradeCount1*Close1),1) OneTradeValue
	FROM CTE WHERE RN <=5
	group by Time2
--	(No column name)	Recs	ProfitReal	SellProfit1	SellWins1	SellProfit3	SellWins3	SellProfit10	SellWins10	BuyProfit1	BuyWins1	ProfitNext	NoFinal	AvgPrevHL	AvgPrevOC	MinTradeCount2	OneTradeShares	OneTradeValue
--	00:00:00	7440	0,1748	0,0485	229	0,006	510	-0,0203	1554	0,0557	244	0,1846	3	11,4129	-0,4053	208	167	2652,1
--	10:00:00	1240	-0,0018	0,0407	32	0,0169	62	-0,0217	175	0,0461	30	0,021	0	16,5494	-0,035	489	159,7	2537,2
--	11:00:00	1240	0,1957	0,0481	30	-0,037	63	-0,0934	211	0,0365	34	0,1923	0	14,1953	-0,5201	322	158,3	2261,7
--	12:00:00	1240	0,0911	0,0378	41	-0,005	90	-0,1182	266	0,0643	49	0,1162	1	10,9931	-0,378	282	164,5	2529,3
--	13:00:00	1240	0,5238	0,0695	46	0,0645	109	0,0802	300	0,0081	35	0,5297	0	9,5614	-0,691	208	168,5	2711,9
--	14:00:00	1240	-0,0028	0,0268	41	-0,0498	84	-0,11	268	0,1377	47	-0,0093	0	8,4596	-0,2202	399	178,5	2873,8
--	15:00:00	1240	0,243	0,0677	39	0,0462	102	0,1414	334	0,0413	49	0,258	2	8,7184	-0,5872	474	172,5	2998,5

-- !!! PrevWma_20>Wma_20*1.003 (!!! SellProfit10=0.4751) ||| PrevWma_20>Wma_20*1.0025 (SellProfit=0.5182)
-- !!! 900 rows PrevWma_20>Wma_20*1.0025 (SellProfit10=0.5182, SellProfit20=0.7932, SellProfitPerc1=0.5955)
--	Time	Recs	ProfitReal	SellProfitPerc1	SellWinsPerc1	SellProfit1	SellWins1	SellProfit3	SellWins3	SellProfit10	SellWins10	SellProfit20	SellWins20	BuyProfit1	BuyWins1	ProfitNext	NoFinal	AvgPrevHL	AvgPrevOC	MinTradeCount2	OneTradeShares	OneTradeValue
--	00:00:00	900	0,7312	0,5955	212	0,19	41	0,2215	78	0,5182	189	0,7932	278	-0,0022	10	0,7727	0	16,6983	5,3776	658	154,8	2436,1
--	10:00:00	442	-0,0157	0,6987	120	0,257	24	0,3093	45	0,4961	102	0,7084	140	0,0298	6	0,034	0	14,4524	6,7258	753	155,7	2846,9
--	11:00:00	140	1,7554	0,5687	31	-0,0112	3	-0,0087	9	0,538	28	0,8749	46	-0,0256	1	1,8225	0	18,8443	5,1123	716	148,3	1870,6
--	12:00:00	82	1,6054	0,1016	15	0,087	3	0,0067	6	0,1882	14	1,315	27	0,1107	2	1,6092	0	19,8092	5,0181	658	150,2	1880,8
--	13:00:00	94	2,0782	0,9573	20	0,3401	6	0,6306	10	1,0049	18	1,6539	29	-0,0717	1	2,119	0	19,1227	1,3315	777	150,3	2113,3
--	14:00:00	71	1,116	0,302	12	0,3866	5	0,2181	5	0,3422	11	-0,0744	14	-0,0882	0	1,0299	0	17,2452	4,431	913	151,1	2365,9
--	15:00:00	71	0,1835	0,3913	14	-0,1072	0	-0,1617	3	0,5298	16	0,2856	22	-0,1072	0	0,2957	0	19,0983	4,2265	1318	176,8	2132,1
-- !!! 2994 rows: PrevWma_20>Wma_20*1.001 and PrevWma_30>Wma_30*1.001 (SellProfit10=0.2473, SellProfit20=0.3262, SEllProfitPerc1=0.263)
--	00:00:00	900	0,7312	0,5955	212	0,19	41	0,2215	78	0,5182	189	0,7932	278	-0,0022	10	0,7727	0	16,6983	5,3776	658	154,8	2436,1
--	10:00:00	442	-0,0157	0,6987	120	0,257	24	0,3093	45	0,4961	102	0,7084	140	0,0298	6	0,034	0	14,4524	6,7258	753	155,7	2846,9
--	11:00:00	140	1,7554	0,5687	31	-0,0112	3	-0,0087	9	0,538	28	0,8749	46	-0,0256	1	1,8225	0	18,8443	5,1123	716	148,3	1870,6
--	12:00:00	82	1,6054	0,1016	15	0,087	3	0,0067	6	0,1882	14	1,315	27	0,1107	2	1,6092	0	19,8092	5,0181	658	150,2	1880,8
--	13:00:00	94	2,0782	0,9573	20	0,3401	6	0,6306	10	1,0049	18	1,6539	29	-0,0717	1	2,119	0	19,1227	1,3315	777	150,3	2113,3
--	14:00:00	71	1,116	0,302	12	0,3866	5	0,2181	5	0,3422	11	-0,0744	14	-0,0882	0	1,0299	0	17,2452	4,431	913	151,1	2365,9
--	15:00:00	71	0,1835	0,3913	14	-0,1072	0	-0,1617	3	0,5298	16	0,2856	22	-0,1072	0	0,2957	0	19,0983	4,2265	1318	176,8	2132,1
*/

-- UP (!!! PrevEma_10*1.002<=Ema_10 (2160 rows): 0.40% (stop-1%), 0.44 (stop-0.2$))
/*;with CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY a.Date, a.[Time2] ORDER BY a.PrevHL DESC ), 
--       SELECT RN = ROW_NUMBER() OVER (PARTITION BY a.Date, a.[Time2] ORDER BY a.BeforeHL DESC ),
--       SELECT RN = ROW_NUMBER() OVER (PARTITION BY a.Date, a.[Time2] ORDER BY a.PrevEma_10/a.Ema_10 DESC ),
	   a.High1 - (a.High1-a.Low1)/3 NearHigh,
	   a.Low1 + (a.High1-a.Low1)/3 NearLow,
--	   iif(high2>(open2*1.01-0.005), -open2*0.01-0.005, open2-close2)/open2*100 SellProfitPerc1,
	   iif(low2<(open2*0.99+0.005), -open2*0.01-0.005, close2-open2)/open2*100 BuyProfitPerc1,

	   iif(highNext>(openNext*1.01-0.005), -openNext*0.01-0.005, openNext-final)/openNext*100 SellProfitPerc1N,
	   iif(iif(high2>(open2*1.01-0.005), -open2*0.01-0.005, open2-close2)>0,1,0) SellWinsPerc1,
	   iif(iif(highNext>(openNext*1.01-0.005), -openNext*0.01-0.005, openNext-final)>0,1,0) SellWinsPerc1N,
	   iif(high2>(open2+0.005), -0.01, open2-close2)/open2*100 SellProfit1,
	   iif(high2>(open2+0.005), 0,1) SellWins1,
	   iif(high2>(open2+0.025), -0.03, open2-close2)/open2*100 SellProfit3,
	   iif(high2>(open2+0.025), 0,1) SellWins3,
	   iif(high2>(open2+0.095), -0.1, open2-close2)/open2*100 SellProfit10,
	   iif(high2>(open2+0.095), 0,1) SellWins10,
--	   iif(high2>(open2+0.195), -0.2, open2-close2)/open2*100 SellProfit20,
	   iif(low2<(open2-0.195), -0.2, close2-open2)/open2*100 BuyProfit20,

	   iif(high2>(open2+0.195), -0.2, open2-Final)/open2*100 SellProfit20_Final,
	   iif(highNext>(openNext+0.195), -0.2, openNext-Final)/openNext*100 SellProfit20N,
	   iif(iif(high2>(open2+0.195), -0.2, open2-close2)>0, 1,0) SellWins20,
	   iif(iif(highNext>(openNext+0.195), -0.2, openNext-final)>0, 1,0) SellWins20N,
	   iif(low2<(open2-0.005), -0.01, close2-open2)/open2*100 BuyProfit1,
	   iif(low2<(open2-0.005), 0,1) BuyWins1,
	   a.*
	   FROM temp_OpenCloseHourSlice_2024_03 a
	   where year(a.Date)=2023
	   and a.Close1>=5.0
	   and PrevDayOpen is not null
	   and a.Count1 >= iif(Time2='10:00:00', 20-OpenDelayInMinutes1,50)
	   -- and a.Open2<(a.Low1 + (a.High1-a.Low1)/5)

 	   -- and a.TradeCount1>=500
-- 	   and (a.PrevDayTurnover>=50 and a.PrevDayTradeCount>=5000)
	   -- and a.Turnover1 between 5 and 50
	   -- and a.Turnover1<0.3*b.Turnover
	   --and a.TradeCount1>0.5*a.PrevDayTradeCount
	   -- and PrevDayVolume/5<Volume1
	   -- and PrevEma_10>Ema_10*1.001 and Open2>Low1*1.01
	   -- and TradeCount1>5000
	   -- and PrevWma_20>Wma_20*1.0025
	   -- and PrevWma_10>Wma_10*1.002
	   and PrevEma_10*1.002<=Ema_10 -- !!! k=1.002 (2160 rows): 0.40% (stop-1%), 0.44 (stop-0.2$)
	   -- and OpenNext between 0.9993*Open2 and 1.01*Open2
	   -- and PrevEma_20>Ema_20*1.002
	   -- and PrevEma2_10>Ema2_10*1.001
	   -- and Wma_20>Wma_10 and Wma_30>Wma_20
	   -- and PrevWma_20>Wma_20*1.001
	   --and PrevWma_30>Wma_30*1.001
	   -- and PrevWma_30>Wma_30*1.001
	   -- and PrevEma_20>Ema_20*1.001
	   -- and PrevEma_30>Ema_30*1.001
	   -- and OpenNext>Open2
	   -- and Open2<=Close1
	   -- and Open2<Wma_20
	   -- and a.PrevHL>5 -- PrevHL>7 = 0.86 for 1420 rows
	   -- and a.UpDown='Down'
	   -- and PrevOC>3 -- PrevOC<=-4.7 = 0.83 for 1380 rows
	   and a.OpenNextDelayInMinutes<2
	   -- and Close1 between 5 and 100
    )
	/*select symbol, date, time2, PrevEma_10, Ema_10, open2, high2, low2, close2,
	Final, OpenNext, HighNext, LowNext, BuyProfitPerc1, BuyProfit20, SellProfit20N, SellWins20, SellWins20N
	from cte where RN<=5 order by date,time2, symbol;*/

    SELECT '--' "--", '00:00:00' Time,-- CAST('0:0:0' as Time(0)) Time,
		count(*) Recs,
		ROUND(avg(BuyProfit20),4) BuyProfit20,
		ROUND(avg(BuyProfitPerc1),4) BuyProfitPerc1,

		ROUND(avg(ProfitReal),4) ProfitReal,
		ROUND(avg(SellProfit20_Final),4) SellProfit20_Final,
--		ROUND(avg(SellProfit20),4) SellProfit20,
		ROUND(avg(SellProfit20N),4) SellProfit20N,
	--	sum(SellWins20) SellWins20,
	--	ROUND(avg(SellProfitPerc1),4) SellProfitPerc1,
		ROUND(avg(SellProfitPerc1N),4) SellProfitPerc1N,
		sum(SellWinsPerc1) SellWinsPerc1,
		sum(SellWinsPerc1N) SellWinsPerc1N,
		ROUND(avg(SellProfit1),4) SellProfit1,
--		sum(SellWins1) SellWins1,
		ROUND(avg(SellProfit3),4) SellProfit3,
--		sum(SellWins3) SellWins3,
		ROUND(avg(SellProfit10),4) SellProfit10,
--		sum(SellWins10) SellWins10,
		ROUND(avg(BuyProfit1),4) BuyProfit1,
		--sum(BuyWins1) BuyWins1,
		ROUND(avg(ProfitNext),4) ProfitNext,
		sum(NoFinal) NoFinal,
		ROUND(Avg(PrevHL),4) AvgPrevHL, ROUND(Avg(PrevOC),4) AvgPrevOC,
		min(TradeCount2) MinTradeCount2,
		ROUND(Avg(Volume1/TradeCount1),1) OneTradeShares, ROUND(Avg(Volume1/TradeCount1*Close1),1) OneTradeValue
	FROM CTE WHERE RN <=5
	UNION
    SELECT '--' "--", Time2,
		count(*) Recs,
		ROUND(avg(BuyProfit20),4) BuyProfit20,
		ROUND(avg(BuyProfitPerc1),4) BuyProfitPerc1,

		ROUND(avg(ProfitReal),4) ProfitReal,
		ROUND(avg(SellProfit20_Final),4) SellProfit20_Final,
--		ROUND(avg(SellProfit20),4) SellProfit20,
		ROUND(avg(SellProfit20N),4) SellProfit20N,
	--	sum(SellWins20) SellWins20,
	--	ROUND(avg(SellProfitPerc1),4) SellProfitPerc1,
		ROUND(avg(SellProfitPerc1N),4) SellProfitPerc1N,
		sum(SellWinsPerc1) SellWinsPerc1,
		sum(SellWinsPerc1N) SellWinsPerc1N,
		ROUND(avg(SellProfit1),4) SellProfit1,
--		sum(SellWins1) SellWins1,
		ROUND(avg(SellProfit3),4) SellProfit3,
--		sum(SellWins3) SellWins3,
		ROUND(avg(SellProfit10),4) SellProfit10,
--		sum(SellWins10) SellWins10,
		ROUND(avg(BuyProfit1),4) BuyProfit1,
		--sum(BuyWins1) BuyWins1,
		ROUND(avg(ProfitNext),4) ProfitNext,
		sum(NoFinal) NoFinal,
		ROUND(Avg(PrevHL),4) AvgPrevHL, ROUND(Avg(PrevOC),4) AvgPrevOC,
		min(TradeCount2) MinTradeCount2,
		ROUND(Avg(Volume1/TradeCount1),1) OneTradeShares, ROUND(Avg(Volume1/TradeCount1*Close1),1) OneTradeValue
	FROM CTE WHERE RN <=5
	group by Time2

-- select PrevEma_10, Ema_10, * from temp_OpenCloseHourSlice_2024_03 where PrevEma_10*1.002<=Ema_10*/

-- =============================
-- Define previous day turnover, tradeCount
-- ============================
-- DOWN (!!! PrevEma_10>=Ema_10*1.002 (2061 rows): 0.60% (stop-1%), 0.72 (stop-0.2$))
;with CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY a.Date, a.[Time2] ORDER BY a.PrevHL DESC ), 
--       SELECT RN = ROW_NUMBER() OVER (PARTITION BY a.Date, a.[Time2] ORDER BY a.BeforeHL DESC ),
--       SELECT RN = ROW_NUMBER() OVER (PARTITION BY a.Date, a.[Time2] ORDER BY a.PrevEma_10/a.Ema_10 DESC ),
--	   c.TradeCount PrevDayTradeCount, 
	   a.High1 - (a.High1-a.Low1)/3 NearHigh,
	   a.Low1 + (a.High1-a.Low1)/3 NearLow,
	   iif(high2>(open2*1.01-0.005), -open2*0.01-0.005, open2-close2)/open2*100 SellProfitPerc1,
	   iif(highNext>(openNext*1.01-0.005), -openNext*0.01-0.005, openNext-final)/openNext*100 SellProfitPerc1N,
	   iif(iif(high2>(open2*1.01-0.005), -open2*0.01-0.005, open2-close2)>0,1,0) SellWinsPerc1,
	   iif(iif(highNext>(openNext*1.01-0.005), -openNext*0.01-0.005, openNext-final)>0,1,0) SellWinsPerc1N,
	   iif(high2>(open2+0.195), -0.2, open2-close2)/open2*100 SellProfit20,
	   iif(high2>(open2+0.195), -0.2, open2-Final)/open2*100 SellProfit20_Final,
	   iif(highNext>(openNext+0.195), -0.2, openNext-Final)/openNext*100 SellProfit20N,
	   iif(iif(high2>(open2+0.195), -0.2, open2-close2)>0, 1,0) SellWins20,
	   iif(iif(highNext>(openNext+0.195), -0.2, openNext-final)>0, 1,0) SellWins20N,
	   iif(low2<(open2-0.005), -0.01, close2-open2)/open2*100 BuyProfit1,
	   iif(low2<(open2-0.005), 0,1) BuyWins1,
	   a.*
	   FROM temp_OpenCloseHourSlice_2024_03 a
	   -- inner join dbQ2024..TradingDays b on a.Date=b.Date
	   -- inner join dbQ2024..DayPolygon c on a.Symbol=c.Symbol and b.Prev2=c.Date
	   where year(a.Date)=2023
	   and a.Close1>=5.0
	   and PrevDayOpen is not null
	   and PrevDayTurnover>=50.0 and PrevDayTradeCount>=10000 
	   and a.Count1 >= iif(Time2='10:00:00', 20-OpenDelayInMinutes1,50)
	   -- and c.Volume*c.[Close]>=50000000 and c.TradeCount>=3000
	   -- and a.MyType like 'ET%'
	   -- and a.MyType in ('CS','ADRC')
	   -- and a.Open2<(a.Low1 + (a.High1-a.Low1)/5)
	   and PrevEma_10>=Ema_10*1.002 -- !!! k=1.002 (2061 rows): 0.60% (stop-1%), 0.72 (stop-0.2$)
	   -- and a.Open2>=(a.High1-a.Low1)*(0.9) + a.Low1
	   -- and a.Open2<=(a.High1-a.Low1)*0.1 + a.Low1
	   -- and a.Low1<a.Open2*0.98
	   -- and a.Open2>Ema_10
	   -- and a.OpenNextDelayInMinutes<2
    )

    SELECT '--' "--", '00:00:00' Time,-- CAST('0:0:0' as Time(0)) Time,
		count(*) Recs,
		ROUND(AVG(PrevDayTurnover),1) AvgPrevDayTurnover, 
		ROUND(AVG(PrevDayTradeCount),0) AvgPrevDayTradeCount, 
		ROUND(avg(ProfitReal),4) ProfitReal,
		ROUND(avg(SellProfit20_Final),4) SellProfit20_Final,
		ROUND(avg(SellProfit20),4) SellProfit20,
		ROUND(avg(SellProfit20N),4) SellProfit20N,
		sum(SellWins20) SellWins20,
		ROUND(avg(SellProfitPerc1),4) SellProfitPerc1,
		ROUND(avg(SellProfitPerc1N),4) SellProfitPerc1N,
		sum(SellWinsPerc1) SellWinsPerc1,
		sum(SellWinsPerc1N) SellWinsPerc1N,
		ROUND(avg(BuyProfit1),4) BuyProfit1,
		--sum(BuyWins1) BuyWins1,
		ROUND(avg(ProfitNext),4) ProfitNext,
		sum(NoFinal) NoFinal,
		ROUND(Avg(PrevHL),4) AvgPrevHL, ROUND(Avg(PrevOC),4) AvgPrevOC,
		min(TradeCount2) MinTradeCount2,
		ROUND(Avg(Volume1/TradeCount1),1) OneTradeShares, ROUND(Avg(Volume1/TradeCount1*Close1),1) OneTradeValue
	FROM CTE WHERE RN <=5
	UNION
    SELECT '--' "--", Time2,
		count(*) Recs,
		ROUND(AVG(PrevDayTurnover),1) AvgPrevDayTurnover, 
		ROUND(AVG(PrevDayTradeCount),0) AvgPrevDayTradeCount, 
		ROUND(avg(ProfitReal),4) ProfitReal,
		ROUND(avg(SellProfit20_Final),4) SellProfit20_Final,
		ROUND(avg(SellProfit20),4) SellProfit20,
		ROUND(avg(SellProfit20N),4) SellProfit20N,
		sum(SellWins20) SellWins20,
		ROUND(avg(SellProfitPerc1),4) SellProfitPerc1,
		ROUND(avg(SellProfitPerc1N),4) SellProfitPerc1N,
		sum(SellWinsPerc1) SellWinsPerc1,
		sum(SellWinsPerc1N) SellWinsPerc1N,
		ROUND(avg(BuyProfit1),4) BuyProfit1,
		--sum(BuyWins1) BuyWins1,
		ROUND(avg(ProfitNext),4) ProfitNext,
		sum(NoFinal) NoFinal,
		ROUND(Avg(PrevHL),4) AvgPrevHL, ROUND(Avg(PrevOC),4) AvgPrevOC,
		min(TradeCount2) MinTradeCount2,
		ROUND(Avg(Volume1/TradeCount1),1) OneTradeShares, ROUND(Avg(Volume1/TradeCount1*Close1),1) OneTradeValue
	FROM CTE WHERE RN <=5
	group by Time2
-- Original (!!! PrevEma_10>=Ema_10*1.002 (2061 rows): 0.60% (stop-1%), 0.72 (stop-0.2$))
--	Time	Recs	ProfitReal	SellProfit20_Final	SellProfit20	SellProfit20N	SellWins20	SellProfitPerc1	SellProfitPerc1N	SellWinsPerc1	SellWinsPerc1N	BuyProfit1	ProfitNext	NoFinal	AvgPrevHL	AvgPrevOC	MinTradeCount2	OneTradeShares	OneTradeValue
--	00:00:00	2061	0,3771	0,7148	0,7209	0,0291	750	0,5978	0,0801	651	446	-0,0492	0,3973	1	12,1219	2,5653	523	165,6	2880
--	10:00:00	918	0,1011	0,7074	0,7178	0,0911	329	0,6882	0,1437	309	212	-0,0306	0,1245	0	11,2394	3,5233	523	164,4	3321,9
--	11:00:00	422	0,6324	0,7152	0,7233	-0,0203	168	0,6108	-0,046	149	102	-0,0525	0,6418	0	11,3317	2,6281	575	155,9	2536,5
--	12:00:00	217	0,3388	0,6526	0,6748	-0,1132	78	0,2028	-0,1516	60	41	-0,0558	0,3141	0	13,0991	1,6284	658	164,2	2514,8
--	13:00:00	175	1,5772	1,5072	1,4789	0,7209	68	0,9873	0,4459	50	34	-0,0796	1,5802	0	15,2298	0,2084	777	158,8	2261
--	14:00:00	178	0,3076	0,2582	0,2539	-0,6873	54	0,4231	-0,1944	47	29	-0,0564	0,2634	0	11,5772	1,827	913	191,8	2904,6
--	15:00:00	151	0,0855	0,4677	0,4717	0,0375	53	0,3344	0,2777	36	28	-0,0996	0,279	1	15,3309	1,5143	641	179,6	2366