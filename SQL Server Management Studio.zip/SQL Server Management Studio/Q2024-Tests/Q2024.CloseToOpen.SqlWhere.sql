-- 2023 year
use dbQ2024Tests;

-- 1,0881963902455	1,0046667277556	0,998805054037607	23200	0,1290323

-- d2.volume/1000000.0 * d2.[close]: 10->21823 rows
-- select avg(K_OpenClose) AverAbsOpenClose, avg(NewK) AvgNewK, avg(PrevK) AvgPrevK, count(*) Recs, min(PrevK) MinPrevK from 
select * from
(SELECT
case when d2.[Open]>d2.[Close] then d2.[Open]/d2.[Close] else d2.[Close]/d2.[Open] end K_OpenClose,
case when d2.[Open]>d2.[Close] then d2.[Close]/d2.[Open] else d2.[Open]/d2.[Close] end K_CloseOpen,
d3.[Open]/d3.[Close] NewK,
d2.[open]/d2.[Close] PrevK, d1.[open]/d1.[Close] Prev2K,
format(d3.date, 'yyyy-MM') as period, case when d2.[Open]>d2.[Close] then 'Down' else 'Up' end as UpDown,
1.0*d2.TradeCount/d1.TradeCount TradeK, d1.Symbol, 
d1.Date Date1, d1.[Open] Open1, d1.High High1, d1.Low Low1, d1.[Close] Close1, d1.Volume Volume1, d1.TradeCount TradeCnt1, d1.volume/1000000.0 * d1.[close] Turnover1,
d2.Date Date2, d2.[Open] Open2, d2.High High2, d2.Low Low2, d2.[Close] Close2, d2.Volume Volume2, d2.TradeCount TradeCnt2, d2.volume/1000000.0 * d2.[close] Turnover2,
d3.Date Date3, d3.[Open] Open3, d3.High High3, d3.Low Low3, d3.[Close] Close3, d3.Volume Volume3, d3.TradeCount TradeCnt3, d3.volume/1000000.0 * d3.[close] Turnover3
-- into temp_OpenClose
FROM dbQ2024..DayPolygon d1
inner join dbQ2024..TradingDays b on d1.Date=b.Date
left join dbQ2024..TradingShortened c1 on b.Next1=c1.Date
left join dbQ2024..TradingShortened c2 on b.Next2=c2.Date
inner join dbQ2024..DayPolygon d2 on d1.Symbol=d2.Symbol and b.Next1=d2.Date
inner join dbQ2024..DayPolygon d3 on d1.Symbol=d3.Symbol and b.Next2=d3.Date
left join dbQ2023Others..Splits s1 on s1.Symbol=d1.Symbol and s1.Date=d1.Date
left join dbQ2023Others..Splits s2 on s2.Symbol=d2.Symbol and s2.Date=d2.Date
left join dbQ2023Others..Splits s3 on s3.Symbol=d3.Symbol and s3.Date=d3.Date
where d1.IsTest is null and d2.tradecount>5000 and d2.[close] >= 5 and d2.volume/1000000.0 * d2.[close]>10
and b.IsShortened is null and c1.Date is null and c2.Date is null
and s1.Symbol is null and s2.Symbol is null and s3.Symbol is null 
and (d2.[Open]/d2.[Close]<0.95 or d2.[Open]/d2.[Close]>1.05)
and d1.Date between '2023-01-01' and '2024-01-01')x
where K_OpenClose>1.05
order by 1 desc

select avg(K_CloseOpen) AverAbsOpenClose, avg(NewK) AvgNewK, avg(PrevK) AvgPrevK, count(*) Recs, min(PrevK) MinPrevK from 
-- select top 100 * from
(SELECT
case when d2.[Open]>d2.[Close] then d2.[Close]/d2.[Open] else d2.[Open]/d2.[Close] end K_CloseOpen,
d3.[Close]/d3.[Open] NewK,
d2.[Close]/d2.[Open] PrevK, d1.[Close]/d1.[Open] Prev2K,
format(d3.date, 'yyyy-MM') as period, case when d2.[Open]>d2.[Close] then 'Down' else 'Up' end as UpDown,
1.0*d2.TradeCount/d1.TradeCount TradeK, d1.Symbol, 
d1.Date Date1, d1.[Open] Open1, d1.High High1, d1.Low Low1, d1.[Close] Close1, d1.Volume Volume1, d1.TradeCount TradeCnt1, d1.volume/1000000.0 * d1.[close] Turnover1,
d2.Date Date2, d2.[Open] Open2, d2.High High2, d2.Low Low2, d2.[Close] Close2, d2.Volume Volume2, d2.TradeCount TradeCnt2, d2.volume/1000000.0 * d2.[close] Turnover2,
d3.Date Date3, d3.[Open] Open3, d3.High High3, d3.Low Low3, d3.[Close] Close3, d3.Volume Volume3, d3.TradeCount TradeCnt3, d3.volume/1000000.0 * d3.[close] Turnover3
-- into temp_CloseOpen
FROM dbQ2024..DayPolygon d1
inner join dbQ2024..TradingDays b on d1.Date=b.Date
left join dbQ2024..TradingShortened c1 on b.Next1=c1.Date
left join dbQ2024..TradingShortened c2 on b.Next2=c2.Date
inner join dbQ2024..DayPolygon d2 on d1.Symbol=d2.Symbol and b.Next1=d2.Date
inner join dbQ2024..DayPolygon d3 on d1.Symbol=d3.Symbol and b.Next2=d3.Date
left join dbQ2023Others..Splits s1 on s1.Symbol=d1.Symbol and s1.Date=d1.Date
left join dbQ2023Others..Splits s2 on s2.Symbol=d2.Symbol and s2.Date=d2.Date
left join dbQ2023Others..Splits s3 on s3.Symbol=d3.Symbol and s3.Date=d3.Date
where d1.IsTest is null and d2.tradecount>5000 and d2.[close] >= 5 and d2.volume/1000000.0 * d2.[close]>10
and b.IsShortened is null and c1.Date is null and c2.Date is null
and s1.Symbol is null and s2.Symbol is null and s3.Symbol is null 
and (d2.[Open]/d2.[Close]<0.95 or d2.[Open]/d2.[Close]>1.05)
and d1.Date between '2023-01-01' and '2024-01-01')x
-- where K_CloseOpen<0.951
-- order by 1

;WITH CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date3 ORDER BY K_OpenClose desc), * FROM dbQ2024Tests..temp_OpenClose where year(date1)=2023 and K_OpenClose between 1.12 and 1.165
    )
	select avg(newK), count(*) from 
    (SELECT *
    FROM    CTE
    WHERE   RN <= 5) x ;

;WITH CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date3 ORDER BY K_OpenClose desc), * FROM dbQ2024Tests..temp_OpenClose_50 where year(date1)=2023
    )
	select avg(newK), count(*) from 
    (SELECT *
    FROM    CTE
    WHERE   RN <= 5) x ;

-- ======  Filter for   ========
-- 21951 row
SELECT *
FROM dbQ2024..DayPolygon d1
inner join dbQ2024..TradingDays b on d1.Date=b.Date
left join dbQ2024..TradingShortened c1 on b.Next1=c1.Date
left join dbQ2024..TradingShortened c2 on b.Next2=c2.Date
inner join dbQ2024..DayPolygon d2 on d1.Symbol=d2.Symbol and b.Next1=d2.Date
inner join dbQ2024..DayPolygon d3 on d1.Symbol=d3.Symbol and b.Next2=d3.Date
left join dbQ2023Others..Splits s1 on s1.Symbol=d1.Symbol and s1.Date=d1.Date
left join dbQ2023Others..Splits s2 on s2.Symbol=d2.Symbol and s2.Date=d2.Date
left join dbQ2023Others..Splits s3 on s3.Symbol=d3.Symbol and s3.Date=d3.Date
where d2.IsTest is null and d2.tradecount>5000 and d2.[close] >= 5 and d2.volume/1000000.0 * d2.[close]>10
and b.IsShortened is null and c1.Date is null and c2.Date is null
and s1.Symbol is null and s2.Symbol is null and s3.Symbol is null 
and (d2.[Open]/d2.[Close]<0.95 or d2.[Open]/d2.[Close]>1.05)
and year(d2.Date)=2023

SELECT *
FROM dbQ2024..DayPolygon
where IsTest is null and tradecount>5000 and [close] >= 5 and volume/1000000.0 * [close]>10
and ([Open]/[Close]<0.97 or [Open]/[Close]>1.03)
and year(Date)=2023

SELECT *
FROM dbQ2024..DayPolygon
where IsTest is null and tradecount>5000 and [close] <5 and volume/1000000.0 * [close]>10
and abs([Open]-[Close])/([Open]+[Close])*2>0.03
and year(Date)=2023

Create view vOpenCloseBase as
SELECT symbol, a.Date, [Open], High, Low, [Close], Volume,
Volume/1000000.0 * [Close] Turnover,
abs([Open]-[Close])/([Open]+[Close])*200.0 as ChangePercent,
b.Prev1, b.Prev2, b.Next1, b.IsShortened
from dbQ2024..DayPolygon a
inner join dbQ2024..TradingDays b on a.Date=b.Date
where YEAR(a.Date)=2023 AND IsTest is null and Volume/1000000.0 * [Close]>=10.0
-- and abs([Open]-[Close])/([Open]+[Close])*200.0>=2.0

select AVG(OpenToClose), AVG(CloseToOpen), count(*) from
(select b.[Open]/b.[Close] OpenToClose, b.[Close]/b.[Open] CloseToOpen, a.* from vOpenCloseBase2023 a
inner join dbQ2024..DayPolygon b on a.Symbol=b.Symbol and a.Next1=b.Date and a.OpenClosePercent>=3.0) x

select kind, AVG(OpenToClose), AVG(CloseToOpen), count(*) from
(select iif(a.[Open]>a.[Close], 1, 0) kind, b.[Open]/b.[Close] OpenToClose, b.[Close]/b.[Open] CloseToOpen, a.* from vOpenCloseBase2023 a
inner join dbQ2024..DayPolygon b on a.Symbol=b.Symbol and a.Next1=b.Date and a.OpenClosePercent>=3.0) x
group by kind

select kind, AVG(OpenToClose), AVG(CloseToOpen), count(*) from
(select iif(a.[Open]>a.[Close], 1, 0) kind, b.[Open]/b.[Close] OpenToClose, b.[Close]/b.[Open] CloseToOpen, a.* from vOpenCloseBase2023 a
inner join dbQ2024..DayPolygon b on a.Symbol=b.Symbol and a.Next1=b.Date and a.OpenClosePercent>=5.0
where a.TradeCount>=5000) x
group by kind

select kind, AVG(OpenToClose), AVG(CloseToOpen), count(*) from
(select iif(a.[Open]>a.[Close], 1, 0) kind, b.[Open]/b.[Close] OpenToClose, b.[Close]/b.[Open] CloseToOpen, a.* from vOpenCloseBase2023 a
inner join dbQ2024..DayPolygon b on a.Symbol=b.Symbol and a.Next1=b.Date and a.OpenClosePercent>=16.0
where a.TradeCount>=5000) x
group by kind

select kind, AVG(OpenToClose), AVG(CloseToOpen), count(*) from
(select iif(a.[Open]>a.[Close], 1, 0) kind, b.[Open]/b.[Close] OpenToClose, b.[Close]/b.[Open] CloseToOpen, a.* from vOpenCloseBase2023 a
inner join dbQ2024..DayPolygon b on a.Symbol=b.Symbol and a.Next1=b.Date
where a.TradeCount>=5000) x
group by kind

-- =========  One open_close level
;WITH CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY a.Date ORDER BY OpenClosePercent desc),
	    iif(a.[Open]>a.[Close], 1, 0) kind, (b.[open]-b.[close])/(b.[open]+b.[close])*200 OCPerc, b.[Open]/b.[Close] OpenToClose, b.[Close]/b.[Open] CloseToOpen, a.* from vOpenCloseBase2023 a
inner join dbQ2024..DayPolygon b on a.Symbol=b.Symbol and a.Next1=b.Date
where a.TradeCount>=5000 and a.OpenClosePercent>=1 and a.Turnover>=50
    )
-- 	select * from cte
	select avg(OpenToClose), avg(CloseToOpen), avg(OCPerc),  count(*) from 
    (SELECT *
    FROM    CTE
    WHERE   RN <= 5) x ;

-- 50: 1,05949009780884	0,980968488907814	3,27087248559147	1250
-- 70: 1,05501384420395	0,982570224928856	2,99184044238776	1250
-- 100: 1,04705003209114	0,986894740891457	2,39728254977316	1250

-- 50/>=10(OCPerc): 1,06065562508429	0,980543719832504	3,33758497673435	1226
-- 70/>=10(OCPerc): 1,05753327368692	0,981233013349597	3,14990363721288	1195
-- 100/>=10(OCPerc): 1,0526551910378	0,984787809724834	2,69714721975845	1106

-- 50/>=16(OCPerc): 1,07827554328609	0,973040117351994	4,38835372282927	938
-- 70/>=16(OCPerc): 1,08167008332275	0,972874169302833	4,44250177807341	789
-- 100/>=16(OCPerc): 1,08584553255953	0,974383907799069	4,37293325372777	637

-- ==========  Minute  ============
select (b.[open]-b.[close])/(b.[open]+b.[close])*200, * from
(select abs([open]-[close])/([open]+[close])*200 OCPerc, * from dbQ2024Tests2..HourPolygon where time='09:30:00' and TradeCount>=500) a
inner join dbQ2024Tests2..HourPolygon b on a.Symbol=b.Symbol and a.Date=b.Date and a.[To]=b.[Time]
where b.[Open]>1.0


;WITH CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY a.Date ORDER BY OCPerc desc),
(b.[open]-b.[close])/(b.[open]+b.[close])*200 Result, a.* from
(select abs([open]-[close])/([open]+[close])*200 OCPerc, * from dbQ2024Tests2..HourPolygon where time='09:30:00' and TradeCount>=500) a
inner join dbQ2024Tests2..HourPolygon b on a.Symbol=b.Symbol and a.Date=b.Date and a.[To]=b.[Time]
where b.[Open]>1.0 and a.[Close]*a.[Volume]>=30000000 and year(a.Date)=2023 and a.[Open]>a.[Close]
    )
-- 	select * from cte
	select avg(Result),  count(*) from 
    (SELECT *
    FROM    CTE
    WHERE   RN <= 5) x ;

;WITH CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY a.Date ORDER BY OCPerc desc),
(b.[open]-b.[close])/(b.[open]+b.[close])*200 Result, a.* from
(select abs([open]-[close])/([open]+[close])*200 OCPerc, * from dbQ2024Tests2..HourPolygon where time='10:00:00' and TradeCount>=500) a
inner join dbQ2024Tests2..HourPolygon b on a.Symbol=b.Symbol and a.Date=b.Date and a.[To]=b.[Time]
where b.[Open]>1.0 and a.[Close]*a.[Volume]>=40000000 -- and year(a.Date)=2023 -- and a.[Open]>a.[Close]
and abs(a.[open]-a.[close])/(a.[open]+a.[close])*200>1
    )
-- 	select * from cte
	select FORMAT(Date,'yyyy-MM'), avg(Result),  count(*) from 
    (SELECT *
    FROM    CTE
    WHERE   RN <= 50) x
	group by FORMAT(Date,'yyyy-MM') order by 1 ;

-- 0,479600223063674	2620
-- 2023, Open>Close: 0,172096093043964	1250
-- 2023, Open<Close: 0,0193662476047873	1250
