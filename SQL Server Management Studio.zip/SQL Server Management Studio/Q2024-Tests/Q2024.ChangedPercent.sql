
select (b.[open]-b.[close])/(b.[open]+b.[close])*200, * from
(select abs([open]-[close])/([open]+[close])*200 AbsChanged, * from dbQ2024Tests2..HourPolygon
 where time='09:30:00' and TradeCount>=500) a
inner join dbQ2024Tests2..HourPolygon b on a.Symbol=b.Symbol and a.Date=b.Date and a.[To]=b.[Time]
where b.[Open]>1.0

select time, avg(AbsChanged) AbsChanged, avg(Changed) Changed, count(*) from
(select abs([open]-[close])/([open]+[close])*200 AbsChanged,
([open]-[close])/([open]+[close])*200 Changed, * from dbQ2024Tests2..HourPolygon where [open]>0) x
-- where time='09:30:00' and TradeCount>=500
group by time order by 1

select * from dbQ2024Tests2..HourPolygon where [open]<0.0001

-- ======  Daily  =======
select avg(AbsChanged) AbsChanged, avg(Changed) Changed, count(*) from
(select abs([open]-[close])/([open]+[close])*200 AbsChanged,
([open]-[close])/([open]+[close])*200 Changed, * from dbQ2024..DayPolygon
where [close]*[volume]>=10000000 and year(date)=2023) x

select avg(AbsChanged) AbsChanged, avg(Changed) Changed, count(*) from
(select abs([open]-[close])/([open]+[close])*200 AbsChanged,
 ([open]-[close])/([open]+[close])*200 Changed, * from dbQ2024..DayPolygon
where [close]>=5.0 and [close]*[volume]>=10000000 and year(date)=2023 and TradeCount>=5000) x

-- =======  Hourly  ======
select [Time], [To], avg(AbsChanged) AbsChanged, avg(Changed) Changed, count(*) from
(select abs([open]-[close])/([open]+[close])*200 AbsChanged,
([open]-[close])/([open]+[close])*200 Changed, * from dbQ2024Tests2..HourPolygon
where [close]>=5.0 and [close]*[volume]>=1000000 and year(date)=2023 and TradeCount>=500) x
group by [Time], [To] order by 1,2

select [Time], [To], avg(AbsChanged) AbsChanged, avg(Changed) Changed, count(*) from
(select abs([open]-[close])/([open]+[close])*200 AbsChanged,
([open]-[close])/([open]+[close])*200 Changed, * from dbQ2024Tests2..HourPolygon
where [close]>=5.0 and year(date)=2023 and TradeCount>=200) x
group by [Time], [To] order by 1,2

select count(*), min(date) from dbQ2024..HourPolygon

select * from dbQ2024..HourPolygon
where TradeCount=0

