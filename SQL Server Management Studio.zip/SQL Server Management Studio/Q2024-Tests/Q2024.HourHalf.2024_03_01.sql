use dbQ2024Tests;

/* Check data - OK
select year(h1.date), count(*)
from dbQ2024Tests2..HourHalfPolygon2 h1
inner join dbQ2024Tests2..HourHalfPolygon2 h2 on h1.Symbol=h2.Symbol and h1.Date=h2.Date and h1.[To]=h2.[Time]
inner join dbQ2024..SymbolsPolygon s on h1.Symbol=s.Symbol and h1.Date between s.Date and isnull(s.[To], '2099-12-31')
inner join (select * from dbQ2024..TradingDays where IsShortened is null) d on h1.Date=d.Date
inner join (select distinct symbol, date from dbQ2024Minute..MinutePolygonLog where rowstatus in (2,5) and Volume*[Close]/1000000>=50 and TradeCount>=5000) x
on x.Symbol=h1.Symbol and x.Date=h1.Date
where h1.TradeCount>=500 and h1.[Close]*h1.[Volume]>=1000000 and h1.[close]>=5.0
and h1.Date<='2024-01-01'
and h2.OpenNextDelayInMinutes is not null
group by year(h1.date) order by 1
-- 2021	3123479
-- 2022	3162864
-- 2023	2896596

select year(date), count(*), min(TradeCount1), min(Volume1*Close1)/1000000 from temp_OpenCloseHourHalf_2024_03 group by year(date) order by 1
-- 2022	3162864
-- 2023	2896596*/

/*-- Base SQL (no moving average) --
-- drop table temp_OpenCloseHourHalf_2024_03
-- 2:26 min: 4015910 rows (h1.TradeCount>=1000 and h1.[Close]*h1.[Volume]>=5000000 and h1.[close]>=5.0), 2022-2023year, no Shortened days
-- 3:17 min: 5562510 rows (h1.TradeCount>=500 and h1.[Close]*h1.[Volume]>=3000000 and h1.[close]>=5.0), 2022-2023year, no Shortened days
-- 3:34 min: 6059460 rows (h1.TradeCount>=500 and h1.[Close]*h1.[Volume]>=1000000 and h1.[close]>=5.0), 2022-2023year, no Shortened days
select 
(h1.[Open]-h1.[Close])/(h1.[Open]+h1.[Close]) * 200.0 PrevOC,
(h1.[High]-h1.[Low])/(h1.[High]+h1.[Low]) * 200.0 PrevHL,
(h2.[Open]-h2.[Close])/h2.[Open] * 100.0 Profit,
(h2.[OpenNext]-h2.[Close])/h2.[OpenNext] * 100.0 ProfitNext,
h1.[Close]*h1.[Volume]/1000000.0 Turnover,
format(h2.date, 'yyyy-MM') as Period,
case when h1.[Open]>h1.[Close] then 'Down' else 'Up' end as UpDown,
h1.Symbol, s.Exchange, s.MyType, h1.[Date], h2.[Time] Time2, h2.[To] To2,
h2.OpenNext, h2.OpenNextDelayInMinutes,
h2.PrevWma_20, h2.Wma_20, h2.PrevWma_30, h2.Wma_30, 
h2.PrevEma_20, h2.Ema_20, h2.PrevEma_30, h2.Ema_30, 
h2.PrevEma2_20, h2.Ema2_20, h2.PrevEma2_30, h2.Ema2_30, 
h1.[Open] Open1, h1.High High1, h1.Low Low1, h1.[Close] Close1, h1.Volume Volume1, h1.[Count] Count1, h1.TradeCount TradeCount1, h1.volume/1000000.0 * h1.[close] Turnover1,
h2.[Open] Open2, h2.High High2, h2.Low Low2, h2.[Close] Close2, h2.Volume Volume2, h2.[Count] Count2, h2.TradeCount TradeCount2, h2.volume/1000000.0 * h2.[close] Turnover2
into temp_OpenCloseHourHalf_2024_03
from dbQ2024..HourHalfPolygon h1
inner join dbQ2024..HourHalfPolygon h2 on h1.Symbol=h2.Symbol and h1.Date=h2.Date and h1.[To]=h2.[Time]
inner join dbQ2024..SymbolsPolygon s on h1.Symbol=s.Symbol and h1.Date between s.Date and isnull(s.[To], '2099-12-31')
inner join (select * from dbQ2024..TradingDays where IsShortened is null) d on h1.Date=d.Date
where h1.TradeCount>=500 and h1.[Close]*h1.[Volume]>=1000000 and h1.[close]>=5.0
and h1.Date<='2024-01-01'
and h2.OpenNextDelayInMinutes is not null*/

;with CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date, [Time2] ORDER BY PrevHL desc), *
	   FROM temp_OpenCloseHourHalf_2024_03 where year(Date)=2023
	   and Turnover1<20
	   -- and TradeCount1>=500
	   -- and TradeCount1>500 and TradeCount1<10000
	   -- and 1.0015*PrevWma_20<Wma_20 -- 1.0015*PrevWma_20<Wma_20 = 0.16 for 1720 rows
	   -- and OpenNext>1.006*Open2 -- OpenNext>1.006*Open2 = 0.13 for 1273 rows
	   -- and Open2>1.01*Wma_20 -- Open2>1.01*Wma_20 = 0.3 for 1492 rows
	   and PrevHL>7 -- PrevHL>7 = 0.488 for 1257 rows
	   and UpDown='Up'
	   -- and PrevOC<=-4 -- !! PrevOC<=-4 = 0.5 for 1565 rows
	   and OpenNextDelayInMinutes<3
	   -- and Close1 between 5 and 500
    )
    SELECT CAST('0:0:0' as Time(0)) Time, avg(ProfitNext) ProfitNext, avg(Profit) Profit, 
		Avg(PrevHL) AvgPrevHL, Avg(PrevOC) AvgPrevOC, count(*) Recs, min(TradeCount2) MinTradeCount2,
		Avg(Volume1/TradeCount1) OneTradeShares, Avg(Volume1/TradeCount1*Close1) OneTradeValue
	FROM CTE WHERE RN <=5
	UNION
    SELECT Time2, avg(ProfitNext) ProfitNext, avg(Profit) Profit, 
		Avg(PrevHL) AvgPrevHL, Avg(PrevOC) AvgPrevOC, count(*) Recs, min(TradeCount2) MinTradeCount2,
		Avg(Volume1/TradeCount1) OneTradeShares, Avg(Volume1/TradeCount1*Close1) OneTradeValue
	FROM CTE WHERE RN <= 5
	group by [Time2]
-- Results:
-- year=2023 and Turnover1<20 and PrevHL>7 and UpDown='Up' and OpenNextDelayInMinutes<3
-- Time	ProfitNext	Profit	AvgPrevHL	AvgPrevOC	Recs	MinTradeCount2	OneTradeShares	OneTradeValue
-- 00:00:00	-0,487923106475422	-0,555321958310555	12,7753818955038	-6,99056252278351	1257	483	152,756562074405	2255,04416920519
-- 10:00:00	-0,529717392651041	-0,488767244831825	10,9509743654876	-6,7676499114909	482	564	141,101491682757	2836,90544261378
-- 10:30:00	-1,31008607684827	-1,23227356719084	12,5425028998005	-6,97624881848816	121	963	160,324790387114	1984,82631462665
-- 11:00:00	-1,76648348109009	-2,31012731249511	14,7384440235256	-8,65836801723884	97	924	148,689033822915	1912,40071971146
-- 11:30:00	0,136903209024913	0,274108982249482	13,5724767332208	-6,76701491177146	73	980	158,401654674582	1817,65987448496
-- 12:00:00	-3,12817630000779	-3,16292688250542	14,8520073890686	-7,38917825688593	61	1205	153,518661811704	1785,32944676133
-- 12:30:00	-2,45318633824587	-2,89821191202849	14,4777956581116	-7,20348222305377	75	1198	162,029626235962	1626,08802246094
-- 13:00:00	1,7665333583735	2,21928519960763	14,4750967163971	-7,96386164038078	69	1131	158,764480065608	2025,64483200294
-- 13:30:00	-0,891134377440502	-1,28548894591373	12,9450063541018	-5,75570648176403	58	483	177,630569984173	1993,01710036705
-- 14:00:00	1,32228408288211	1,14051530556753	14,0753629406293	-6,52075593732297	48	974	156,833198388418	1818,40218353271
-- 14:30:00	0,68337930176136	0,399927741111214	14,3178456434563	-6,59071882697406	67	801	161,943857221461	1916,80427574044
-- 15:00:00	0,72668979355688	0,577154140469843	13,5922424299964	-6,87326434280338	58	1059	165,727056371755	1873,07121119006
-- 15:30:00	2,39746836945415	2,23835178138688	14,1158410112063	-6,65807693172246	48	2050	163,625814159711	2047,34516525269
-- year=2022 and Turnover1<20 and PrevHL>7 and UpDown='Up' and OpenNextDelayInMinutes<3
-- Time	ProfitNext	Profit	AvgPrevHL	AvgPrevOC	Recs	MinTradeCount2	OneTradeShares	OneTradeValue
-- 00:00:00	-0,731401710401766	-0,789241310404193	11,3917234210037	-6,55882989443354	1783	197	172,400699534178	2560,22421885954
-- 10:00:00	-0,600170365160383	-0,572924874698122	10,9526861494559	-6,92564938387937	675	205	147,826322643139	2838,85594762731
-- 10:30:00	-1,12653765753071	-1,28320598954039	10,6134767900721	-6,4770814991704	233	690	163,525554354099	2322,66690836239
-- 11:00:00	-0,349696320578359	-0,486090114267616	12,5873113978993	-6,69976972217684	154	549	179,843465340602	2320,89194874949
-- 11:30:00	-0,936740852578884	-0,698476266968848	11,0983447367602	-5,75540860749707	101	782	185,076471659217	2185,88279678798
-- 12:00:00	-0,663363606744253	-0,577238940851047	12,2045557615234	-6,14730540026979	82	829	190,089174700946	2504,82101365997
-- 12:30:00	-0,634758292226592	-0,820356422564486	12,2623892773639	-6,51902343938639	91	814	207,323161072783	2335,39366602636
-- 13:00:00	-1,96752594890514	-2,24340837291981	11,4185113342185	-5,48227862582395	76	763	210,170403003693	2332,29133365029
-- 13:30:00	-0,701203846059636	-0,802939704060554	13,1930845843421	-6,90545689057973	90	291	197,711280420091	2564,89461941189
-- 14:00:00	-0,445935579186136	-0,639150854482344	11,5102225072456	-6,68781663612886	66	1175	205,181721369425	2398,40240293561
-- 14:30:00	-1,94985592732395	-2,29771069977163	12,0527134978253	-6,04731520880824	69	932	202,182955935381	2557,78498995131
-- 15:00:00	-0,225443758947008	-0,231525740136995	11,3798240942114	-6,13619954025044	85	197	185,199147931267	2671,42451602711
-- 15:30:00	0,326340095918687	0,148415245848601	10,7480066799727	-6,25684413020728	61	907	191,186508647731	2318,28679919634