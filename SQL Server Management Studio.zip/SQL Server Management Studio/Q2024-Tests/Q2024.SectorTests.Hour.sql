use dbQ2024Tests;

/*-- Check data: OK
select year(h1.date), count(*)
from dbQ2024..HourPolygon5 h1
inner join dbQ2024..HourPolygon5 h2 on h1.Symbol=h2.Symbol and h1.Date=h2.Date and h1.[To]=h2.[Time]

inner join (select distinct symbol, date from dbQ2024Minute..MinutePolygonLog where rowstatus in (2,5) and Volume*[Close]/1000000>=50 and TradeCount>=5000) x
on x.Symbol=h1.Symbol and x.Date=h1.Date

left join (select b.Sector2, a.* from dbQ2024..SymbolsPolygon a
		inner join (select CIK, min(b.Sector) Sector2 from (select * from dbQ2024..SymbolsPolygon where [To] is null) a
			inner join dbQ2023Others..ScreenerMorningStar b on a.Symbol=b.Symbol and a.Exchange=b.Exchange
		where a.IsTest is null and a.MyType in ('ADRC','CS','PFD', 'UNIT') AND (a.[To] is null or a.[To]>'2024-01-01')
			and cik is not null
		group by CIK) b on a.CIK=b.CIK) s on h1.Symbol=s.Symbol and h1.Date between s.Date and isnull(s.[To], '2099-12-31')
where h1.TradeCount>=1000 and h1.[Close]*h1.[Volume]>=5000000 and h1.[close]>=5.0
and h1.Date<='2024-02-16'
and h2.OpenNextDelayInMinutes is not null and h2.[Time] not in ('15:45:00', '12:45:00') 
group by year(h1.date) order by 1
-- 2022	1493181
-- 2023	1358346
-- 2024	191777

select year(date), count(*) from temp_OpenCloseHourSector group by year(date) order by 1
-- 2022	1493181
-- 2023	1358346
-- 2024	191777*/

/*-- drop table temp_OpenCloseHourSector
-- 2'332'878 rows (h1.TradeCount>=1000 and h1.[Close]*h1.[Volume]>=10000000 and h1.[close]>=5.0)
-- 3'043'304 (where h1.TradeCount>=1000 and h1.[Close]*h1.[Volume]>=5000000 and h1.[close]>=5.0)
select 
abs(h1.[Open]-h1.[Close])/(h1.[Open]+h1.[Close]) * 200.0 PrevChangeAbsOpenCLose,
(h1.[High]-h1.[Low])/(h1.[High]+h1.[Low]) * 200.0 PrevChangeHighLow,
-- Bad: use OpenNext (h2.Open-h2.[Close])/(h2.[Open]+h2.[Close]) * 200.0 Profit,
(h2.OpenNext-h2.[Close])/(h2.[OpenNext]+h2.[Close]) * 200.0 Profit,
h1.[Close]*h1.[Volume]/1000000.0 Turnover,
format(h2.date, 'yyyy-MM') as Period,
case when h1.[Open]>h1.[Close] then 'Down' else 'Up' end as UpDown,
h1.Symbol, s.Exchange, s.MyType, s.Sector, h1.[Date], h1.[Time], h1.[To], h2.[To] EndTime,
h2.OpenNext, h2.OpenNextDelayInMinutes,
h2.PrevWma_20, h2.Wma_20, h2.PrevWma_30, h2.Wma_30, 
h2.PrevEma_20, h2.Ema_20, h2.PrevEma_30, h2.Ema_30, 
h2.PrevEma2_20, h2.Ema2_20, h2.PrevEma2_30, h2.Ema2_30, 
h1.[Open] Open1, h1.High High1, h1.Low Low1, h1.[Close] Close1, h1.Volume Volume1, h1.[Count] Count1, h1.TradeCount TradeCount1, h1.volume/1000000.0 * h1.[close] Turnover1,
h2.[Open] Open2, h2.High High2, h2.Low Low2, h2.[Close] Close2, h2.Volume Volume2, h2.[Count] Count2, h2.TradeCount TradeCount2, h2.volume/1000000.0 * h2.[close] Turnover2
into temp_OpenCloseHourSector
from dbQ2024Tests2..HourPolygon h1
inner join dbQ2024Tests2..HourPolygon h2 on h1.Symbol=h2.Symbol and h1.Date=h2.Date and h1.[To]=h2.[Time]
left join (
select b.Sector, a.* from dbQ2024..SymbolsPolygon a
inner join
(select CIK, min(b.Sector) Sector
from (select * from dbQ2024..SymbolsPolygon where [To] is null) a
inner join dbQ2023Others..ScreenerMorningStar b on a.Symbol=b.Symbol and a.Exchange=b.Exchange
where a.IsTest is null and a.MyType in ('ADRC','CS','PFD', 'UNIT') AND (a.[To] is null or a.[To]>'2024-01-01')
and cik is not null
group by CIK) b on a.CIK=b.CIK) s on h1.Symbol=s.Symbol and h1.Date between s.Date and isnull(s.[To], '2099-12-31')
-- where h1.TradeCount>=1000 and h1.[Close]*h1.[Volume]>=5000000 and h1.[close]>=5.0
where h1.TradeCount>=1000 and h1.[Close]*h1.[Volume]>=5000000 and h1.[close]>=5.0
and h1.Date<='2024-02-16'
and h2.OpenNextDelayInMinutes is not null and h2.[Time] not in ('15:45:00', '12:45:00')*/

-- !!!! MovingAverage ===
-- Group by time for all sectors: old version
;WITH CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date, [Time] ORDER BY PrevEma2_20/Ema2_20 desc), *
	   FROM (select * from temp_OpenCloseHourSector WHERE
		PrevEma2_20>Ema2_20 and OpenNext<Open2 and Open2<Ema2_20
	   -- and PrevEma_20>Ema_20 and Open2<Ema_20
-- !!		and PrevEma2_20/Ema2_20>1.0005
	   and OpenNextDelayInMinutes=1 ) x
    )
    SELECT [Time], avg(Profit), count(*) FROM CTE
    WHERE   RN <= 5 and Year(date)=2023
	group by [Time] order by 1

-- Group by sector
;WITH CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date, [Time] ORDER BY PrevEma2_20/Ema2_20 desc), *
	   FROM (select * from temp_OpenCloseHourSector WHERE
		PrevEma2_20>Ema2_20 and OpenNext<Open2 and Open2<Ema2_20
	   -- and PrevEma_20>Ema_20 and Open2<Ema_20
	   -- and PrevEma2_20/Ema2_20>1.0005
--	   and (Sector is null or Sector like '[A-Z]%')
	   and (Sector is null or Sector like '[B,E,F,H,T]%')
	   and OpenNextDelayInMinutes=1 ) x
    )
    SELECT Sector, avg(Profit), count(*) FROM CTE
    WHERE   RN <= 5 and Year(date)=2022
	group by Sector order by 1,2

-- Filter by some sectors
;WITH CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date, [Time] ORDER BY PrevEma2_20/Ema2_20 desc), *
	   FROM (select * from temp_OpenCloseHourSector WHERE
		PrevEma2_20>Ema2_20 and OpenNext<Open2 and Open2<Ema2_20
	   -- and PrevEma_20>Ema_20 and Open2<Ema_20
	   and PrevEma2_20/Ema2_20>1.0005
--	   and (Sector is null or Sector like '[A-Z]%')
	   and (Sector is null or Sector like '[E,F,H]%')
	   and OpenNextDelayInMinutes=1 ) x
    )
    SELECT Time, avg(Profit), count(*) FROM CTE
    WHERE   RN <= 5 and Year(date)=2022
	group by Time order by 1,2

;WITH CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date, [Time] ORDER BY PrevEma2_20/Ema2_20 desc), *
	   FROM (select * from temp_OpenCloseHourSector WHERE
	   /*Prev2Ema2_20>PrevEma2_20 and*/ PrevEma2_20>Ema2_20 and OpenNext<Open2 and Open2<Ema2_20
	   -- and PrevEma_20>Ema_20 and Open2<Ema_20
	   and OpenNextDelayInMinutes=1 ) x
    )
    SELECT [Time], avg(Profit), count(*) FROM CTE
    WHERE   RN <= 5 and Year(date)=2023 and PrevEma2_20/Ema2_20>1.0005
	group by [Time] order by 1
	-- group by [Time], Period order by 2,1
/* Wma_20: OpenNextDelayInMinutes<5
09:30:00	0,408270181017739	1255
10:00:00	0,477724070440462	1255
11:00:00	0,655141683590721	1255
12:00:00	0,542832720925333	1250
13:00:00	0,470814637047239	1250
14:00:00	0,281246360476967	1250
Wma_20: OpenNextDelayInMinutes=1
09:30:00	0,409942661276072	1255
10:00:00	0,443500299995257	1255
11:00:00	0,658862801470545	1255
12:00:00	0,538870264976146	1250
13:00:00	0,444742411089875	1250
14:00:00	0,281332646139618	1250
Wma_30: OpenNextDelayInMinutes=1
09:30:00	0,737803956403015	1255
10:00:00	0,431143548469749	1255
11:00:00	0,652264909213223	1255
12:00:00	0,584661007010983	1250
13:00:00	0,447901323156804	1250
14:00:00	0,352487175790925	1249
Ema_20: OpenNextDelayInMinutes=1 (PrevEma_20>Wma_20 and OpenNext<Open2 and Open2<Ema_20)
09:30:00	0,704710336658636	1255
10:00:00	0,464713753739361	1255
11:00:00	0,63798793735413	1255
12:00:00	0,579910419281991	1250
13:00:00	0,476234939190606	1250
14:00:00	0,378900463850449	1245
Ema_20: OpenNextDelayInMinutes=1
09:30:00	0,619936645330594	1255
10:00:00	0,476518121586864	1255
11:00:00	0,686515575936769	1255
12:00:00	0,601175620908709	1250
13:00:00	0,48722432848271	1250
14:00:00	0,369466721277591	1250
Ema_30: OpenNextDelayInMinutes=1
09:30:00	0,702988073665953	1255
10:00:00	0,48490594274715	1255
11:00:00	0,647213051864781	1255
12:00:00	0,604285779658006	1250
13:00:00	0,502091355817253	1250
14:00:00	0,403105235939892	1250
Ema2_20: OpenNextDelayInMinutes=1
09:30:00	0,667614546189441	1255
10:00:00	0,476928750945318	1255
11:00:00	0,639965759575426	1255
12:00:00	0,539275229055434	1250
13:00:00	0,544511531010503	1250
14:00:00	0,38000374087384	1250
Ema2_30: OpenNextDelayInMinutes=1
09:30:00	0,668611215224	1255
10:00:00	0,440362184437129	1255
11:00:00	0,661340844450125	1255
12:00:00	0,484664678061428	1250
13:00:00	0,562012604093226	1250
14:00:00	0,403556250521091	1249
*/
