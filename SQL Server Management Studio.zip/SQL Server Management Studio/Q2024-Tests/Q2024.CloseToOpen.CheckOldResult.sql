-- select min(date1), max(Date1), count(*) from dbQ2023..temp_openclose
-- 2018-03-27	2023-12-06, 189056/189187
-- ======  For dbQ2024 (26 secs)  =====
-- AverAbsOpenClose	AvgNewK	AvgPrevK	Recs	MinPrevK
-- 1,08975684206564	1,00454282724034	1,00797474022887	189187	0,092
-- ======== In =========
-- AverAbsOpenClose	AvgNewK	AvgNewKIn	AvgPrevK	Recs	MinPrevK
-- 1,08968806390257	1,00475855306166	1,00239619359053	1,00801052116409	189137	0,092

use dbQ2024Tests;

-- drop table temp_OpenClose
select avg(K_OpenClose) AverAbsOpenClose, avg(NewK) AvgNewK, avg(PrevK) AvgPrevK, count(*) Recs, min(PrevK) MinPrevK from 
(SELECT
case when d2.[Open]>d2.[Close] then d2.[Open]/d2.[Close] else d2.[Close]/d2.[Open] end K_OpenClose,
d3.[Open]/d3.[Close] NewK,
d2.[open]/d2.[Close] PrevK, d1.[open]/d1.[Close] Prev2K,
format(d3.date, 'yyyy-MM') as period, case when d2.[Open]>d2.[Close] then 'Down' else 'Up' end as UpDown,
1.0*d2.TradeCount/d1.TradeCount TradeK, d1.Symbol, 
d1.Date Date1, d1.[Open] Open1, d1.High High1, d1.Low Low1, d1.[Close] Close1, d1.Volume Volume1, d1.TradeCount TradeCnt1, d1.volume/1000000.0 * d1.[close] Turnover1,
d2.Date Date2, d2.[Open] Open2, d2.High High2, d2.Low Low2, d2.[Close] Close2, d2.Volume Volume2, d2.TradeCount TradeCnt2, d2.volume/1000000.0 * d2.[close] Turnover2,
d3.Date Date3, d3.[Open] Open3, d3.High High3, d3.Low Low3, d3.[Close] Close3, d3.Volume Volume3, d3.TradeCount TradeCnt3, d3.volume/1000000.0 * d3.[close] Turnover3
-- into temp_OpenClose
FROM dbQ2024..DayPolygon d1
inner join dbQ2024..TradingDays b on d1.Date=b.Date
left join dbQ2024..TradingShortened c1 on b.Next1=c1.Date
left join dbQ2024..TradingShortened c2 on b.Next2=c2.Date
inner join dbQ2024..DayPolygon d2 on d1.Symbol=d2.Symbol and b.Next1=d2.Date
inner join dbQ2024..DayPolygon d3 on d1.Symbol=d3.Symbol and b.Next2=d3.Date
left join dbQ2024..Splits s1 on s1.Symbol=d1.Symbol and s1.Date=d1.Date
left join dbQ2024..Splits s2 on s2.Symbol=d2.Symbol and s2.Date=d2.Date
left join dbQ2024..Splits s3 on s3.Symbol=d3.Symbol and s3.Date=d3.Date
where d1.IsTest is null and d2.tradecount>5000 and d2.[close] >= 5 and d2.volume/1000000.0 * d2.[close]>10
and b.IsShortened is null and c1.Date is null and c2.Date is null
and s1.Symbol is null and s2.Symbol is null and s3.Symbol is null 
and (d2.[Open]/d2.[Close]<0.95 or d2.[Open]/d2.[Close]>1.05)
-- and d1.Date between '2018-03-27' and '2023-12-06')x
and year(d1.Date)=2023)x

select a.*
from dbQ2023..temp_OpenClose a
left join dbQ2024Tests..temp_OpenClose b on a.Symbol=b.Symbol 
where b.Symbol is null
-- 1 row: MDGS	2023-06-08 -> open/close=1.036423

select a.*
from dbQ2024Tests..temp_OpenClose a
left join dbQ2023..temp_OpenClose b on a.Symbol=b.Symbol 
where b.Symbol is null
-- 1 rows: ELEV	2023-05-25

select * from dbQ2024..SymbolsPolygon where symbol='ZVZZT'
select * from dbQ2024..DayPolygon where symbol='MDGS' and date >= '2023-06-08' order by date
select * from dbQ2023..DayPolygon where symbol='MDGS' and date >= '2023-06-08' order by date
select * from dbQ2024..DayPolygon where symbol='ELEV' and date >= '2023-05-25' order by date
select * from dbQ2023..DayPolygon where symbol='ELEV' and date >= '2023-05-25' order by date

select * from dbQ2024..splits where symbol in ('MDGS','ELEV') order by date desc

-- Data for Excel (dbQ2023)
;WITH CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date3 ORDER BY K_OpenClose desc), * FROM dbQ2023..temp_OpenClose
    )
    SELECT *
    FROM    CTE
    WHERE   RN <= 5
	order by Date3, RN ;

-- Data for Excel (dbQ2024Tests)
;WITH CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date3 ORDER BY K_OpenClose desc), * FROM dbQ2024Tests..temp_OpenClose
    )
    SELECT *
    FROM    CTE
    WHERE   RN <= 5
	order by Date3, RN ;

-- Compare data for Excel
;WITH CTE_2024 AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date3 ORDER BY K_OpenClose desc), * FROM dbQ2024Tests..temp_OpenClose
    ),
CTE_2023 AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date3 ORDER BY K_OpenClose desc), * FROM dbQ2023..temp_OpenClose
    )
	select * from 
    (SELECT * FROM CTE_2024 WHERE RN <= 5) a
	left join (SELECT * FROM CTE_2023 WHERE RN <= 5) b on a.Symbol=b.Symbol and a.Date1=b.Date1
	where b.Symbol is null;
-- 7 rows: BIG/2023-05-26, DLO/2023-05-25, ITOS/2023-05-25, SOXS/2023-05-25, BHG/2023-05-25, AMSWA/2023-06-08, SDA/2023-05-25

;WITH CTE_2024 AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date3 ORDER BY K_OpenClose desc), * FROM dbQ2024Tests..temp_OpenClose
    ),
CTE_2023 AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date3 ORDER BY K_OpenClose desc), * FROM dbQ2023..temp_OpenClose
    )
	select * from 
    (SELECT * FROM CTE_2023 WHERE RN <= 5) a
	left join (SELECT * FROM CTE_2024 WHERE RN <= 5) b on a.Symbol=b.Symbol and a.Date1=b.Date1
	where b.Symbol is null;
-- 2 rows: AI/2023-05-26, MVIS/2023-06-08

-- ==========================================
/*select AVG([Open]/[Close]) from dbQ2024..DayPolygon d
where d2.tradecount>5000 and d2.[close] >= 5 and d2.volume/1000000.0 * d2.[close]>50
and d2.Date between '2018-03-27' and '2023-12-06'*/

/*
-- select avg(K_OpenClose) AverAbsOpenClose, avg(NewK) AvgNewK, avg(NewKIn) AvgNewKIn, avg(PrevK) AvgPrevK, count(*) Recs, min(PrevK) MinPrevK from 
select avg(K_OpenClose) AverAbsOpenClose, avg(NewK) AvgNewK, /*avg(NewK1) AvgNewK1,*/ avg(PrevK) AvgPrevK, count(*) Recs, min(PrevK) MinPrevK from 
(SELECT
case when d2.[Open]>d2.[Close] then d2.[Open]/d2.[Close] else d2.[Close]/d2.[Open] end K_OpenClose,
-- d3.[Open]/d3.[Close] NewK, d3.[OpenIn]/d3.[FinalIn] NewKIn,
d3.[Open]/d3.[Close] NewK,
-- d4.[Open]/d4.[Close] NewK1,
d2.[open]/d2.[Close] PrevK, d1.[open]/d1.[Close] Prev2K,
format(d3.date, 'yyyy-MM') as period, case when d2.[Open]>d2.[Close] then 'Down' else 'Up' end as UpDown,
1.0*d2.TradeCount/d1.TradeCount TradeK, d1.Symbol, 
d1.Date Date1, d1.[Open] Open1, d1.High High1, d1.Low Low1, d1.[Close] Close1, d1.Volume Volume1, d1.TradeCount TradeCnt1, d1.volume/1000000.0 * d1.[close] Turnover1,
d2.Date Date2, d2.[Open] Open2, d2.High High2, d2.Low Low2, d2.[Close] Close2, d2.Volume Volume2, d2.TradeCount TradeCnt2, d2.volume/1000000.0 * d2.[close] Turnover2,
d3.Date Date3, d3.[Open] Open3, d3.High High3, d3.Low Low3, d3.[Close] Close3, d3.Volume Volume3, d3.TradeCount TradeCnt3, d3.volume/1000000.0 * d3.[close] Turnover3
-- into temp_OpenClose
 FROM dbQ2024..DayPolygon d1
inner join dbQ2024..TradingDays b on d1.Date=b.Date
left join dbQ2024..TradingShortened c1 on b.Next1=c1.Date
left join dbQ2024..TradingShortened c2 on b.Next2=c2.Date
inner join dbQ2024..DayPolygon d2 on d1.Symbol=d2.Symbol and b.Next1=d2.Date
-- inner join dbQ2024..DayPolygon d3 on d1.Symbol=d3.Symbol and b.Next2=d3.Date
-- inner join (select * from dbQ2024Minute..MinutePolygonLog where RowStatus in (4,5) and FinalIn is not null) d3 on d1.Symbol=d3.Symbol and b.Next2=d3.Date
inner join (select * from dbQ2024..HourPolygon where [time]='10:00:00') d3 on d1.Symbol=d3.Symbol and b.Next2=d3.Date
-- inner join (select * from dbQ2024..HourPolygon where [time]='13:00:00') d4 on d1.Symbol=d4.Symbol and b.Next2=d4.Date
left join dbQ2024..Splits s1 on s1.Symbol=d1.Symbol and s1.Date=d1.Date
left join dbQ2024..Splits s2 on s2.Symbol=d2.Symbol and s2.Date=d2.Date
left join dbQ2024..Splits s3 on s3.Symbol=d3.Symbol and s3.Date=d3.Date
where d2.tradecount>5000 and d2.[close] >= 5 and d2.volume/1000000.0 * d2.[close]>10 and d3.[Open]>5.0 --and d4.[Open]>5.0
and b.IsShortened is null and c1.Date is null and c2.Date is null
and s1.Symbol is null and s2.Symbol is null and s3.Symbol is null 
and (d2.[Open]/d2.[Close]<0.95 or d2.[Open]/d2.[Close]>1.05)
and d1.Date between '2018-03-27' and '2023-12-06')x
*/
