use dbQ2024Tests;

-- drop table temp_OpenCloseDay
SELECT
abs(d2.[Open]-d2.[Close])/(d2.[Open]+d2.[Close]) * 200.0 PrevChangeAbsOpenCLose,
(d2.[High]-d2.[Low])/(d2.[High]+d2.[Low]) * 200.0 PrevChangeHighLow,
(d3.[Open]-d3.[Close])/(d3.[Open]+d3.[Close]) * 200.0 Profit,
(d3.[Open]-d3.[Close])/(d3.[Open]) * 100.0 ProfitReal,
d2.[Close]*d2.[Volume]/1000000.0 Turnover,
case when d2.[Open]>d2.[Close] then d2.[Open]/d2.[Close] else d2.[Close]/d2.[Open] end K_OpenClose,
case when d2.[Open]>d2.[Close] then d2.[Close]/d2.[Open] else d2.[Open]/d2.[Close] end K_CloseOpen,
d3.[Open]/d3.[Close] NewK_OpenClose,
d3.[Close]/d3.[Open] NewK_CloseOpen,
d2.[open]/d2.[Close] PrevOpenClose, d1.[open]/d1.[Close] Prev2_OpenClose,
format(d3.date, 'yyyy-MM') as period, case when d2.[Open]>d2.[Close] then 'Down' else 'Up' end as UpDown,
1.0*d2.TradeCount/d1.TradeCount TradeK, d1.Symbol, 
d1.Date Date1, d1.[Open] Open1, d1.High High1, d1.Low Low1, d1.[Close] Close1, d1.Volume Volume1, d1.TradeCount TradeCnt1, d1.volume/1000000.0 * d1.[close] Turnover1,
d2.Date Date2, d2.[Open] Open2, d2.High High2, d2.Low Low2, d2.[Close] Close2, d2.Volume Volume2, d2.TradeCount TradeCnt2, d2.volume/1000000.0 * d2.[close] Turnover2,
d3.Date Date3, d3.[Open] Open3, d3.High High3, d3.Low Low3, d3.[Close] Close3, d3.Volume Volume3, d3.TradeCount TradeCnt3, d3.volume/1000000.0 * d3.[close] Turnover3
into temp_OpenCloseDay
FROM dbQ2024..DayPolygon d1
inner join dbQ2024..TradingDays b on d1.Date=b.Date
left join dbQ2024..TradingShortened c1 on b.Next1=c1.Date
left join dbQ2024..TradingShortened c2 on b.Next2=c2.Date
inner join dbQ2024..DayPolygon d2 on d1.Symbol=d2.Symbol and b.Next1=d2.Date
inner join dbQ2024..DayPolygon d3 on d1.Symbol=d3.Symbol and b.Next2=d3.Date
left join dbQ2024..Splits s1 on s1.Symbol=d1.Symbol and s1.Date=d1.Date
left join dbQ2024..Splits s2 on s2.Symbol=d2.Symbol and s2.Date=d2.Date
left join dbQ2024..Splits s3 on s3.Symbol=d3.Symbol and s3.Date=d3.Date
where d1.IsTest is null and d2.tradecount>=5000 and d2.[close] >= 5 and d2.volume/1000000.0 * d2.[close]>=50
and b.IsShortened is null and c1.Date is null and c2.Date is null
and s1.Symbol is null and s2.Symbol is null and s3.Symbol is null 
and d3.Date between '2022-01-01' and '2024-01-01'

select * from temp_OpenCloseDay where turnover>=50

-- ================================
-- =======  Result for day  =======
-- ================================
-- !!! Attention: �� ����� ��������� ������������ ������, ��� ����� �������
-- (d3.[Open]-d3.[Close])/(d3.[Open]+d3.[Close]) * 200.0,
-- � ������� ����: (d3.[Open]-d3.[Close])/d3.[Open]*100
-- �� ���������� ������ ������ �� 20-50% ������
-- Compare by AbsChange=abs(Close-Open)/(Close+Open) AND (high2-low2)/(high2+low2)
;WITH CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date3 ORDER BY PrevChangeAbsOpenCLose desc),
	   ([Open3]-[Close3])/([Open3]) * 100.0 ProfitReal, *
	   FROM temp_OpenCloseDay where turnover>=50
    )
    SELECT avg(ProfitReal) ProfitReal, avg(Profit) Profit, count(*) Recs FROM CTE
    WHERE   RN <= 5 and PrevChangeAbsOpenCLose>=12 and Year(date3)=2023
-- 2,96852579460019	870 / 2023 year

-- !!!
;WITH CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date3 ORDER BY PrevChangeHighLow desc),
	   ([Open3]-[Close3])/([Open3]) * 100.0 ProfitReal, *
	   FROM temp_OpenCloseDay where turnover>=50
    )
    SELECT avg(ProfitReal) ProfitReal, avg(Profit) Profit, count(*) Recs FROM CTE
    WHERE   RN <= 5 and PrevChangeHighLow>=18.2 and Year(date3)=2023
-- 2,32324280586022	3,48739040092832	883 / 2023 year

-- Compare by AbsChange=abs(Close-Open)/(Close+Open) AND (high2-low2)/(high2+low2) 
-- By period
;WITH CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date3 ORDER BY PrevChangeAbsOpenCLose desc),
   	   ([Open3]-[Close3])/([Open3]) * 100.0 ProfitReal, *
	   FROM temp_OpenCloseDay where turnover>=50
    )
    SELECT period, avg(ProfitReal) ProfitReal, avg(Profit) Profit, count(*) Recs FROM CTE
    WHERE RN <= 5 and PrevChangeAbsOpenCLose>=12
	GROUP BY period order by 1

-- !!!
;WITH CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date3 ORDER BY PrevChangeHighLow desc),
	   ([Open3]-[Close3])/([Open3]) * 100.0 ProfitReal, *
	   FROM temp_OpenCloseDay where turnover>=50
    )
    SELECT period, avg(ProfitReal) ProfitReal, avg(Profit) Profit, count(*) Recs FROM CTE
    WHERE   RN <= 5 and PrevChangeHighLow>=18.2
	GROUP BY period order by 1

