;with data as
	(
		select ([Open]-[Close])/[Open]*100 PrevOpenRate, ([Open]-[Close])/([Open]+[Close])*200 PrevCO,
		([High]-[Low])/(High+Low)*200 PrevHL,
		a.*/*, b.MyType, b.Type, b.MsSector*/ from dbQ2024..DayPolygon a 
		inner join dbQ2024..SymbolsPolygon b on a.Symbol=b.Symbol and a.Date between b.Date and isnull(b.[To],'2099-12-31')
		inner join dbQ2024..TradingDays c on c.Prev1=a.Date
-- 		where a.IsTest is null and year(a.Date)>=2010 and
		where a.IsTest is null and year(a.Date) in (2022,2023) and
		-- c.IsShortened is null and
			a.Volume*a.[Close]>=50000000 and a.TradeCount>=10000 --and a.Low>=5.0
	),
	data2 as (
		select d.ProfitIn, c.Profit, (c.[Open]-c.[Close]) ProfitValue, a.* from data a
		inner join dbQ2024..TradingDays b on a.Date=b.Date
		inner join (select ([Open]-[Close])/[Open]*100 Profit, * from dbQ2024..DayPolygon where [Open]>=5.0) c
			on a.Symbol=c.Symbol and c.Date=b.Next1
		inner join (select ([OpenIn]-[CloseIn])/[OpenIn]*100 ProfitIn, *
			from dbQ2024Minute..MinutePolygonLog
--			where rowstatus in (2,5) and OpenIn>=5.0 and [Open]*0.95>LowBefore) d
			where rowstatus in (2,5) and OpenIn>=5.0) d
			on a.Symbol=d.Symbol and d.Date=b.Next1
	),
	data3 as (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date ORDER BY PrevHL DESC), *
	   FROM data2
	)

-- No filter:			0,608632415
-- [Open]*1.1>OpenIn:	0,541765151
-- [Open]*0.9<OpenIn:	0,483358644
-- [Open]*0.9<HighBefore:	0,61236171
-- [Open]*0.9<LowBefore:	0,367789331
-- [Open]*1.1>HighBefore:	0,398437238
-- [Open]*1.1>LowBefore:	0,608632415
-- !!![Open]*0.95>LowBefore (not many):	1,049762473


--	select avg(Profit) Profit, count(*) Recs, avg(PrevHL) PrevHL, ROUND(sum(ProfitValue),0) ProfitValue from data3
  --  WHERE RN<=5 and PrevHL>10
-- select year(date), avg(Profit) Profit, count(*) Recs, avg(PrevHL) PrevHL, ROUND(sum(ProfitValue),0) ProfitValue from data3
   -- WHERE RN<=5 and PrevHL>10 group by year(date) order by 1 -- and [Open]<[Close]
 select year(date) Year, avg(ProfitIn) ProfitIn, avg(Profit) Profit, count(*) Recs, avg(PrevHL) PrevHL, ROUND(sum(ProfitValue),0) ProfitValue from data3
   WHERE RN<=5 and PrevHL>8 group by year(date) order by 1 -- and [Open]<[Close]
