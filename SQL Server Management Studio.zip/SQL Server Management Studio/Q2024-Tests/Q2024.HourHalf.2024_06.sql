-- select * FROM dbQ2024Tests..temp_OpenCloseHourHalf3_2024_03 where symbol='NMRA' and date='2023-09-15'
-- select * FROM dbQ2024Tests3..Polygon30Min where symbol='NMRA' and date='2023-09-15'

/*
-- Without CTE:
select count(*), avg((h2.[OpenNext]-h2.[Final])/h2.[OpenNext] * 100.0) ProfitReal
from dbQ2024Tests3..Polygon30Min h1
inner join dbQ2024Tests3..Polygon30Min h2 on h1.Symbol=h2.Symbol and h1.Date=h2.Date and h1.[To]=h2.[Time]
inner join (select * from dbQ2024..TradingDays where IsShortened is null) d on h1.Date=d.Date
where year(h1.date)=2023 and h1.TradeCount>=500 and h1.[Close]*h1.[Volume]>=5000000 and h1.[close]>=5.0
and (h1.[High]-h1.[Low])/(h1.[High]+h1.[Low]) * 200.0 > 7
and h2.OpenNextDelayInMinutes is not null and h2.[Time] not in ('15:30:00')
and h2.OpenNextDelayInMinutes<3
and h1.[Count]>= iif(h2.Time='10:00:00', 15, 25)
-- and h1.HighTime>h1.LowTime
-- and h2.HighTimeBefore<h2.LowTimeBefore
*/

/*;with CTE AS
    (
       -- SELECT RN = ROW_NUMBER() OVER (PARTITION BY a.Date, a.[Time2] ORDER BY (a.PrevHL) desc), a.*
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY a.Date, a.[Time2] ORDER BY (a.BeforeHL) desc), a.*
	  --, b1.HighTimeBefore, b1.LowTimeBefore
	  --, b2.HighTime, b2.LowTime
	   FROM dbQ2024Tests..temp_OpenCloseHourHalf3_2024_03 a
--		inner join (select * from dbQ2024Tests3..Polygon30Min) b1 on a.Symbol=b1.Symbol and a.Date=b1.Date and a.Time2=b1.Time -- this timeframe
		inner join (select * from dbQ2024Tests3..Polygon30Min) b2 on a.Symbol=b2.Symbol and a.Date=b2.Date and a.Time2=b2.[To] -- previous timeframe
	   where year(a.Date)=2023
	   -- and b1.HighTimeBefore>b1.LowTimeBefore
	   -- and b2.HighTime>b2.LowTime
	   -- and DATEDIFF(minute, b2.HighTime, time2)<15
	   -- and DATEDIFF(minute, b2.LowTime, time2)>15
 	   and a.Count1>= iif(a.time2='10:00:00', 15, 25)
	   -- no filter: 0,1363 for 7440 rows
	   -- and a.Turnover1 between 5 and 1000
	   -- and TradeCount1>5000
	  --  and PrevWma_20>Wma_20
	   -- and OpenNext<Open2
	   -- and Open2<a.Wma_20
	   -- and Open2<b2.Wma_20*1.025 -- (b2 - prev timeframe, b1 - this timeframe (not valid)); Open2<b2.Wma_20 * 1.025 = ProfitReal*Recs=1659 and 5004 rows (ProfitReal=0.3316%) if a.PrevHL>5
	   and a.PrevHL>7 -- Optimal PrevHL>5: Profit*Recs=1738 for 6869 rows (2023), (ProfitReal=0.253%)
	   -- and BeforeHL>17
	   -- and UpDown='Down'
	   -- and PrevOC>5
	   and a.OpenNextDelayInMinutes<3 -- OpenNextDelayInMinutes=1: 0.1389 for 7440
	   -- and Close1 between 10 and 200
    )
--    SELECT a.*, b.*
	--FROM CTE a 
--	inner join (select * from dbQ2024Tests3..Polygon30Min) b on a.Symbol=b.Symbol and a.Date=b.Date and a.To2=b.Time
	--WHERE RN <=5 and b.HighTimeBefore=b.LowTimeBefore
--	order by [to] desc
    SELECT '--' "--", '00:00:00' Time, Round(avg(ProfitReal)*count(*),0) "ProfitReal*Recs",
		ROUND(avg(ProfitReal),4) ProfitReal, ROUND(avg(ProfitNext),4) ProfitNext, sum(NoFinal) NoFinal,
		ROUND(Avg(PrevHL),4) AvgPrevHL, ROUND(Avg(PrevOC),4) AvgPrevOC,
		count(*) Recs, min(TradeCount2) MinTradeCount2,
		ROUND(Avg(Volume1/TradeCount1),1) OneTradeShares, ROUND(Avg(Volume1/TradeCount1*Close1),1) OneTradeValue
		-- min(HighTimeBefore), min(LowTimeBefore), max(HighTimeBefore), max(LowTimeBefore)
		--, min(HighTime) MinHighTime, min(LowTime) MinLowTime, max(HighTime) MaxHighTime, max(LowTime) MaxLowTime,
		-- min(DATEDIFF(minute, HighTime, time2))
	FROM CTE a
	WHERE RN <=5
	UNION
    SELECT '--' "--", Time2, Round(avg(ProfitReal)*count(*),0) "ProfitReal*Recs",
		ROUND(avg(ProfitReal),4) ProfitReal, ROUND(avg(ProfitNext),4) ProfitNext, sum(NoFinal) NoFinal,
		ROUND(Avg(PrevHL),4) AvgPrevHL, ROUND(Avg(PrevOC),4) AvgPrevOC,
		count(*) Recs, min(TradeCount2) MinTradeCount2,
		ROUND(Avg(Volume1/TradeCount1),1) OneTradeShares, ROUND(Avg(Volume1/TradeCount1*Close1),1) OneTradeValue
		-- min(HighTimeBefore), min(LowTimeBefore), max(HighTimeBefore), max(LowTimeBefore)
		--, min(HighTime) MinHighTime, min(LowTime) MinLowTime, max(HighTime) MaxHighTime, max(LowTime) MaxLowTime,
		-- avg(DATEDIFF(minute, HighTime, time2))
	FROM CTE a 
	WHERE RN <=5
	group by Time2 order by 1*/
-- ORDER BY (a.BeforeHL); year(a.Date)=2023 and b.HighTimeBefore<b.LowTimeBefore and
--		a.Count1>= iif(a.time2='10:00:00', 15, 25) and a.PrevHL>3 and a.OpenNextDelayInMinutes<3
-- WHERE RN <=5
--	Time	ProfitReal	ProfitNext	NoFinal	AvgPrevHL	AvgPrevOC	Recs	MinTradeCount2	OneTradeShares	OneTradeValue

-- RETURN;

-- ==================
-- No temporary table
-- ==================
-- Details:
;with CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY a.Date, a.[Time2] ORDER BY (a.PrevHL) desc), a.*
       -- SELECT RN = ROW_NUMBER() OVER (PARTITION BY a.Date, a.[Time2] ORDER BY (a.BeforeHL) desc), a.*
	   FROM dbQ2024Tests3..vPolygon30Min a
	   where NoFinal=0 
	   -- year(a.Date)=2023
 	   and a.Count1>= iif(a.time2='10:00:00', 15, 25)
	   -- and a.time2<>'12:30:00'
	   -- and HighTimeBefore<LowTimeBefore
	   -- and HighTime<LowTime
	   -- and DATEDIFF(minute, b2.HighTime, time2)<15
	   -- and DATEDIFF(minute, b2.LowTime, time2)>15
	   -- no filter: 0,1363 for 7440 rows
	   -- and a.Turnover1 between 5 and 1000
	   -- and TradeCount1>5000
	   -- and PrevWma_20<Wma_20 -- !? PrevWma_20<Wma_20
	   -- and OpenNext<Open2
	   -- and Open2<a.Wma_20
	   -- and Open2>a.Wma_10
	   -- and Open2<Wma_20*1.025 -- (b2 - prev timeframe, b1 - this timeframe (not valid)); Open2<b2.Wma_20 * 1.025 = ProfitReal*Recs=1659 and 5004 rows (ProfitReal=0.3316%) if a.PrevHL>5
	   and a.PrevHL>5 -- Optimal PrevHL>5: Profit*Recs=1738 for 6869 rows (2023), (ProfitReal=0.253%)
	   -- and a.BeforeHL>7
	   -- and UpDown='Up'
	   -- and PrevOC>5
	   and a.OpenNextDelayInMinutes<3 -- OpenNextDelayInMinutes=1: 0.1389 for 7440
	   -- and Close1 between 10 and 200
	)
    SELECT '--' "--", 
		-- 0 as YEAR,
		'' as Period,
		-- '00:00:00' Time, 
		Round(avg(ProfitReal)*count(*),0) "ProfitReal*Recs",
		count(*) Recs, 
		ROUND(sum(iif(ProfitReal>0, 1.0, 0.0))/count(*)*100,1) ProfitPercent, 
		ROUND(avg(ProfitReal),4) ProfitReal, 
		ROUND(avg(ProfitReal5Min),4) ProfitReal5Min, 
		ROUND(avg(ProfitReal10Min),4) ProfitReal10Min, 
		ROUND(avg(ProfitReal15Min),4) ProfitReal15Min, 
		ROUND(avg(ProfitReal20Min),4) ProfitReal20Min, 
		ROUND(avg(ProfitNext),4) ProfitNext, sum(NoFinal) NoFinal,
		ROUND(Avg(PrevHL),4) AvgPrevHL, ROUND(Avg(PrevOC),4) AvgPrevOC,
		min(TradeCount2) MinTradeCount2,
		ROUND(Avg(Volume1/TradeCount1),1) OneTradeShares, ROUND(Avg(Volume1/TradeCount1*Close1),1) OneTradeValue
		-- min(HighTimeBefore), min(LowTimeBefore), max(HighTimeBefore), max(LowTimeBefore)
		--, min(HighTime) MinHighTime, min(LowTime) MinLowTime, max(HighTime) MaxHighTime, max(LowTime) MaxLowTime,
		-- min(DATEDIFF(minute, HighTime, time2))
	FROM CTE a
	WHERE RN <=5
	UNION
    SELECT '--' "--",
		YEAR(Date) as YEAR,
		-- format(date, 'yyyy-MM') as Period,
		-- Time2,
		Round(avg(ProfitReal)*count(*),0) "ProfitReal*Recs",
		count(*) Recs, 
		ROUND(sum(iif(ProfitReal>0, 1.0, 0.0))/count(*)*100,1) ProfitPercent, 
		ROUND(avg(ProfitReal),4) ProfitReal, 
		ROUND(avg(ProfitReal5Min),4) ProfitReal5Min, 
		ROUND(avg(ProfitReal10Min),4) ProfitReal10Min, 
		ROUND(avg(ProfitReal15Min),4) ProfitReal15Min, 
		ROUND(avg(ProfitReal20Min),4) ProfitReal20Min, 
		ROUND(avg(ProfitNext),4) ProfitNext, sum(NoFinal) NoFinal,
		ROUND(Avg(PrevHL),4) AvgPrevHL, ROUND(Avg(PrevOC),4) AvgPrevOC,
		min(TradeCount2) MinTradeCount2,
		ROUND(Avg(Volume1/TradeCount1),1) OneTradeShares, ROUND(Avg(Volume1/TradeCount1*Close1),1) OneTradeValue
		-- min(HighTimeBefore), min(LowTimeBefore), max(HighTimeBefore), max(LowTimeBefore)
		--, min(HighTime) MinHighTime, min(LowTime) MinLowTime, max(HighTime) MaxHighTime, max(LowTime) MaxLowTime,
		-- avg(DATEDIFF(minute, HighTime, time2))
	FROM CTE a 
	WHERE RN <=5
	-- group by Time2 order by 2
	group by YEAR(Date) order by 2
	-- group by format(date, 'yyyy-MM') order by 2
	-- group by YEAR(Date), Time2 order by 2, 3

RETURN;

-- Summary
select count(*), avg((h2.[OpenNext]-h2.[Final])/h2.[OpenNext] * 100.0) ProfitReal
from dbQ2024Tests3..Polygon30Min h1
inner join dbQ2024Tests3..Polygon30Min h2 on h1.Symbol=h2.Symbol and h1.Date=h2.Date and h1.[To]=h2.[Time]
inner join (select * from dbQ2024..TradingDays where IsShortened is null) d on h1.Date=d.Date
where year(h1.date)=2023 and h1.TradeCount>=500 and h1.[Close]*h1.[Volume]>=5000000 and h1.[close]>=5.0
and (h1.[High]-h1.[Low])/(h1.[High]+h1.[Low]) * 200.0 > 7
and h2.OpenNextDelayInMinutes is not null and h2.[Time] not in ('15:30:00')
and h2.OpenNextDelayInMinutes<3
and h1.[Count]>= iif(h2.Time='10:00:00', 15, 25)
-- and h1.HighTime<h1.LowTime
-- and h2.HighTimeBefore<h2.LowTimeBefore

RETURN;

-- ===============
-- Summary by year
-- ===============
select year(h1.date), count(*)
, avg((h2.[OpenNext]-h2.[Final5Min])/h2.[OpenNext] * 100.0) ProfitReal5Min
, avg((h2.[OpenNext]-h2.[Final10Min])/h2.[OpenNext] * 100.0) ProfitReal10Min
, avg((h2.[OpenNext]-h2.[Final15Min])/h2.[OpenNext] * 100.0) ProfitReal15Min
, avg((h2.[OpenNext]-h2.[Final20Min])/h2.[OpenNext] * 100.0) ProfitReal20Min
, avg((h2.[OpenNext]-h2.[Final])/h2.[OpenNext] * 100.0) ProfitReal
from dbQ2024Tests3..Polygon30Min h1
inner join dbQ2024Tests3..Polygon30Min h2 on h1.Symbol=h2.Symbol and h1.Date=h2.Date and h1.[To]=h2.[Time]
inner join (select * from dbQ2024..TradingDays where IsShortened is null) d on h1.Date=d.Date
where h1.TradeCount>=500 and h1.[Close]*h1.[Volume]>=5000000 and h1.[close]>=5.0
and (h1.[High]-h1.[Low])/(h1.[High]+h1.[Low]) * 200.0 > 12
and h2.OpenNextDelayInMinutes is not null and h2.[Time] not in ('15:30:00')
and h2.OpenNextDelayInMinutes<3
and h1.[Count]>= iif(h2.Time='10:00:00', 15, 25)
-- and h1.HighTime<h1.LowTime
-- and h2.HighTimeBefore<h2.LowTimeBefore
group by year(h1.date) order by 1
