-- see also E:\Users\System\Documents\SQL Server Management Studio\Q2024-Tests\Q2024.Days.2024-03-01.sql

;with data as
	(
		select (a.[Open]-a.[Close])/a.[Open]*100 PrevOpenRate,
		(a.[Open]-a.[Close])/(a.[Open]+a.[Close])*200 PrevCO,
		(a.[High]-a.[Low])/(a.High+a.Low)*200 PrevHL,
		a.*, b.MyType, b.Sector from dbQ2024..DayPolygon a 
		inner join dbQ2024..SymbolsPolygon b on a.Symbol=b.Symbol and a.Date between b.Date and isnull(b.[To],'2099-12-31')
		-- inner join dbQ2024Minute..MinutePolygonLog c on c.Symbol=a.Symbol and c.Date=a.Date
		where a.IsTest is null and year(a.Date) in (2022,2023) and
			a.Volume*a.[Close]>=50000000 and a.TradeCount>=10000 --and a.Low>=5.0
			--and c.Count between 330 and 335  -- is worse
			--and a.[Open]<=a.Low + 2.0/3.0*(a.High-a.Low) and a.[Close]<=a.Low + 2.0/3.0*(a.High-a.Low)  -- is worse
 			--and a.[Open] between a.Low*1.05 and a.High*0.95  -- is worse
			-- 2,29973874921762	1070	36,9982769386791	1071
			-- !!?? and a.[Close] between a.Low*1.05 and a.High*0.95  -- !!?? is worse
			-- 1,71267929428642	1585	38,4622468460998	1648
	),
	data2 as (
		select (c.[Open]-c.[Close])/c.[Open]*100 Profit, (c.[Open]-c.[Close]) ProfitValue, 
iif (HighIn-OpenIn<0.01,OpenIn-CloseIn,-0.01)/OpenIn*100 Amt1,
iif (HighIn-OpenIn<0.02,OpenIn-CloseIn,-0.02)/OpenIn*100 Amt2,
iif (HighIn-OpenIn<0.05,OpenIn-CloseIn,-0.05)/OpenIn*100 Amt5,
iif (HighIn-OpenIn<OpenIn*0.01,OpenIn-CloseIn,-OpenIn*0.01)/OpenIn*100 Amt1P,
iif (HighIn-OpenIn<OpenIn*0.02,OpenIn-CloseIn,-OpenIn*0.02)/OpenIn*100 Amt2P,
iif (HighIn-OpenIn<OpenIn*0.05,OpenIn-CloseIn,-OpenIn*0.05)/OpenIn*100 Amt5P,
iif (HighIn-OpenIn<0.01,1,0) Cnt1,
iif (HighIn-OpenIn<0.02,1,0) Cnt2,
iif (HighIn-OpenIn<0.05,1,0) Cnt5,
iif (HighIn-OpenIn<OpenIn*0.01,1,0) Cnt1P,
iif (HighIn-OpenIn<OpenIn*0.02,1,0) Cnt2P,
iif (HighIn-OpenIn<OpenIn*0.05,1,0) Cnt5P,
		a.* from data a
		inner join dbQ2024..TradingDays b on a.Date=b.Date
		inner join (select High HighIn, [Open] OpenIn, [Close] CloseIn, * from dbQ2024..DayPolygon
		 where [Open]>=5.0)
		c on a.Symbol=c.Symbol and c.Date=b.Next1
		--and c.[Open] between a.Low and a.High -- is worse
		--and (c.[Open] <= a.Low or c.[Open]>=a.High) -- is worse
	),
	data3 as (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date ORDER BY PrevHL DESC), *
	   FROM data2
	)

	-- select * from data3 WHERE RN<=5 and PrevHL>15 -- and [Open]<[Close]

	select ROUND(avg(Profit),3) Profit, count(*) Recs, ROUND(avg(PrevHL),2) PrevHL,
	ROUND(sum(ProfitValue),0) ProfitValue,
ROUND(avg(Amt1),3) Amt1, 
ROUND(avg(Amt2),3) Amt2, 
ROUND(avg(Amt5),3) Amt5, 
ROUND(avg(Amt1P),3) Amt1P, 
ROUND(avg(Amt2P),3) Amt2P, 
ROUND(avg(Amt5P),3) Amt5P, 
cast(ROUND(100.0*sum(Cnt1)/count(*),1) as real) Cnt1, 
cast(ROUND(100.0*sum(Cnt2)/count(*),1) as real) Cnt2, 
cast(ROUND(100.0*sum(Cnt5)/count(*),1) as real) Cnt5,
cast(ROUND(100.0*sum(Cnt1P)/count(*),1) as real) Cnt1P, 
cast(ROUND(100.0*sum(Cnt2P)/count(*),1) as real) Cnt2P, 
cast(ROUND(100.0*sum(Cnt5P)/count(*),1) as real) Cnt5P 
	from data3
    WHERE RN<=5 and PrevHL>15 -- and [Open]<[Close]

/* *** NEW RESULT (year(a.Date) in (2022,2023) and a.Volume*a.[Close]>=50000000 and a.TradeCount>=10000)
PrevHL desc, RN<=5:	1,45856221206561	2505	34,0491688760693	1509
PrevHL(>15) desc, RN<=5:	1,60621828757514	2307	35,8555602444474	1496
[Open]<[Close], RN<=5:	1,69248202985725	1461	36,8306548799414	739
[Open]<[Close], PrevHL(>15) desc, RN<=5:	1,84209529867617	1362	38,5590942469637	753
*/

/* *** OLD RESULT (year(a.Date) in (2022,2023) and a.Volume*a.[Close]>=50000000 and a.TradeCount>=5000)
PrevHL desc, RN=5: 1,45840094434079	2505	1486
PrevHL(>15) desc, RN=5: 1,60664487931608	2307	1494
PrevHL(>20) desc, RN=5: 2,09192811379787	1740	1471
PrevHL(>25) desc, RN=5: 2,82318279959227	1284	1467
PrevHL(>30) desc, RN=5: 3,60795701275943	951	1483
PrevHL(>35) desc, RN=5: 4,2400278066021	748	1397
PrevHL desc, RN=10: 0,738772196036962	5010	1363
PrevHL desc, RN=25: 0,287135720958737	12525 1455
PrevCO desc, RN=5: 0,675292429198583	2505
PrevOpenRate desc, RN=5: 0,675292429198583	2505
PrevCO asc, RN=5: 0,820855568293594	2505
PrevOpenRate asc, RN=5: 0,820855568293594	2505
** END OF OLD RESULT
*/