use dbQ2024Tests;
-- =======================
-- New method (2024-02-29)
-- =======================
/*;with data as
	(
		select ([Open]-[Close])/[Open]*100 PrevOpenRate, ([Open]-[Close])/([Open]+[Close])*200 PrevCOProfit,
		([High]-[Low])/(High+Low)*200 PrevHLProfit,
		a.*, b.MyType, b.Sector from dbQ2024..DayPolygon a 
		inner join dbQ2024..SymbolsPolygon b on a.Symbol=b.Symbol and a.Date between b.Date and isnull(b.[To],'2099-12-31')
		where a.IsTest is null and year(a.Date) in (2022,2023) and
			a.Volume*a.[Close]>=50000000 and a.TradeCount>=5000
	)
	select avg(a.PrevOpenRate), avg(a.PrevCOProfit), avg(a.PrevHLProfit),
	avg(c.Profit), count(*) Recs from data a
	inner join dbQ2024..TradingDays b on a.Date=b.Date
	inner join (select ([Open]-[Close])/[Open]*100 Profit, * from dbQ2024..DayPolygon where [Open]>=5.0)
		c on a.Symbol=c.Symbol and c.Date=b.Next1
	-- where abs(a.PrevHLProfit)>12 -- 9807/0.35
	-- where abs(a.PrevCOProfit)>8.5 -- 9083/0.22
	-- where abs(a.PrevOpenRate)>8.5 -- 9087/0.16
	-- where a.PrevOpenRate>6.2 -- 9431/0.32
	-- where a.PrevOpenRate<-6.7 -- 9493/-0.11
*/

/*;with data as
	(
		select ([Open]-[Close])/[Open]*100 PrevOpenRate, ([Open]-[Close])/([Open]+[Close])*200 PrevCOProfit,
		([High]-[Low])/(High+Low)*200 PrevHLProfit,
		a.*, b.MyType, b.Sector from dbQ2024..DayPolygon a 
		inner join dbQ2024..SymbolsPolygon b on a.Symbol=b.Symbol and a.Date between b.Date and isnull(b.[To],'2099-12-31')
		where a.IsTest is null and year(a.Date) in (2022,2023) and
			a.Volume*a.[Close]>=50000000 and a.TradeCount>=5000
	),
	data2 as (
		select (c.[Open]-c.[Close])/c.[Open]*100 Profit, (c.[Open]-c.[Close]) ProfitValue, a.* from data a
		inner join dbQ2024..TradingDays b on a.Date=b.Date
--		inner join (select ([Open]-[Close])/[Open]*100 Profit, * from dbQ2024..DayPolygon where [Open]>=5.0)
		inner join dbQ2024..DayPolygon c on a.Symbol=c.Symbol and c.Date=b.Next1 and c.[Open]>=5.0
	),
	data3 as (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date ORDER BY PrevHLProfit DESC), *
	   FROM data2
	)

	select avg(Profit), count(*), avg(PrevHLProfit), ROUND(sum(ProfitValue),0) ProfitValue from data3
    WHERE   RN <= 5
-- PrevHLProfit desc, RN=5: 1,45840094434079	2505	1486
-- PrevHLProfit(>15) desc, RN=5: 1,60664487931608	2307	1494
-- PrevHLProfit(>20) desc, RN=5: 2,09192811379787	1740	1471
-- PrevHLProfit(>25) desc, RN=5: 2,82318279959227	1284	1467
-- PrevHLProfit(>30) desc, RN=5: 3,60795701275943	951	1483
-- PrevHLProfit(>35) desc, RN=5: 4,2400278066021	748	1397
-- PrevHLProfit desc, RN=10: 0,738772196036962	5010	1363
-- PrevHLProfit desc, RN=25: 0,287135720958737	12525 1455
-- PrevCOProfit desc, RN=5: 0,675292429198583	2505
-- PrevOpenRate desc, RN=5: 0,675292429198583	2505
-- PrevCOProfit asc, RN=5: 0,820855568293594	2505
-- PrevOpenRate asc, RN=5: 0,820855568293594	2505*/

/*-- By Sector (conclusion: sector doesn't affect on the result)
;with data as
	(
		select ([Open]-[Close])/[Open]*100 PrevOpenRate, ([Open]-[Close])/([Open]+[Close])*200 PrevCOProfit,
		([High]-[Low])/(High+Low)*200 PrevHLProfit,
		a.*, b.MyType, b.Sector from DayPolygon a 
		inner join SymbolsPolygon b on a.Symbol=b.Symbol and a.Date between b.Date and isnull(b.[To],'2099-12-31')
		where a.IsTest is null and year(a.Date) in (2022,2023) and
			a.Volume*a.[Close]>=50000000 and a.TradeCount>=5000
	),
	data2 as (
		select c.Profit, (c.[Open]-c.[Close]) ProfitValue, a.* from data a
		inner join TradingDays b on a.Date=b.Date
		inner join (select ([Open]-[Close])/[Open]*100 Profit, * from DayPolygon where [Open]>=5.0)
		c on a.Symbol=c.Symbol and c.Date=b.Next1
	),
	data3 as (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date ORDER BY PrevHLProfit DESC), *
	   FROM data2
	)

	select sector, avg(Profit), count(*), avg(PrevHLProfit), ROUND(sum(ProfitValue),0) ProfitValue from data3
    WHERE   RN <= 25 group by Sector order by 1

;with data as
	(
		select ([Open]-[Close])/[Open]*100 PrevOpenRate, ([Open]-[Close])/([Open]+[Close])*200 PrevCOProfit,
		([High]-[Low])/(High+Low)*200 PrevHLProfit,
		a.*, b.MyType, b.Sector from DayPolygon a 
		inner join SymbolsPolygon b on a.Symbol=b.Symbol and a.Date between b.Date and isnull(b.[To],'2099-12-31')
		where a.IsTest is null and year(a.Date) in (2022,2023) and
			a.Volume*a.[Close]>=50000000 and a.TradeCount>=5000
	),
	data2 as (
		select c.Profit, (c.[Open]-c.[Close]) ProfitValue, a.* from data a
		inner join TradingDays b on a.Date=b.Date
		inner join (select ([Open]-[Close])/[Open]*100 Profit, * from DayPolygon where [Open]>=5.0)
		c on a.Symbol=c.Symbol and c.Date=b.Next1
	),
	data3 as (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date ORDER BY PrevHLProfit DESC), *
	   FROM data2 WHERE Sector is null or  Sector in ('Industrials', 'Utilities', 'Energy', 'Real Estate',
	    'Communication Services', 'Consumer Discretionary', 'Financials','Consumer Staples')
	)

	select avg(Profit), count(*), avg(PrevHLProfit), ROUND(sum(ProfitValue),0) ProfitValue from data3
    WHERE   RN <= 5
-- allsectors, RN=5: 1,45840094434079	2505	1487	
-- no bad sectors, RN=5: 1,2988042749115 2505 1282	(worse)*/

-- =========================
-- Restore method at 2023-12 (!! ���� �������)
-- =========================
/*;with data as
	(
		SELECT (d2.[High]-d2.[Low])/(d2.High+d2.Low)*200 PrevHLProfit,
		(d3.[Open]-d3.[Close])/d3.[Open]*100 Profit,
		(d3.[Open]-d3.[Close])/(d3.[Open]+d3.[Close])*200 Profit2,
		d3.*
		FROM dbQ2024..DayPolygon d1
		inner join dbQ2024..TradingDays b on d1.Date=b.Date
		left join dbQ2024..TradingShortened c1 on b.Next1=c1.Date
		left join dbQ2024..TradingShortened c2 on b.Next2=c2.Date
		inner join dbQ2024..DayPolygon d2 on d1.Symbol=d2.Symbol and b.Next1=d2.Date
		inner join dbQ2024..DayPolygon d3 on d1.Symbol=d3.Symbol and b.Next2=d3.Date
		left join dbQ2023Others..Splits s1 on s1.Symbol=d1.Symbol and s1.Date=d1.Date
		left join dbQ2023Others..Splits s2 on s2.Symbol=d2.Symbol and s2.Date=d2.Date
		left join dbQ2023Others..Splits s3 on s3.Symbol=d3.Symbol and s3.Date=d3.Date
		where d1.IsTest is null and d2.tradecount>=5000 and d2.[close] >= 5 and d2.volume/1000000.0 * d2.[close]>=50
			and b.IsShortened is null and c1.Date is null and c2.Date is null
			and s1.Symbol is null and s2.Symbol is null and s3.Symbol is null 
			-- and d3.Date between '2016-01-01' and '2017-01-01'
	),
	CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date ORDER BY PrevHLProfit desc), *
	   FROM data
    )
    SELECT avg(Profit) ProfitAs_2024_02 /* more exact*/, avg(Profit2) ProfitAs_2023_12, count(*) FROM CTE
    WHERE   RN <= 5 and PrevHLProfit>=18.2
	-- group by year(Date) order by 1

-- Year=2023, PrevHLProfit>=18.2, RN=5: 2,32324280586022	3,48739040092832	883
-- Year=2022, PrevHLProfit>=18.2, RN=5: 0,856213545519421	2,13384988343807	1065
-- Years=2022-2023, PrevHLProfit>=18.2, RN=5: 1,52119652133098	2,74739006667415	1948
-- Year=2016, PrevHLProfit>=18.2, RN=5: 0,734215050636448	1,58997380092231	585
-- !!! By year (from 2003), PrevHLProfit>=18.2, RN=5: Average Profit: 0.14-2.3%	Rows: 185-1236
-- !!! By year (from 2003), PrevHLProfit>=12, RN=5: Average Profit: 0.2-1.8%	Rows: 680-1245
-- Years=2003-2024, PrevHLProfit>=12, RN=5: 0,872073217205912	1,44212456444285	20287
-- Years=2003-2024, PrevHLProfit>=18.2, RN=5: 1,20765498591556	2,09789237189119	11470*/

-- =========================
-- ������ ��������� ���������
-- =========================
-- drop table temp_OpenClose_2024_02;
/*;with cte as (
		select * from dbQ2024..DayPolygon where TradeCount>0
	)
	SELECT
	 (d1.[Open]-d1.[Close])/(d1.[Open]+d1.[Close])*200 OC1,
	 (d2.[Open]-d2.[Close])/(d2.[Open]+d2.[Close])*200 OC2,
	 (d1.[High]-d1.[Low])/(d1.High+d1.Low)*200 HL1,
	 (d2.[High]-d2.[Low])/(d2.High+d2.Low)*200 HL2,
		(d3.[Open]-d3.[Close])/d3.[Open]*100 Profit,
		(d3.[Open]-d3.[Close])/(d3.[Open]+d3.[Close])*200 Profit2_Bad,
d1.Symbol, s.Sector, s.SectorSource,
d1.Date Date1, d1.[Open] Open1, d1.High High1, d1.Low Low1, d1.[Close] Close1, d1.Volume Volume1, d1.TradeCount TradeCnt1, d1.volume/1000000.0 * d1.[close] Turnover1,
d2.Date Date2, d2.[Open] Open2, d2.High High2, d2.Low Low2, d2.[Close] Close2, d2.Volume Volume2, d2.TradeCount TradeCnt2, d2.volume/1000000.0 * d2.[close] Turnover2,
d3.Date Date3, d3.[Open] Open3, d3.High High3, d3.Low Low3, d3.[Close] Close3, d3.Volume Volume3, d3.TradeCount TradeCnt3, d3.volume/1000000.0 * d3.[close] Turnover3
into temp_OpenClose_2024_02
		FROM cte d1
		inner join dbQ2024..SymbolsPolygon s on d1.Symbol=s.Symbol and d1.Date between s.Date and isnull(s.[To],'2099-12-31')
		inner join dbQ2024..TradingDays b on d1.Date=b.Date
		left join dbQ2024..TradingShortened c1 on b.Next1=c1.Date
		left join dbQ2024..TradingShortened c2 on b.Next2=c2.Date
		inner join cte d2 on d1.Symbol=d2.Symbol and b.Next1=d2.Date
		inner join cte d3 on d1.Symbol=d3.Symbol and b.Next2=d3.Date
		left join dbQ2023Others..Splits s1 on s1.Symbol=d1.Symbol and s1.Date=d1.Date
		left join dbQ2023Others..Splits s2 on s2.Symbol=d2.Symbol and s2.Date=d2.Date
		left join dbQ2023Others..Splits s3 on s3.Symbol=d3.Symbol and s3.Date=d3.Date
		where d1.IsTest is null and d2.tradecount>=5000 and d2.[close] >= 5
			and d2.volume/1000000.0 * d2.[close]>=50
			and b.IsShortened is null and c1.Date is null and c2.Date is null
			and s1.Symbol is null and s2.Symbol is null and s3.Symbol is null 
			and d3.Date between '2022-01-01' and '2024-01-01'
*/
/*;with CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date3 ORDER BY HL2 desc), *
	   FROM temp_OpenClose_2024_02 WHERE HL2>18.2
    )
    SELECT avg(Profit) ProfitAs_2024_02 /* more exact*/, 
	avg(Profit2_Bad) ProfitAs_2023_12, Avg(HL2) AvgHL2, Min(TradeCnt3) MinTradeCount3,
		Min(Turnover3) MinTurnover3, count(*) Recs
	FROM CTE WHERE RN <= 5
-- 2022-2023, HL2>=18.2, RN=5: 1,52119652133098	2,74739006667415	38,292175897093	1988	1,563016	1948
-- 2022-2023, HL2>=12, RN=5: 1,24839866932298	2,27382729276568	33,9098714774041	1988	1,563016	2417
-- 2022-2023, RN=5: 1,20773810732777	2,21696148833745	33,5134905826755	1988	1,563016	2460*/

/*;with CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date3 ORDER BY HL2 desc), *
	   FROM temp_OpenClose_2024_02
--	   where (Sector is null or Sector<>'Information Technology') and HL2>18.2
	   where Symbol not in (select ticker from dbQ2024Temp..Indices /*where [Index]='DJI'*/) and
	   -- HL2>12 and
	   (SectorSource is null or SectorSource not like '%SP[6,4]%')
	   and (Sector is null or Sector<>'Information Technology')
    )
    SELECT avg(Profit) ProfitAs_2024_02 /* more exact*/, 
		Avg(HL2) AvgHL2, Min(TradeCnt3) MinTradeCount3,
		Min(Turnover3) MinTurnover3, count(*) Recs
	FROM CTE WHERE RN <=5
-- !!! 2022-2023, order=HL2 desc, RN=5: 1,20773810732777	33,5134905826755	1988	1,563016	2460
-- 2022-2023, order=(High2-Close2)/(High2+Close2) desc, RN=5: 1,15820379624204	27,5669982921786	1594	1,563016	2460
-- 2022-2023, order=(High2-Close2)/(High2+Close2) asc, RN=5: -0,0514793654687975	1,86733685019237	816	4,971927	2460
-- 2022-2023, order=(High2-Open2)/(High2+Open2) desc, RN=5: 0,917459650340725	28,7137898332704	1988	1,598045	2460
-- 2022-2023, order=(High2-Open2)/(High2+Open2) asc, RN=5: -0,00295847761501535	3,51533500953782	1093	3,881169	2460
-- 2022-2023, order=(Open2-Low2)/(Open2+Low2) desc, RN=5: 0,611133047869444	22,9618388119752	2936	1,563016	2460
-- 2022-2023, order=(Open2-Low2)/(Open2+Low2) asc, RN=5: -0,0317662076192635	3,33721933195526	1707	4,120438	2460
-- 2022-2023, order=(Close2-Low2)/(Close2+Low2) desc, RN=5: 0,665484678111516	28,6171226201019	2437	1,563016	2460
-- 2022-2023, order=(Close2-Low2)/(Close2+Low2) asc, RN=5: 0,0162208233142226	1,66452262207063	1436	4,863506	2460
-- 2022-2023, order=(Max(High1,High2)-Min(Close1,Close2))/(1+2) desc, RN=5: 0,738161705182444	29,8352898896225	1455	1,563016	2460	39,7168528114877
-- 2022-2023, order=(High1-Low1)/(High1+Low1) desc, RN=5: 0,978894783012433	22,2588211889311	1594	1,563016	2460

-- !!! 2022-2023, order=HL2 desc, RN=5, sector<>Information Technology: 1,27187796865658	31,3533393049628	1988	1,563016	2460
-- !!! 2022-2023, order=HL2 desc, HL2>12, RN=5, sector<>Information Technology: 1,32312236286348	31,9220655945819	1988	1,563016	2393
-- !!! 2022-2023, order=HL2 desc, HL2>18.2, RN=5, sector<>Information Technology: 1,76899206736579	37,5057043329732	1988	1,563016	1786

-- Below for filter: (SectorSource is null or SectorSource not like '%Nasd%')
--	and (Sector is null or Sector<>'Information Technology')
-- !!! 2022-2023, order=HL2 desc, RN=5, : 1,27701181977139	31,2938211146409	1988	1,563016	2460
-- !!! 2022-2023, order=HL2 desc, HL2>12, RN=5, : 1,33402486819849	31,8696036195277	1988	1,563016	2392
-- !!! 2022-2023, order=HL2 desc, HL2>18.2, RN=5, : 1,79493635914437	37,5158708131735	1988	1,563016	1779

-- Below for filter: (SectorSource is null or SectorSource not like '%SP[6,4]%')
--	   and (Sector is null or Sector<>'Information Technology')
-- !!! 2022-2023, order=HL2 desc, RN=5, : 1,26018385838763	30,6562478073244	1988	1,563016	2460
-- !!! 2022-2023, order=HL2 desc, HL2>12, RN=5, : 1,34225374433293	31,6332758450051	1988	1,563016	2345
-- !!! 2022-2023, order=HL2 desc, HL2>18.2, RN=5, : 1,89819492999142	38,0211245942936	1988	1,563016	1686
*/
-- ===========================================
-- Remove bad tickers (�� ������ �� ���������)
-- ===========================================
/*;with CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date3 ORDER BY HL2 desc), *
	   FROM temp_OpenClose_2024_02 where year(Date3)=2023
	   -- and symbol not in ('HKD', 'IMUX', 'SKYH', 'TGTX', 'HUDI', 'PGY', 'BKKT', 'MARA', 'AERC', 'BYND', 'PTON', 'TAL', 'SOXS', 'AFRM', 'NERV', 'SI', 'BOIL', 'RELI', 'VERU', 'MSTR')
	   -- and HL2>18.2
    )
    SELECT avg(Profit) ProfitAs_2024_02 /* more exact*/, 
		Avg(HL2) AvgHL2, Min(TradeCnt3) MinTradeCount3,
		Min(Turnover3) MinTurnover3, count(*) Recs
	FROM CTE WHERE RN <=5
    -- SELECT symbol, avg(Profit) Profit, count(*)
	-- FROM CTE WHERE RN <=5
	-- group by symbol order by 2
-- 2022, RN=5: 0,690414682069733	34,5674536043598	1988	1,598045	1240
-- 2023, RN=5: 1,73354224447527	32,4422494786685	2899	1,563016	1220

-- After filter 20 most bad symbols (filter HL2>18.2 doesn't work)
-- 2022, RN=5: 1,33742618924908	32,1714132178214	1988	1,598045	1240
-- 2023, RN=5: 1,58592375894001	31,9320065654692	2899	1,563016	1220
*/
-- ===========================================
-- Link with hour data
-- ===========================================
;with CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date3 ORDER BY HL2 desc), *
	   FROM temp_OpenClose_2024_02 --where hl2>=18.0
	   wHERE (SectorSource is null or SectorSource not like '%SP[6,4]%')
	   and (Sector is null or Sector<>'Information Technology')
    ),
	hourData AS
	(
		select a.Profit, b.* from cte a inner join temp_OpenClose_Hour_2024_02 b
		on a.Symbol=b.Symbol and a.Date3=b.Date
		where a.RN<=5 and b.OpenNext>=5.0 
		--and b.PrevEma2_20>b.Ema2_20 and b.OpenNext<b.[Open] and b.[Open]<b.Ema2_20
		and b.OpenNextDelayInMinutes<3
	)
	-- select * from hourData;
    SELECT year(date), avg(([OpenNext]-[close])/[opennext]*100), count(*)
	FROM hourData a 
	group by year(date)order by 1,2
/*    SELECT year(date),[Time], avg(([OpenNext]-[close])/[opennext]*100), count(*)
	FROM hourData a 
	group by year(date), a.[Time] order by 1,2*/
/*    SELECT avg(Profit) ProfitAs_2024_02 /* more exact*/, 
		Avg(HL2) AvgHL2, Min(TradeCnt3) MinTradeCount3,
		Min(Turnover3) MinTurnover3, count(*) Recs
	FROM CTE WHERE RN <=5*/
