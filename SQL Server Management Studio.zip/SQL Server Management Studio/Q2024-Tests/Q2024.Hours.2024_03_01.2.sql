use dbQ2024Tests;

/* Check data - ok
SELECT year(h1.date), count(*) 
from dbQ2024..HourPolygon5 h1
inner join dbQ2024..HourPolygon5 h2 on h1.Symbol=h2.Symbol and h1.Date=h2.Date and h1.[To]=h2.[Time]
inner join dbQ2024..SymbolsPolygon s on h1.Symbol=s.Symbol and h1.Date between s.Date and isnull(s.[To], '2099-12-31')
inner join (select * from dbQ2024..TradingDays where IsShortened is null) d on h1.Date=d.Date
where h1.TradeCount>=1000 and h1.[Close]*h1.[Volume]>=1000000 and h1.[close]>=5.0
and h1.Date<='2024-01-01'
and h2.OpenNextDelayInMinutes is not null and h2.[Time] not in ('15:45:00', '12:45:00')
group by year(h1.date) order by 1
-- 2022	2452259
-- 2023	2273357

select year(date), count(*) from dbQ2024Tests..temp_OpenCloseHour_2024_03 group by year(date) order by 1
-- 2022	2452259
-- 2023	2272937
*/

/*select year(date), [Time], [To], min(date), max(date), count(*)  from dbQ2024..HourPolygon
where TradeCount>=1000 and [Close]*[Volume]>=5000000 and year(date)<=2023 and [Close]<5.0
group by year(date), [Time], [To] 
order by 2,3,1

select top 1000 * from dbQ2024..HourPolygon
select [Time],[To], count(*) from dbQ2024..HourPolygon
group by [Time],[To] order by 1,2

select count(*) from temp_OpenCloseHour_2024_03*/

-- Base SQL (no moving average) --
-- drop table temp_OpenCloseHour_2024_03
-- 2 minutes: 3043304 rows (h1.TradeCount>=1000 and h1.[Close]*h1.[Volume]>=5000000 and h1.[close]>=5.0)
-- 1:45 min: 2846402 rows  (h1.TradeCount>=1000 and h1.[Close]*h1.[Volume]>=5000000 and h1.[close]>=5.0), 2022-2023year, no Shortened days
-- 3:05 min: 4725196 rows  (h1.TradeCount>=1000 and h1.[Close]*h1.[Volume]>=1000000 and h1.[close]>=5.0), 2022-2023year, no Shortened days
/*select 
(h1.[Open]-h1.[Close])/(h1.[Open]+h1.[Close]) * 200.0 PrevOC,
(h1.[High]-h1.[Low])/(h1.[High]+h1.[Low]) * 200.0 PrevHL,
(h2.[OpenNext]-h2.[Final])/h2.[OpenNext] * 100.0 ProfitReal,
iif(h2.Final is null, 1,0) NoFinal,
h2.FinalDelayInMinutes,
(h2.[Open]-h2.[Close])/h2.[Open] * 100.0 Profit,
(h2.[OpenNext]-h2.[Close])/h2.[OpenNext] * 100.0 ProfitNext,
h1.[Close]*h1.[Volume]/1000000.0 Turnover,
format(h2.date, 'yyyy-MM') as Period,
case when h1.[Open]>h1.[Close] then 'Down' else 'Up' end as UpDown,
h1.Symbol, s.Exchange, s.MyType, h1.[Date], h2.[Time] Time2, h2.[To] To2,
h2.OpenNext, h2.OpenNextDelayInMinutes,
h2.PrevWma_20, h2.Wma_20, h2.PrevWma_30, h2.Wma_30, 
h2.PrevEma_20, h2.Ema_20, h2.PrevEma_30, h2.Ema_30, 
h2.PrevEma2_20, h2.Ema2_20, h2.PrevEma2_30, h2.Ema2_30, 
h1.[Open] Open1, h1.High High1, h1.Low Low1, h1.[Close] Close1, h1.Volume Volume1, h1.[Count] Count1, h1.TradeCount TradeCount1, h1.volume/1000000.0 * h1.[close] Turnover1,
h2.[Open] Open2, h2.High High2, h2.Low Low2, h2.[Close] Close2, h2.Volume Volume2, h2.[Count] Count2, h2.TradeCount TradeCount2, h2.volume/1000000.0 * h2.[close] Turnover2
into temp_OpenCloseHour_2024_03
from dbQ2024..HourPolygon h1
inner join dbQ2024..HourPolygon h2 on h1.Symbol=h2.Symbol and h1.Date=h2.Date and h1.[To]=h2.[Time]
inner join dbQ2024..SymbolsPolygon s on h1.Symbol=s.Symbol and h1.Date between s.Date and isnull(s.[To], '2099-12-31')
inner join (select * from dbQ2024..TradingDays where IsShortened is null) d on h1.Date=d.Date
where h1.TradeCount>=1000 and h1.[Close]*h1.[Volume]>=1000000 and h1.[close]>=5.0
and h1.Date<='2024-01-01'
and h2.OpenNextDelayInMinutes is not null and h2.[Time] not in ('15:45:00', '12:45:00')
*/

/*select Top 100 * from temp_OpenCloseHour_2024_03
select Top 100 * from dbQ2024..HourPolygon
select [Time2], count(*) from temp_OpenCloseHour_2024_03 group by [Time2] order by 1
select [Time], [To], count(*) from dbQ2024..HourPolygon group by [Time],[To] order by 1*/

;with CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date, [Time2] ORDER BY PrevHL desc),
	   	   iif(ProfitReal>0.0, 1.0, 0.0) ProfitRealCount, *
	   FROM temp_OpenCloseHour_2024_03 where year(Date)=2023
	   and Count1>=iif(time2='10:00:00',20, iif(time2='15:00:00',35,50))
	   and Turnover1 between 10 and 50
	   -- and TradeCount1>2000
	   -- and PrevWma_20<Wma_20
	   -- and OpenNext>Open2
	   -- and Open2>Wma_20
	   and PrevHL>12 -- PrevHL>7 = 0.86 for 1420 rows
	   -- and UpDown='Up'
	   -- and PrevOC>3 -- PrevOC<=-4.7 = 0.83 for 1380 rows
	   and OpenNextDelayInMinutes<3
	   -- and Close1 between 5 and 100
    )
--	select * into testNew2 from cte
    SELECT '--' "--", CAST('0:0:0' as Time(0)) Time,
		avg(ProfitReal) ProfitReal, sum(ProfitRealCount)/count(*)*100 ProfitRealCount,
		avg(ProfitNext) ProfitNext, sum(NoFinal) NoFinal,
		Avg(PrevHL) AvgPrevHL, Avg(PrevOC) AvgPrevOC, count(*) Recs, min(TradeCount2) MinTradeCount2,
		Avg(Volume1/TradeCount1) OneTradeShares, Avg(Volume1/TradeCount1*Close1) OneTradeValue
	FROM CTE WHERE RN <=5
	UNION
    SELECT '--' "--", Time2,
		avg(ProfitReal) ProfitReal, sum(ProfitRealCount)/count(*)*100 ProfitRealCount,
		avg(ProfitNext) ProfitNext, sum(NoFinal) NoFinal,
		Avg(PrevHL) AvgPrevHL, Avg(PrevOC) AvgPrevOC, count(*) Recs, min(TradeCount2) MinTradeCount2,
		Avg(Volume1/TradeCount1) OneTradeShares, Avg(Volume1/TradeCount1*Close1) OneTradeValue
	FROM CTE WHERE RN <=5
	group by [Time2]
-- Results (if you add 'and PrevOC<=-5' to filter you'l get the better result(Profit=1%)):
-- Filter: Count1>=iif(time2='10:00:00',20, iif(time2='15:00:00',35,50))
-- and Turnover1 between 10 and 50 and and PrevHL>12 and OpenNextDelayInMinutes<3
-- year=2023
--	Time	ProfitReal	ProfitNext	NoFinal	AvgPrevHL	AvgPrevOC	Recs	MinTradeCount2	OneTradeShares	OneTradeValue
--	00:00:00	0,611972150912516	0,657839501558479	2	20,4623869465963	0,897365463339664	1282	489	152,267539671542	1886,7312641114
--	10:00:00	0,2138884576726	0,241057945476448	0	18,6216500587151	1,13870622947446	488	489	153,031891205272	2235,36960076504
--	11:00:00	0,381488725307364	0,39298645726703	0	19,9817891757981	2,27581355959056	247	638	151,069858574192	1754,89267943842
--	12:00:00	0,275202734708097	0,359104315002013	0	22,0916182788121	0,629802641324225	173	760	151,452308985539	1612,99056354148
--	13:00:00	1,32051434424417	1,26184918728882	0	22,7295134445717	-1,74629145228657	145	1285	149,869638061523	1541,96512493265
--	14:00:00	1,08151336125913	1,02995680138469	0	20,9407037734985	1,37582458782941	100	1925	149,553424072266	1739,16631774902
--	15:00:00	1,86994552383507	2,17486395247916	2	23,2419621815053	0,304510694950126	129	913	157,561848854834	1689,31535824325
-- year=2022
--	Time	ProfitReal	ProfitNext	NoFinal	AvgPrevHL	AvgPrevOC	Recs	MinTradeCount2	OneTradeShares	OneTradeValue
--	00:00:00	0,734483459901873	0,686507494990181	1	18,8165849049886	-0,708121414048655	1647	410	180,822353664136	2259,17531185
--	10:00:00	0,44909559911248	0,413537912887754	0	17,9408353924166	-0,792293245134397	611	1623	162,77304469388	2407,81428869969
--	11:00:00	0,268844068281892	0,291591739959668	0	18,9353005262938	-0,543677903944626	352	410	177,328111499548	2110,70966711911
--	12:00:00	1,32841003585075	1,26771876123689	0	19,2750149590628	-1,16202336322694	210	574	198,809920310974	2120,39854997907
--	13:00:00	0,593506383432063	0,58403521425874	0	19,4341123025149	1,43273542831276	151	432	191,412113227592	2136,42977197912
--	14:00:00	1,23950871615498	1,32686594684643	0	19,7086051658348	-1,97317960846617	135	1294	198,223893893207	2241,00962140119
--	15:00:00	1,6257219454423	1,28632301580597	1	19,7918794256576	-1,0465376075912	188	491	204,931132397753	2320,72614596752

-- Result from previous data set (not valid)
-- Time	ProfitNext	Profit	AvgPrevHL	AvgPrevOC	Recs	MinTradeCount2
-- 00:00:00	-0,862405975468696	-0,911564940558812	12,6636474790707	-7,14743090680486	1420	752
-- 10:00:00	-0,68728092528172	-0,684693260369106	11,4191594827493	-6,95961807234859	637	1242
-- 11:00:00	-0,868355815734859	-1,05788621746938	13,294755098031	-7,5875348823832	263	959
-- 12:00:00	-2,39779380121745	-2,53766062951124	14,9695268811249	-8,47254647332721	164	1035
-- 13:00:00	-0,450513337606814	-0,258183132475755	13,6109880199583	-6,57018808401593	127	752
-- 14:00:00	-1,09390672400467	-1,21668497574026	12,1928565259707	-5,55646716554697	118	830
-- 15:00:00	0,190030761130221	0,1124855374565	14,3198133502995	-7,57638619531382	111	929
-- year=2022 and Turnover1<30 and PrevHL>7 and UpDown='Up' and OpenNextDelayInMinutes<3
-- Time	ProfitNext	Profit	AvgPrevHL	AvgPrevOC	Recs	MinTradeCount2
-- 00:00:00	-0,897169694361045	-0,921845413663125	11,764841127934	-6,85147191259862	2037	549
-- 10:00:00	-0,650583885738329	-0,624473515582627	11,5549132535999	-7,2171866131591	828	758
-- 11:00:00	-1,02477797666678	-1,07940828808413	11,4635425359309	-6,73650262957226	499	549
-- 12:00:00	-0,589630758018137	-0,582862809659587	11,8560708841401	-6,65366697246251	223	776
-- 13:00:00	-2,73008626789536	-2,90800270051361	12,2441354016073	-6,62780987238816	153	852
-- 14:00:00	-0,338560743656542	-0,476059214389395	12,999028810433	-6,66467397775324	168	919
-- 15:00:00	-1,03263817292201	-1,00740682665842	11,9042898459607	-6,03382581032543	166	754

/*;with CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date, [Time2] ORDER BY PrevHL desc), *
	   FROM temp_OpenCloseHour_2024_03 where year(Date)=2022
	   and Turnover1<30
	   -- and TradeCount1>2000
	   -- and PrevWma_20<Wma_20
	   -- and OpenNext>Open2
	   -- and Open2>Wma_20
	   and PrevHL>7
	   and UpDown='Down'
	   and OpenNextDelayInMinutes<3
	   and PrevOC>3
    )
    SELECT CAST('0:0:0' as Time(0)) Time, avg(ProfitNext) ProfitNext, avg(Profit) Profit, 
		Avg(PrevHL) AvgPrevHL, Avg(PrevOC) AvgPrevOC, count(*) Recs, min(TradeCount2) MinTradeCount2
	FROM CTE WHERE RN <=5
	UNION
    SELECT Time2, avg(ProfitNext) ProfitNext, avg(Profit) Profit, 
		Avg(PrevHL) AvgPrevHL, Avg(PrevOC) AvgPrevOC, count(*) Recs, min(TradeCount2) MinTradeCount2
	FROM CTE WHERE RN <=5
	group by [Time2]
*/
