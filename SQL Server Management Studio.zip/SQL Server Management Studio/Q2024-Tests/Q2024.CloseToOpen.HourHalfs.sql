use dbQ2024Tests;

select year(date), [Time], [To], min(date), max(date), count(*)  from dbQ2024..HourHalfPolygon
where TradeCount>=500 and [Close]*[Volume]>=2000000 and year(date)<=2023 and [Close]<5.0
group by year(date), [Time], [To] 
order by 2,3,1

select top 1000 * from dbQ2024..HourHalfPolygon
select [Time],[To], count(*) from dbQ2024..HourHalfPolygon
group by [Time],[To] order by 1,2

select count(*) from temp_OpenCloseHourHalf

-- Base SQL (no moving average) --
-- drop table temp_OpenCloseHourHalf
-- 3 mins 38 secs: 6372141 rows (turnover>=2'000'000)
-- 2 mins 50 secs: 4837904 rows (turnover>=5'000'000)
select 
abs(h1.[Open]-h1.[Close])/(h1.[Open]+h1.[Close]) * 200.0 PrevChangeAbsOpenCLose,
(h1.[High]-h1.[Low])/(h1.[High]+h1.[Low]) * 200.0 PrevChangeHighLow,
(h2.[Open]-h2.[Close])/(h2.[Open]+h2.[Close]) * 200.0 Profit,
h1.[Close]*h1.[Volume]/1000000.0 Turnover,
format(h2.date, 'yyyy-MM') as Period,
case when h1.[Open]>h1.[Close] then 'Down' else 'Up' end as UpDown,
h1.Symbol, s.Exchange, s.MyType, h1.[Date], h1.[Time], h1.[To], h2.[To] EndTime,
h2.OpenNext, h2.OpenNextDelayInMinutes,
h2.Prev2Wma_20, h2.PrevWma_20, h2.Wma_20, h2.Prev2Wma_30, h2.PrevWma_30, h2.Wma_30, 
h2.Prev2Ema_20, h2.PrevEma_20, h2.Ema_20, h2.Prev2Ema_30, h2.PrevEma_30, h2.Ema_30, 
h2.Prev2Ema2_20, h2.PrevEma2_20, h2.Ema2_20, h2.Prev2Ema2_30, h2.PrevEma2_30, h2.Ema2_30, 
h1.[Open] Open1, h1.High High1, h1.Low Low1, h1.[Close] Close1, h1.Volume Volume1, h1.[Count] Count1, h1.TradeCount TradeCount1, h1.volume/1000000.0 * h1.[close] Turnover1,
h2.[Open] Open2, h2.High High2, h2.Low Low2, h2.[Close] Close2, h2.Volume Volume2, h2.[Count] Count2, h2.TradeCount TradeCount2, h2.volume/1000000.0 * h2.[close] Turnover2
into temp_OpenCloseHourHalf
from dbQ2024..HourHalfPolygon h1
inner join dbQ2024..HourHalfPolygon h2 on h1.Symbol=h2.Symbol and h1.Date=h2.Date and h1.[To]=h2.[Time]
inner join dbQ2024..SymbolsPolygon s on h1.Symbol=s.Symbol and h1.Date between s.Date and isnull(s.[To], '2099-12-31')
where h1.TradeCount>=500 and h1.[Close]*h1.[Volume]>=5000000 and h1.[close]>=5.0
and h2.OpenNextDelayInMinutes is not null

-- ================================
-- =======  Result for day  =======
-- ================================
-- Quote list
;WITH CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date, [Time] ORDER BY PrevChangeAbsOpenCLose desc), *
	   FROM temp_OpenCloseHourHalf
    )
    SELECT * FROM CTE
    WHERE RN <= 5 and PrevChangeAbsOpenCLose>=6 and Year(date)=2023
	order by date, [Time], RN

-- Compare by AbsChange=abs(Close-Open)/(Close+Open) AND (high2-low2)/(high2+low2)
;WITH CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date, [Time] ORDER BY PrevChangeAbsOpenCLose desc), *
	   FROM temp_OpenCloseHourHalf where turnover>=5
    )
    SELECT avg(Profit), count(*) FROM CTE
    WHERE   RN <= 5 and PrevChangeAbsOpenCLose>=12 and Year(date)=2022
-- 0,919787724422504	940 / 2023 year
-- 0,625709673985837	1171 / 2022 year

;WITH CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date, [Time] ORDER BY PrevChangeHighLow desc), *
	   FROM temp_OpenCloseHourHalf
    )
    SELECT avg(Profit), count(*) FROM CTE
    WHERE   RN <= 5 and PrevChangeHighLow>=21.2 and Year(date)=2022
-- 0,926404298427199	944 / 2023 year ( PrevChangeHighLow>=21.0 is better profit)
-- 0,661898116813735	981 / 2022 year

-- Group by Time: Compare by AbsChange=abs(Close-Open)/(Close+Open) AND (high2-low2)/(high2+low2)
;WITH CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date, [Time] ORDER BY PrevChangeAbsOpenCLose desc), *
	   FROM temp_OpenCloseHourHalf where turnover>=5
    )
    SELECT [Time], [To], avg(Profit) Profit, count(*) Recs FROM CTE
    WHERE RN <= 5 and PrevChangeAbsOpenCLose>=12 and Year(date)=2022
	GROUP by [Time], [To] order by 1
/* 2023 year
09:30:00	10:00:00	0,933798606684416	302
10:00:00	11:00:00	1,15246075913661	212
11:00:00	12:00:00	-1,83273752053491	113
12:00:00	13:00:00	1,59402320336085	96
13:00:00	14:00:00	1,53687642871494	71
14:00:00	15:00:00	1,52117727311809	89
15:00:00	15:45:00	2,59371419917596	57
2022 year
09:30:00	10:00:00	1,40808825050505	382
10:00:00	11:00:00	1,16141365285291	244
11:00:00	12:00:00	2,29269700146388	136
12:00:00	13:00:00	-2,98273806650083	103
13:00:00	14:00:00	-0,535820745454546	114
14:00:00	15:00:00	-0,832981747827519	107
15:00:00	15:45:00	0,671285010567483	85  */

;WITH CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date, [Time] ORDER BY PrevChangeHighLow desc), *
	   FROM temp_OpenCloseHourHalf where turnover>=5
    )
    SELECT [Time], [To], avg(Profit) Profit, count(*) Recs FROM CTE
    WHERE RN <= 5 and PrevChangeHighLow>=21.2 and Year(date)=2022
	GROUP by [Time], [To] order by 1,2
/* 2023 year
09:30:00	10:00:00	1,01562020685034	228
10:00:00	11:00:00	0,468824586321442	212
11:00:00	12:00:00	-0,986979723634089	136
12:00:00	13:00:00	2,76089671398674	116
13:00:00	14:00:00	1,85057639521222	86
14:00:00	15:00:00	0,780632523919946	93
15:00:00	15:45:00	1,72315434427702	73
2022 year
09:30:00	10:00:00	1,4889960559376	256
10:00:00	11:00:00	1,58633362844184	222
11:00:00	12:00:00	3,71944051419479	138
12:00:00	13:00:00	-3,66685859322548	100
13:00:00	14:00:00	-0,863465582808623	104
14:00:00	15:00:00	-1,83406213535504	88
15:00:00	15:45:00	0,281834981468034	73  */

-- =========================================
-- ==========  Tests  ======================
-- =========================================
;WITH CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date, [Time] ORDER BY PrevChangeAbsOpenCLose desc), *
	   FROM temp_OpenCloseHourHalf
    )
    SELECT avg(Profit), count(*) FROM CTE
    WHERE   RN <= 5 and PrevChangeAbsOpenCLose>=12 and Year(date)=2023
-- 0,811731315519959	883 / 2023 year

;WITH CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date, [Time] ORDER BY PrevWma_20/Wma_20 desc), *
	   FROM (select * from temp_OpenCloseHourHalf WHERE PrevWma_20>Wma_20 and OpenNext<Open2 and Open2<Wma_20) x
    )
    SELECT [Time], Period, avg(Profit), count(*) FROM CTE
    WHERE   RN <= 5 and Year(date)=2022
	-- group by [Time] order by 1
	group by [Time], Period order by 2,1
-- Order by [Close1]/Wma_20 DESC, WHERE PrevWma_20>Wma_20
-- WMA20: 09:30:00	0,524324074935913	1250
-- WMA30: 09:30:00	0,392471636140719	1250
-- EMA20: 09:30:00	0,442146550244978	1250
-- EMA30: 09:30:00	0,403254540254502	1250
-- EMA2_20: 09:30:00	0,459272037382191	1250
-- EMA2_30: 09:30:00	0,486977583048493	1250

-- Order by PrevWma_20/Wma_20 DESC, WHERE PrevWma_20>Wma_20
-- WMA20: 09:30:00	0,42522857299652	1250
-- WMA30: 09:30:00	0,397932510149945	1250
-- EMA20: 09:30:00	0,405112395914365	1250
-- EMA30: 09:30:00	0,346110302660149	1250
-- EMA2_20: 09:30:00	0,405112395914365	1250
-- EMA2_30: 09:30:00	0,354927858539391	1250

-- !!!! MovingAverage ===
;WITH CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date, [Time] ORDER BY PrevEma2_20/Ema2_20 desc), *
	   FROM (select * from temp_OpenCloseHourHalf WHERE
	   /*Prev2Ema2_20>PrevEma2_20 and*/ PrevEma2_20>Ema2_20 and OpenNext<Open2 and Open2<Ema2_20
	   -- and PrevEma_20>Ema_20 and Open2<Ema_20
	   and OpenNextDelayInMinutes=1 ) x
    )
    SELECT [Time], avg(Profit), count(*) FROM CTE
    WHERE   RN <= 5 and Year(date)=2022 and PrevEma2_20/Ema2_20>1.0005
	group by [Time] order by 1
	-- group by [Time], Period order by 2,1
/* Wma_20: OpenNextDelayInMinutes<5
09:30:00	0,408270181017739	1255
10:00:00	0,477724070440462	1255
11:00:00	0,655141683590721	1255
12:00:00	0,542832720925333	1250
13:00:00	0,470814637047239	1250
14:00:00	0,281246360476967	1250
Wma_20: OpenNextDelayInMinutes=1
09:30:00	0,409942661276072	1255
10:00:00	0,443500299995257	1255
11:00:00	0,658862801470545	1255
12:00:00	0,538870264976146	1250
13:00:00	0,444742411089875	1250
14:00:00	0,281332646139618	1250
Wma_30: OpenNextDelayInMinutes=1
09:30:00	0,737803956403015	1255
10:00:00	0,431143548469749	1255
11:00:00	0,652264909213223	1255
12:00:00	0,584661007010983	1250
13:00:00	0,447901323156804	1250
14:00:00	0,352487175790925	1249
Ema_20: OpenNextDelayInMinutes=1 (PrevEma_20>Wma_20 and OpenNext<Open2 and Open2<Ema_20)
09:30:00	0,704710336658636	1255
10:00:00	0,464713753739361	1255
11:00:00	0,63798793735413	1255
12:00:00	0,579910419281991	1250
13:00:00	0,476234939190606	1250
14:00:00	0,378900463850449	1245
Ema_20: OpenNextDelayInMinutes=1
09:30:00	0,619936645330594	1255
10:00:00	0,476518121586864	1255
11:00:00	0,686515575936769	1255
12:00:00	0,601175620908709	1250
13:00:00	0,48722432848271	1250
14:00:00	0,369466721277591	1250
Ema_30: OpenNextDelayInMinutes=1
09:30:00	0,702988073665953	1255
10:00:00	0,48490594274715	1255
11:00:00	0,647213051864781	1255
12:00:00	0,604285779658006	1250
13:00:00	0,502091355817253	1250
14:00:00	0,403105235939892	1250
Ema2_20: OpenNextDelayInMinutes=1
09:30:00	0,667614546189441	1255
10:00:00	0,476928750945318	1255
11:00:00	0,639965759575426	1255
12:00:00	0,539275229055434	1250
13:00:00	0,544511531010503	1250
14:00:00	0,38000374087384	1250
Ema2_30: OpenNextDelayInMinutes=1
09:30:00	0,668611215224	1255
10:00:00	0,440362184437129	1255
11:00:00	0,661340844450125	1255
12:00:00	0,484664678061428	1250
13:00:00	0,562012604093226	1250
14:00:00	0,403556250521091	1249
*/

-- =======  Count  =======
;WITH CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date, [Time] ORDER BY PrevWma_20/Wma_20 desc), *
	   FROM (select * from temp_OpenCloseHourHalf WHERE
	   PrevWma_20>Wma_20 and OpenNext<Open2 and Open2<Wma_20
	   --and (PrevWma_20-Wma_20)>=(Wma_20-Open2)
	   -- and (Wma_20-Open2)<=(Open2-OpenNext)
	   -- and PrevWma_30>Wma_30 and Open2<Wma_30
	   and [Count1]>iif([Time]='09:30:00', 20,40)
	   -- and [TradeCount1] between 1000 and 10000
	   and OpenNextDelayInMinutes=1 ) x
    )
    SELECT [Time], avg(Profit), avg(Count1*1.0), count(*) FROM CTE
    WHERE   RN <= 5 and Year(date)=2022
	group by [Time] order by 1
/* Wma20, [Count1]>iif([Time]='09:30:00', 20,40)
09:30:00	0,405821668777978	29.674900	1255
10:00:00	0,435101745755642	59.106772	1255
11:00:00	0,576738481444726	59.171314	1255
12:00:00	0,510746980075957	58.752000	1250
13:00:00	0,451863732309081	58.747200	1250
14:00:00	0,281519154222216	58.896000	1250
*/

-- =========  
;WITH CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date, [Time] ORDER BY PrevWma_20/Wma_20), *
	   FROM (select * from temp_OpenCloseHourHalf WHERE
	   PrevWma_20<Wma_20 and OpenNext>Open2 -- and Open1>Close1 -- and Open2<Wma_20 and Open2<[Close1] and [Close1]<Wma_20
	   --and (PrevWma_20-Wma_20)>=(Wma_20-Open2)
	   -- and (Wma_20-Open2)<=(Open2-OpenNext)
	   -- and PrevWma_30>Wma_30 and Open2<Wma_30
	   and [Count1]>iif([Time]='09:30:00', 20,40)
	   -- and [TradeCount1] between 1000 and 10000
	   and OpenNextDelayInMinutes=1 ) x
    )
    SELECT [Time], avg(Profit), avg(Count1*1.0), count(*) FROM CTE
    WHERE   RN <= 5 and Year(date)=2022
	group by [Time] order by 1
