;WITH Data AS
    (
SELECT
abs(d2.[Open]-d2.[Close])/(d2.[Open]+d2.[Close]) * 200.0 PrevChangeAbsOpenCLose,
(d2.[High]-d2.[Low])/(d2.[High]+d2.[Low]) * 200.0 PrevChangeHighLow,
(d3.[Open]-d3.[Close])/(d3.[Open]+d3.[Close]) * 200.0 Profit,
(d3.[Open]-d3.[Close])/(d3.[Open]) * 100.0 ProfitReal,
iif(d3.[Open]<d3.[Close], 1, 0) UpCount,
iif(d3.[Open]>d3.[Close], 1, 0) DownCount,
d2.[Close]*d2.[Volume]/1000000.0 Turnover,
case when d2.[Open]>d2.[Close] then d2.[Open]/d2.[Close] else d2.[Close]/d2.[Open] end K_OpenClose,
case when d2.[Open]>d2.[Close] then d2.[Close]/d2.[Open] else d2.[Open]/d2.[Close] end K_CloseOpen,
d3.[Open]/d3.[Close] NewK_OpenClose,
d3.[Close]/d3.[Open] NewK_CloseOpen,
d2.[open]/d2.[Close] PrevOpenClose,
format(d3.date, 'yyyy-MM') as period, case when d2.[Open]>d2.[Close] then 'Down' else 'Up' end as UpDown,
d2.Date Date2, d2.[Open] Open2, d2.High High2, d2.Low Low2, d2.[Close] Close2, d2.Volume Volume2, d2.TradeCount TradeCnt2, d2.volume/1000000.0 * d2.[close] Turnover2,
d3.Date Date3, d3.[Open] Open3, d3.High High3, d3.Low Low3, d3.[Close] Close3, d3.Volume Volume3, d3.TradeCount TradeCnt3, d3.volume/1000000.0 * d3.[close] Turnover3
-- into temp_OpenCloseDay
FROM dbQ2024..DayPolygon d2
inner join dbQ2024..TradingDays b on d2.Date=b.Date
left join dbQ2024..TradingShortened c1 on b.Next1=c1.Date
inner join dbQ2024..DayPolygon d3 on d2.Symbol=d3.Symbol and b.Next1=d3.Date
-- left join dbQ2024..Splits s2 on s2.Symbol=d2.Symbol and s2.Date=d2.Date
-- left join dbQ2024..Splits s3 on s3.Symbol=d3.Symbol and s3.Date=d3.Date
where d2.IsTest is null
and d2.tradecount>10000 and d2.[close]>5 and d2.volume/1000000.0 * d2.[close]>50
and d3.[Open]>5.0
and b.IsShortened is null and c1.Date is null
-- and s2.Symbol is null and s3.Symbol is null 
and year(d3.Date)>=2010
-- and d3.Date between '2022-01-01' and '2024-01-01'
),
CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date3 ORDER BY PrevChangeHighLow desc), *
	   FROM data 
    ),
CTE1 AS (
		SELECT * from CTE
		WHERE RN<=10 and PrevChangeHighLow>=18.2
--     WHERE   RN<=5 and PrevChangeHighLow>=18.2 and Year(date3)=2023
)

    SELECT 'Total' Year, ROUND(avg(ProfitReal),3) ProfitReal,
	ROUND(cast(sum(UpCount)*1.0/count(*)*100.0 as real),2) UpPerc,
	ROUND(cast(sum(DownCount)*1.0/count(*)*100.0 as real),2) DownPerc,
	ROUND(avg(Profit),3) Profit, count(*) Recs
	FROM CTE1
	UNION ALL
    SELECT format(date3, 'yyyy') Year, ROUND(avg(ProfitReal),3) ProfitReal,
	ROUND(cast(sum(UpCount)*1.0/count(*)*100.0 as real),2) UpPerc,
	ROUND(cast(sum(DownCount)*1.0/count(*)*100.0 as real),2) DownPerc,
	ROUND(avg(Profit),3) Profit, count(*) Recs
	FROM CTE1
	GROUP by format(date3, 'yyyy') order by 1 desc

/* WHERE RN<=10 and PrevChangeHighLow>=10
Year	ProfitReal (Invalid)	UpPerc	DownPerc	Profit	Recs
Total	1,254	45,09	54,38	1,103	30634
2024	1,241	44,17	55,25	1,39	2040
2023	2,007	46,62	53,08	1,597	2385
2022	0,875	45,5	54,1	1,259	2466
2021	3,239	38,92	60,8	2,752	2500
2020	1,363	43,4	56,23	1,548	2470
2019	0,695	48,95	50,35	0,631	2153
2018	1,322	45,8	53,53	0,987	2225
2017	1,165	45,09	54,29	0,856	1923
2016	0,756	47,75	51,74	0,739	2178
2015	0,477	47,43	51,96	0,503	2163
2014	1,328	44,1	55,34	0,906	1993
2013	1,088	45,45	53,96	0,708	1540
2012	0,416	45,37	53,98	0,346	1532
2011	0,985	44,04	55,49	0,642	1721
2010	1,097	44,31	54,8	0,674	1345
*/

/* WHERE RN<=5 and PrevChangeHighLow>=18
Year	ProfitReal	UpPerc	DownPerc	Profit	Recs
Total	2,197	42,6	56,97	1,972	14212
2024	2,302	42,67	56,78	2,224	1268
2023	4,397	42,26	57,47	3,289	1098
2022	1,495	44,14	55,5	1,845	1672
2021	2,962	38,91	60,72	2,527	2948
2020	1,332	43,81	55,76	1,681	2134
2019	2,069	43,63	55,52	1,704	589
2018	2,423	43,19	56,17	1,843	778
2017	2,87	43,12	56,28	2,123	494
2016	1,326	47,5	52,09	1,432	741
2015	1,066	44,08	55,65	0,996	735
2014	2,126	42,91	56,73	1,565	550
2013	1,918	43,84	55,86	1,315	333
2012	1,32	39,65	59,65	0,896	285
2011	0,648	44,15	55,85	0,599	376
2010	3,246	41,23	57,82	1,941	211
*/