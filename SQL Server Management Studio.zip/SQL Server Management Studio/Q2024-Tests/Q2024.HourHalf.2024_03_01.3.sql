use dbQ2024Tests;

/* Check data - OK
select year(h1.date), count(*)
from dbQ2024Tests2..HourHalfPolygon2 h1
inner join dbQ2024Tests2..HourHalfPolygon2 h2 on h1.Symbol=h2.Symbol and h1.Date=h2.Date and h1.[To]=h2.[Time]
inner join dbQ2024..SymbolsPolygon s on h1.Symbol=s.Symbol and h1.Date between s.Date and isnull(s.[To], '2099-12-31')
inner join (select * from dbQ2024..TradingDays where IsShortened is null) d on h1.Date=d.Date
where h1.TradeCount>=500 and h1.[Close]*h1.[Volume]>=5000000 and h1.[close]>=5.0
and h1.Date<='2024-01-01'
and h2.OpenNextDelayInMinutes is not null and h2.[Time] not in ('15:30:00')
group by year(h1.date) order by 1
-- 2021	2224897
-- 2022	2227385
-- 2023	1992919

select year(date), count(*), min(TradeCount1), min(Volume1*Close1)/1000000 from dbQ2024Tests..temp_OpenCloseHourHalf3_2024_03 group by year(date) order by 1
-- 2023	1992919*/

/*
-- Without CTE:
select count(*), avg((h2.[OpenNext]-h2.[Final])/h2.[OpenNext] * 100.0) ProfitReal
from dbQ2024Tests3..HourHalfPolygon7 h1
inner join dbQ2024Tests3..HourHalfPolygon7 h2 on h1.Symbol=h2.Symbol and h1.Date=h2.Date and h1.[To]=h2.[Time]
inner join (select * from dbQ2024..TradingDays where IsShortened is null) d on h1.Date=d.Date
where year(h1.date)=2023 and h1.TradeCount>=500 and h1.[Close]*h1.[Volume]>=5000000 and h1.[close]>=5.0
and (h1.[High]-h1.[Low])/(h1.[High]+h1.[Low]) * 200.0 > 7
and h2.OpenNextDelayInMinutes is not null and h2.[Time] not in ('15:30:00')
and h2.OpenNextDelayInMinutes<3
and h1.[Count]>= iif(h2.Time='10:00:00', 15, 25)
-- and h1.HighTime>h1.LowTime
-- and h2.HighTimeBefore<h2.LowTimeBefore
*/

-- Base SQL (no moving average) --
-- drop table dbQ2024Tests..temp_OpenCloseHourHalf3_2024_03
-- 2:20 min: 1992919 rows (h1.TradeCount>=500 and h1.[Close]*h1.[Volume]>=5000000 and h1.[close]>=5.0), 2023year, no Shortened days
/*select 
(h1.[Open]-h1.[Close])/(h1.[Open]+h1.[Close]) * 200.0 PrevOC,
(h1.[High]-h1.[Low])/(h1.[High]+h1.[Low]) * 200.0 PrevHL,
(h2.[HighBefore]-h2.[LowBefore])/(h2.[HighBefore]+h2.[LowBefore]) * 200.0 BeforeHL,
(h2.[OpenNext]-h2.[Final])/h2.[OpenNext] * 100.0 ProfitReal,
iif(h2.Final is null, 1,0) NoFinal,
h2.FinalDelayInMinutes,
(h2.[Open]-h2.[Close])/h2.[Open] * 100.0 Profit,
(h2.[OpenNext]-h2.[Close])/h2.[OpenNext] * 100.0 ProfitNext,
h1.[Close]*h1.[Volume]/1000000.0 Turnover,
format(h2.date, 'yyyy-MM') as Period,
case when h1.[Open]>h1.[Close] then 'Down' else 'Up' end as UpDown,
h1.Symbol, s.Exchange, s.MyType, h1.[Date], h2.[Time] Time2, h2.[To] To2,
h1.HighBefore, h1.LowBefore,
h2.OpenNext, h2.OpenNextDelayInMinutes,
h2.PrevWma_20, h2.Wma_20, h2.PrevWma_30, h2.Wma_30, 
h2.PrevEma_20, h2.Ema_20, h2.PrevEma_30, h2.Ema_30, 
h2.PrevEma2_20, h2.Ema2_20, h2.PrevEma2_30, h2.Ema2_30, 
h1.[Open] Open1, h1.High High1, h1.Low Low1, h1.[Close] Close1, h1.Volume Volume1, h1.[Count] Count1, h1.TradeCount TradeCount1, h1.volume/1000000.0 * h1.[close] Turnover1,
h2.[Open] Open2, h2.High High2, h2.Low Low2, h2.[Close] Close2, h2.Volume Volume2, h2.[Count] Count2, h2.TradeCount TradeCount2, h2.volume/1000000.0 * h2.[close] Turnover2
into dbQ2024Tests..temp_OpenCloseHourHalf3_2024_03
from dbQ2024..HourHalfPolygon h1
inner join dbQ2024..HourHalfPolygon h2 on h1.Symbol=h2.Symbol and h1.Date=h2.Date and h1.[To]=h2.[Time]
inner join dbQ2024..SymbolsPolygon s on h1.Symbol=s.Symbol and h1.Date between s.Date and isnull(s.[To], '2099-12-31')
inner join (select * from dbQ2024..TradingDays where IsShortened is null) d on h1.Date=d.Date
where h1.TradeCount>=500 and h1.[Close]*h1.[Volume]>=5000000 and h1.[close]>=5.0
and h1.Date<='2024-01-01'
and h2.OpenNextDelayInMinutes is not null and h2.[Time] not in ('15:30:00')*/

/*select Top 100 * from temp_OpenCloseHour_2024_03
select Top 100 * from dbQ2024..HourPolygon
select [Time2], count(*) from temp_OpenCloseHour_2024_03 group by [Time2] order by 1
select [Time], [To], count(*) from dbQ2024..HourPolygon group by [Time],[To] order by 1*/

;with CTE AS
    (
        -- SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date, [Time2] ORDER BY (PrevHL) desc), *
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date, [Time2] ORDER BY (BeforeHL) desc), 
	   iif(ProfitReal>0.0, 1.0, 0.0) ProfitRealCount, *
	   FROM temp_OpenCloseHourHalf3_2024_03 where year(Date)=2023
	   and Count1>= iif(time2='10:00:00', 15, 25)
	   -- no filter: 0,1363 for 7440 rows
	   and Turnover1 between 5 and 1000
	   -- and TradeCount1>5000
	  --  and PrevWma_20>Wma_20
	   -- and OpenNext<Open2
	   -- and Open2<Wma_20
	   and PrevHL>7 -- PrevHL>7 = 0.28 for 4056 rows (2023)
	   -- and BeforeHL>17
	   -- and UpDown='Down'
	   -- and PrevOC>5
	   and OpenNextDelayInMinutes<3 -- OpenNextDelayInMinutes=1: 0.1389 for 7440
	   -- and Close1 between 10 and 200
    )
    SELECT '--' "--", '00:00:00' Time,-- CAST('0:0:0' as Time(0)) Time,
		ROUND(avg(ProfitReal),4) ProfitReal, 
		sum(ProfitRealCount)/count(*)*100.0 ProfitRealCount,
		ROUND(avg(ProfitNext),4) ProfitNext, sum(NoFinal) NoFinal,
		ROUND(Avg(PrevHL),4) AvgPrevHL, ROUND(Avg(PrevOC),4) AvgPrevOC,
		count(*) Recs, min(TradeCount2) MinTradeCount2,
		ROUND(Avg(Volume1/TradeCount1),1) OneTradeShares, ROUND(Avg(Volume1/TradeCount1*Close1),1) OneTradeValue
	FROM CTE WHERE RN <=5
	UNION
    SELECT '--' "--", Time2,
		ROUND(avg(ProfitReal),4) ProfitReal,
		sum(ProfitRealCount)/count(*)*100.0 ProfitRealCount,
		ROUND(avg(ProfitNext),4) ProfitNext, sum(NoFinal) NoFinal,
		ROUND(Avg(PrevHL),4) AvgPrevHL, ROUND(Avg(PrevOC),4) AvgPrevOC,
		count(*) Recs, min(TradeCount2) MinTradeCount2,
		ROUND(Avg(Volume1/TradeCount1),1) OneTradeShares, ROUND(Avg(Volume1/TradeCount1*Close1),1) OneTradeValue
	FROM CTE WHERE RN <=5
	group by Time2
-- Results (if you add 'and PrevOC<=-5' to filter you'l get the better result(Profit=1%)):
-- Filter: Count1>=iif(time2='10:00:00',20, iif(time2='15:00:00',35,50))
-- PrevHL>7 and OpenNextDelayInMinutes<3
-- year=2023
--	Time	ProfitReal	ProfitNext	NoFinal	AvgPrevHL	AvgPrevOC	Recs	MinTradeCount2	OneTradeShares	OneTradeValue
--	00:00:00	0,2831	0,3051	3	15,1528	-0,756	4036	489	166,5	2750,6
--	10:00:00	0,0684	0,0991	0	15,2959	-0,4295	1211	489	163,2	3097,3
--	11:00:00	0,0969	0,0886	0	14,3728	-0,5878	1028	638	163,6	2566,2
--	12:00:00	0,1442	0,1846	1	15,0602	-0,7249	601	1035	161,5	2576,1
--	13:00:00	0,9731	0,958	0	15,8452	-1,8631	430	1285	165,6	2507,4
--	14:00:00	0,4477	0,4421	0	14,6045	-0,4934	369	827	171,9	2645
--	15:00:00	0,7319	0,8417	2	16,6364	-1,2794	397	641	187,3	2796,3
-- year=2022
--	Time	ProfitReal	ProfitNext	NoFinal	AvgPrevHL	AvgPrevOC	Recs	MinTradeCount2	OneTradeShares	OneTradeValue
--	00:00:00	0,4213	0,4175	0	14,6661	-1,2583	5029	418	189,5	3155,9
--	10:00:00	0,3438	0,3195	0	15,81	-0,9096	1241	916	169,8	3256
--	11:00:00	-0,0213	-0,0136	0	14,8825	-1,364	1166	418	178,2	3021,8
--	12:00:00	0,6516	0,6362	0	13,7492	-1,4454	826	574	197,2	3053,2
--	13:00:00	0,4964	0,5148	0	13,711	-0,9819	616	432	205,6	3125,4
--	14:00:00	0,9141	0,9446	0	14,3783	-1,8754	554	876	209,1	3266,1
--	15:00:00	0,5852	0,5642	0	14,3993	-1,232	626	491	206,3	3274,9
-- year=2021
--	Time	ProfitReal	ProfitNext	NoFinal	AvgPrevHL	AvgPrevOC	Recs	MinTradeCount2	OneTradeShares	OneTradeValue
--	00:00:00	0,5839	0,5886	1	17,5865	-1,8147	6934	307	202,7	3079
--	10:00:00	1,4682	1,458	0	20,8088	-1,6622	1255	726	182,3	3019,6
--	11:00:00	0,3918	0,3862	0	20,1003	-1,3824	1253	322	196,5	2751,6
--	12:00:00	0,0557	0,0664	0	16,5313	-1,9626	1183	307	204,4	3098,1
--	13:00:00	0,5935	0,5859	0	15,4771	-2,3521	1103	405	211,5	3218,4
--	14:00:00	-0,1082	-0,0651	0	15,9951	-1,3881	1063	501	214,6	3182
--	15:00:00	1,0309	1,0328	1	15,7973	-2,2033	1077	493	210,9	3263,4

-- Result from previous data set (not valid)
-- Time	ProfitNext	Profit	AvgPrevHL	AvgPrevOC	Recs	MinTradeCount2
-- 00:00:00	-0,862405975468696	-0,911564940558812	12,6636474790707	-7,14743090680486	1420	752
-- 10:00:00	-0,68728092528172	-0,684693260369106	11,4191594827493	-6,95961807234859	637	1242
-- 11:00:00	-0,868355815734859	-1,05788621746938	13,294755098031	-7,5875348823832	263	959
-- 12:00:00	-2,39779380121745	-2,53766062951124	14,9695268811249	-8,47254647332721	164	1035
-- 13:00:00	-0,450513337606814	-0,258183132475755	13,6109880199583	-6,57018808401593	127	752
-- 14:00:00	-1,09390672400467	-1,21668497574026	12,1928565259707	-5,55646716554697	118	830
-- 15:00:00	0,190030761130221	0,1124855374565	14,3198133502995	-7,57638619531382	111	929
-- year=2022 and Turnover1<30 and PrevHL>7 and UpDown='Up' and OpenNextDelayInMinutes<3
-- Time	ProfitNext	Profit	AvgPrevHL	AvgPrevOC	Recs	MinTradeCount2
-- 00:00:00	-0,897169694361045	-0,921845413663125	11,764841127934	-6,85147191259862	2037	549
-- 10:00:00	-0,650583885738329	-0,624473515582627	11,5549132535999	-7,2171866131591	828	758
-- 11:00:00	-1,02477797666678	-1,07940828808413	11,4635425359309	-6,73650262957226	499	549
-- 12:00:00	-0,589630758018137	-0,582862809659587	11,8560708841401	-6,65366697246251	223	776
-- 13:00:00	-2,73008626789536	-2,90800270051361	12,2441354016073	-6,62780987238816	153	852
-- 14:00:00	-0,338560743656542	-0,476059214389395	12,999028810433	-6,66467397775324	168	919
-- 15:00:00	-1,03263817292201	-1,00740682665842	11,9042898459607	-6,03382581032543	166	754

/*;with CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date, [Time2] ORDER BY PrevHL desc), *
	   FROM temp_OpenCloseHour_2024_03 where year(Date)=2022
	   and Turnover1<30
	   -- and TradeCount1>2000
	   -- and PrevWma_20<Wma_20
	   -- and OpenNext>Open2
	   -- and Open2>Wma_20
	   and PrevHL>7
	   and UpDown='Down'
	   and OpenNextDelayInMinutes<3
	   and PrevOC>3
    )
    SELECT CAST('0:0:0' as Time(0)) Time, avg(ProfitNext) ProfitNext, avg(Profit) Profit, 
		Avg(PrevHL) AvgPrevHL, Avg(PrevOC) AvgPrevOC, count(*) Recs, min(TradeCount2) MinTradeCount2
	FROM CTE WHERE RN <=5
	UNION
    SELECT Time2, avg(ProfitNext) ProfitNext, avg(Profit) Profit, 
		Avg(PrevHL) AvgPrevHL, Avg(PrevOC) AvgPrevOC, count(*) Recs, min(TradeCount2) MinTradeCount2
	FROM CTE WHERE RN <=5
	group by [Time2]
*/
