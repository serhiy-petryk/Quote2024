use dbQuote2022;

-- ===========================

select count(*) Cnt,
avg(dbo.BuyAbs(100000.0, Open_N1, Low_N1, CL_N1)) b,
avg(dbo.BuyAbs(0.01, Open_N1, Low_N1, CL_N1)) b1,
avg(dbo.dBuyAbs(0.01, Open_N1, Low_N1, CL_N1)) dB1,
avg(dbo.BuyAbs(0.02, Open_N1, Low_N1, CL_N1)) b2,
avg(dbo.BuyAbs(0.03, Open_N1, Low_N1, CL_N1)) b3,
avg(dbo.BuyAbs(0.05, Open_N1, Low_N1, CL_N1)) b5,
avg(dbo.BuyAbs(0.1, Open_N1, Low_N1, CL_N1)) b10,
avg(dbo.BuyPerc(CL, 100000.0, Open_N1, Low_N1, CL_N1)) bp,
avg(dbo.BuyPerc(CL, 0.1, Open_N1, Low_N1, CL_N1)) b1p,
avg(dbo.BuyPerc(CL, 0.2, Open_N1, Low_N1, CL_N1)) b2p,
avg(dbo.BuyPerc(CL, 0.3, Open_N1, Low_N1, CL_N1)) b3p,
avg(dbo.BuyPerc(CL, 0.5, Open_N1, Low_N1, CL_N1)) b5p,
avg(dbo.BuyPerc(CL, 1.0, Open_N1, Low_N1, CL_N1)) b10p,
avg(dbo.SellAbs(100000.0, Open_N1, High_N1, CL_N1)) s,
avg(dbo.SellAbs(0.01, Open_N1, High_N1, CL_N1)) s1,
avg(dbo.SellAbs(0.02, Open_N1, High_N1, CL_N1)) s2,
avg(dbo.SellAbs(0.03, Open_N1, High_N1, CL_N1)) s3,
avg(dbo.SellAbs(0.05, Open_N1, High_N1, CL_N1)) s5,
avg(dbo.SellAbs(0.1, Open_N1, High_N1, CL_N1)) s10,
avg(dbo.SellPerc(CL, 1000000.0, Open_N1, High_N1, CL_N1)) sp,
avg(dbo.SellPerc(CL, 0.1, Open_N1, High_N1, CL_N1)) s1p,
avg(dbo.SellPerc(CL, 0.2, Open_N1, High_N1, CL_N1)) s2p,
avg(dbo.SellPerc(CL, 0.3, Open_N1, High_N1, CL_N1)) s3p,
avg(dbo.SellPerc(CL, 0.5, Open_N1, High_N1, CL_N1)) s5p,
avg(dbo.SellPerc(CL, 1.0, Open_N1, High_N1, CL_N1)) s10
from vDayEoddataExtended where k1 is not null; 

select symbol, date,
dbo.dBuyAbs(0.01, Open_N1, Low_N1, CL_N1) dB1,
dbo.dBuyAbsPrice(0.01, Open_N1, Low_N1, CL_N1) dB1,
Open_N1, Low_N1, CL_N1 from vDayEoddataExtended where k1 is not null
order by symbol, date; 

select symbol, date,
dbo.dBuyAbs(0.01, Open_N1, Low_N1, CL_N1) dB1,
dbo.dBuyAbsPrice(0.01, Open_N1, Low_N1, CL_N1) dB1,
Open_N1, Low_N1, CL_N1 from vDayEoddataExtended where k1 is not null
and symbol='ZYME' and date in('2022-02-03', '2022-05-09') 

select symbol, date,
dbo.dBuyAbsPrice(0.01, Open_N1, Low_N1, CL_N1) dB1,
Open_N1, Low_N1, CL_N1 from vDayEoddataExtended where k1 is not null
and ((symbol='ADI' and date='2022-01-13') 
or (symbol='TSLA' and date='2022-03-30')); 

select cast(1094.57 as decimal(15,4))-cast(0.01 as decimal(15,4)),
cast(cast(1094.57E0 as float) as decimal(15,4)), ---cast(0.01 as decimal(15,4)),
dbo.[dBuyAbsPrice](0.01, cast(1094.57E0 as real), 106.641E0, 1077.6E0),
CAST(CAST(CAST(168.4148 as real) as varchar(20)) as decimal(15,4)),
CONVERT(decimal(15,4), CONVERT(varchar(20), CONVERT(real, 168.4148))),
CAST(ROUND(CONVERT(real, 168.4148)*10000E0,2) as int)

SELECT CAST(25.65 AS varchar);


-- ======================================
select symbol, date,
dbo.dBuyPerc(0.1, CL, Open_N1, Low_N1, CL_N1) dB1,
dbo.dBuyPercPrice(0.1, CL, Open_N1, Low_N1, CL_N1) dB1,
CL, Open_N1, Low_N1, CL_N1 from vDayEoddataExtended where k1 is not null
order by symbol, date; 

-- =====================================
-- Different version of functions (float(double) version)
select symbol, date,
dbo.ndBuyAbsPrice(0.01, Open_N1, Low_N1, CL_N1) ndBuyAbsPrice,
dbo.nfBuyAbsPrice(0.01, Open_N1, Low_N1, CL_N1) nfBuyAbsPrice,
CL, Open_N1, Low_N1, CL_N1 from vDayEoddataExtended where k1 is not null
and dbo.ndBuyAbsPrice(0.01, Open_N1, Low_N1, CL_N1)<>dbo.nfBuyAbsPrice(0.01, Open_N1, Low_N1, CL_N1)


select symbol, date,
dbo.ndBuyAbsPrice(0.01, Open_N1, Low_N1, CL_N1) ndBuyAbsPrice,
CL, Open_N1, Low_N1, CL_N1 from vDayEoddataExtended where k1 is not null

select symbol, date,
dbo.nfBuyAbsPrice(0.01, Open_N1, Low_N1, CL_N1) ndBuyAbsPrice,
CL, Open_N1, Low_N1, CL_N1 from vDayEoddataExtended where k1 is not null

select symbol, date,
dbo.fBuyAbsPrice(0.01, Open_N1, Low_N1, CL_N1) fBuyAbsPrice,
dbo.fBuyPercPrice(0.1, CL, Open_N1, Low_N1, CL_N1) fBuyPercPrice,
CL, Open_N1, Low_N1, CL_N1 from vDayEoddataExtended where k1 is not null
and dbo.fBuyAbsPrice(0.01, Open_N1, Low_N1, CL_N1)<>dbo.fBuyPercPrice(0.1, CL, Open_N1, Low_N1, CL_N1)

select symbol, date,
dbo.dBuyAbs(0.01, Open_N1, Low_N1, CL_N1) dBuyAbs,
dbo.fBuyAbs(0.01, Open_N1, Low_N1, CL_N1) fBuyAbs,
dbo.dBuyAbs(0.01, Open_N1, Low_N1, CL_N1)-dbo.fBuyAbs(0.01, Open_N1, Low_N1, CL_N1) diff,
CL, Open_N1, Low_N1, CL_N1 from vDayEoddataExtended where k1 is not null
order by abs(dbo.dBuyAbs(0.01, Open_N1, Low_N1, CL_N1)-dbo.fBuyAbs(0.01, Open_N1, Low_N1, CL_N1)) desc

select symbol, date,
dbo.dBuyAbs(0.01, Open_N1, Low_N1, CL_N1) dBuyAbs,
CL, Open_N1, Low_N1, CL_N1 from vDayEoddataExtended where k1 is not null

select symbol, date,
dbo.fBuyAbs(0.01, Open_N1, Low_N1, CL_N1) fBuyAbs,
CL, Open_N1, Low_N1, CL_N1 from vDayEoddataExtended where k1 is not null

--====================================
select --TOP 5000
symbol, date,
dbo.fBuyAbs(0.01, Open_N1, Low_N1, CL_N1) fBuyAbs,
dbo.fBuyAbsPrice(0.01, Open_N1, Low_N1, CL_N1) fBuyAbsPrice,
dbo.fBuyPerc(0.1, CL, Open_N1, Low_N1, CL_N1) fBuyPerc,
dbo.fBuyPercPrice(0.1, CL, Open_N1, Low_N1, CL_N1) fBuyPercPrice,
dbo.fSellAbs(0.01, Open_N1, High_N1, CL_N1) fSellAbs,
dbo.fSellAbsPrice(0.01, Open_N1, High_N1, CL_N1) fSellAbsPrice,
dbo.fSellPerc(0.1, CL, Open_N1, High_N1, CL_N1) fSellPerc,
dbo.fSellPercPrice(0.1, CL, Open_N1, High_N1, CL_N1) fSellPercPrice,
CL, Open_N1, High_N1, Low_N1, CL_N1 from vDayEoddataExtended where k1 is not null

--===================
SELECT dbo.fSellAbsPrice(0.01, 149.46, 149.54, 145.17),
dbo.fSellPercPrice(0.1, 149.51, 149.46, 149.54, 145.17) 
-- =================
select 
symbol, date,
dbo.xfBuyAbsPrice(0.01, Open_N1, Low_N1, CL_N1) fBuyAbsPrice,
CL, Open_N1, High_N1, Low_N1, CL_N1 from vDayEoddataExtended where k1 is not null

select
symbol, date,
dbo.f3BuyAbsPrice(0.01, Open_N1, Low_N1, CL_N1) fBuyAbsPrice,
CL, Open_N1, High_N1, Low_N1, CL_N1 from vDayEoddataExtended where k1 is not null

select 
symbol, date,
dbo.xfBuyAbsPrice(0.01, Open_N1, Low_N1, CL_N1) fBuyAbsPrice,
dbo.f3BuyAbsPrice(0.01, Open_N1, Low_N1, CL_N1) f3BuyAbsPrice,
CL, Open_N1, High_N1, Low_N1, CL_N1 from vDayEoddataExtended where k1 is not null
and dbo.xfBuyAbsPrice(0.01, Open_N1, Low_N1, CL_N1)<>
dbo.f3BuyAbsPrice(0.01, Open_N1, Low_N1, CL_N1);

select 
symbol, date,
dbo.xfBuyAbs(0.01, Open_N1, Low_N1, CL_N1) fBuyAbs,
dbo.f3BuyAbs(0.01, Open_N1, Low_N1, CL_N1) f3BuyAbs,
dbo.xfBuyAbsPrice(0.01, Open_N1, Low_N1, CL_N1) fBuyAbsPrice,
dbo.f3BuyAbsPrice(0.01, Open_N1, Low_N1, CL_N1) f3BuyAbsPrice,
dbo.xfBuyPerc(0.1, CL, Open_N1, Low_N1, CL_N1) fBuyPerc,
dbo.f3BuyPerc(0.1, CL, Open_N1, Low_N1, CL_N1) f3BuyPerc,
dbo.xfBuyPercPrice(0.1, CL, Open_N1, Low_N1, CL_N1) fBuyPercPrice,
dbo.f3BuyPercPrice(0.1, CL, Open_N1, Low_N1, CL_N1) f3BuyPercPrice,
dbo.xfSellAbs(0.01, Open_N1, Low_N1, CL_N1) fSellAbs,
dbo.f3SellAbs(0.01, Open_N1, Low_N1, CL_N1) f3SellAbs,
dbo.xfSellAbsPrice(0.01, Open_N1, Low_N1, CL_N1) fSellAbsPrice,
dbo.f3SellAbsPrice(0.01, Open_N1, Low_N1, CL_N1) f3SellAbsPrice,
dbo.xfSellPerc(0.1, CL, Open_N1, Low_N1, CL_N1) fSellPerc,
dbo.f3SellPerc(0.1, CL, Open_N1, Low_N1, CL_N1) f3SellPerc,
dbo.xfSellPercPrice(0.1, CL, Open_N1, Low_N1, CL_N1) fSellPercPrice,
dbo.f3SellPercPrice(0.1, CL, Open_N1, Low_N1, CL_N1) f3SellPercPrice,
CL, Open_N1, High_N1, Low_N1, CL_N1
FROM vDayEoddataExtended where k1 is not null
and (dbo.xfBuyAbs(0.01, Open_N1, Low_N1, CL_N1)<>dbo.f3BuyAbs(0.01, Open_N1, Low_N1, CL_N1) or
dbo.xfBuyAbsPrice(0.01, Open_N1, Low_N1, CL_N1)<>dbo.f3BuyAbsPrice(0.01, Open_N1, Low_N1, CL_N1) or
dbo.xfBuyPerc(0.1, CL, Open_N1, Low_N1, CL_N1)<>dbo.f3BuyPerc(0.1, CL, Open_N1, Low_N1, CL_N1) or
dbo.xfBuyPercPrice(0.1, CL, Open_N1, Low_N1, CL_N1)<>dbo.f3BuyPercPrice(0.1, CL, Open_N1, Low_N1, CL_N1) or
dbo.xfSellAbs(0.01, Open_N1, Low_N1, CL_N1)<>dbo.f3SellAbs(0.01, Open_N1, Low_N1, CL_N1) or
dbo.xfSellAbsPrice(0.01, Open_N1, Low_N1, CL_N1)<>dbo.f3SellAbsPrice(0.01, Open_N1, Low_N1, CL_N1) or
dbo.xfSellPerc(0.1, CL, Open_N1, Low_N1, CL_N1)<>dbo.f3SellPerc(0.1, CL, Open_N1, Low_N1, CL_N1) or
dbo.xfSellPercPrice(0.1, CL, Open_N1, Low_N1, CL_N1)<>dbo.f3SellPercPrice(0.1, CL, Open_N1, Low_N1, CL_N1));

-- ====================
select
symbol, date,
dbo.xfBuyAbsPrice(0.01, Open_N1, Low_N1, CL_N1) fBuyAbsPrice,
dbo.f3BuyAbsPrice(0.01, Open_N1, Low_N1, CL_N1) f3BuyAbsPrice,
CL, 
Open_N1, 
CAST(CAST(Open_N1 as varchar(20)) as FLOAT) Varchar, 
ROUND(CAST(Open_N1 as FLOAT),4) Cast, 
CAST(FORMAT(Open_N1, 'G') as FLOAT) Format, 
CONVERT(VARCHAR(20), Open_N1) ConvertX, 
High_N1, Low_N1, CL_N1 from vDayEoddataExtended where k1 is not null
and ((symbol='ADI' and date='2022-01-13') 
or (symbol='TSLA' and date='2022-03-30')
or (symbol='TSLA' and date='2022-01-12')); 



