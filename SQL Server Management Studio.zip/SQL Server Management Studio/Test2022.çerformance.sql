-- 50/55 secs
-- Missing symbol/date in DayPolygon (Turnover > 1 mln): 25 secs
select ROUND(a.[Close]*a.Volume/1000000.0,1) EoddataTurnover, a.*, b.Symbol PolygonSymbol, b.Date SymbolDate, b.[To] SymbolTo, b.Name -- 963
from dbTest2022..DayEoddata a
inner join dbTest2022..SymbolsPolygon b on a.Symbol=b.EoddataSymbol and a.Date between b.Date and isnull(b.[To], '2099-12-31')
left join (SELECT * from dbTest2022..DayPolygon WHERE IsTest IS NULL and Date>'2022-01-01') c on c.Symbol=b.Symbol and c.Date=a.Date
where a.symbol not like '%TEST%' and a.Volume<>0 and c.Symbol is null
and a.[Close]*a.Volume/1000000.0>1.0
order by a.Date desc
-- 2024-01-18: 11 rows (or 963 rows without Turnover filter)

-- 26 secs
SELECT isnull(b.Recs,0)-isnull(a.Recs,0) RowsDifference, a.Date, a.Recs DayEoddataRows, b.Recs DayPolygonRows from
(select Date, count(*) Recs from dbTest2022..DayEoddata 
	WHERE Symbol not like '%TEST%' and Volume<>0 GROUP BY Date) a
FULL JOIN
(select Date, count(*) Recs from dbTest2022..DayPolygon
	WHERE IsTest is null and Volume<>0 and Date>'2022-01-01' GROUP BY Date) b on a.Date=b.Date
ORDER BY 2 DESC

-- 68/75 secs
select * from dbTest2022..DayPolygon where [open]>high or [open]<low or [close]>high or [close]<low or low<=0 or volume<0 or TradeCount<0;
-- 2024-01-18: 0 recs

-- Bad Open/High/Low/Close in DayEoddata: 1 secs
select * from dbTest2022..DayEoddata where [open]>high or [open]<low or [close]>high or [close]<low or low<0 or volume<0;
-- 2024-01-18: 0 recs

-- Trading days for DayPolygon: 13 secs
select a.* from dbTest2022..DayPolygon a left join dbTest2022..TradingDays b on a.Date=b.Date
where b.Date is null;
-- 2024-01-18: 0 recs

-- Trading days for DayEoddata: 1 secs
select a.* from dbTest2022..DayEoddata a left join dbTest2022..TradingDays b on a.Date=b.Date
where b.Date is null;
-- 2024-01-18: 0 recs

