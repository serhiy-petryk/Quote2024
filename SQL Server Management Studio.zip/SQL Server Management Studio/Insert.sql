INSERT INTO [DESKTOP-PC\SQLEXPRESS2014].[dbQ2023].[dbo].[DayPolygon]
select * from [dbQ2023].[dbo].[DayPolygon]



