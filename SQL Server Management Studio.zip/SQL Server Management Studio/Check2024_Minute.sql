USE dbQ2024;

-- Check for 'PARTIAL' loadings (Position='X'): 8 secs
select * from dbQ2024Minute..MinutePolygonLog where Position not in (2,3,4) or RowStatus not in (1,2,3,4,5)
-- 2024-01-20: 0 rows

/*-- Check of unique of date: 7 secs
SELECT date, min(Folder) MinFolder, max(Folder) MaxFolder, count(*) Recs,
 Min(symbol) MinSymbol, max(symbol) MaxSymbol
FROM dbQ2024Minute..MinutePolygonLog
WHERE RowStatus IN (2, 5) AND Date > DATEADD(YEAR, -1, getdate())
and date not in ('2024-07-01','2024-07-02','2024-07-03','2024-07-05') -- missing symbol/date in minute quotes
GROUP by date
having min(Folder)<>max(Folder)*/
/* Details of unique date check
select a.*
from (SELECT * FROM dbQ2024Minute..MinutePolygonLog 
	WHERE Folder='MP2003_20240727' and RowStatus IN (5) AND
		Date between '2024-07-22' and '2024-07-05') a
left join (SELECT * FROM dbQ2024Minute..MinutePolygonLog WHERE Folder='MP2003_20240713' and
		Date between '2024-07-01' and '2024-07-05') b
on a.Symbol=b.Symbol and a.Date=b.Date
where b.Symbol is null
UNION ALL
select a.*
from (SELECT * FROM dbQ2024Minute..MinutePolygonLog
	WHERE Folder='MP2003_20240713' and RowStatus IN (5) AND
		Date between '2024-07-01' and '2024-07-05') a
left join (SELECT * FROM dbQ2024Minute..MinutePolygonLog
	WHERE Folder='MP2003_20240706' and Date between '2024-07-01' and '2024-07-05') b
on a.Symbol=b.Symbol and a.Date=b.Date
where b.Symbol is null
*/
-- 2024-06-01: 0 rows

/*-- Summary of MinutePolygonLog: 20 secs
select folder, min(date) MinDate, max(date) MaxDate, count(*) Recs, 
CAST(ROUND(count(*)/((DATEDIFF(DAY, min(Date), Max(Date))+1.0) * 5 /7), 0) as int) RecsPerDay
from dbQ2024Minute..MinutePolygonLog group by folder order by 1 desc*/

-- Check RowStatus in MinutePolygonLog:  12 secs
select Folder, min(date) MinDate, max(Date) MaxDate, count(distinct Date) Days,
DateDiff(day, Min(date), Max(Date)) DayRange,
sum(iif (Rowstatus=2, 1,0)) RowStat2,
sum(iif (Rowstatus=3, 1,0)) RowStat3,
sum(iif (Rowstatus=4, 1,0)) RowStat4,
sum(iif (Rowstatus=5, 1,0)) RowStat5,
count(*) Rows,
count(*)/count(distinct Date) RecsPerDay,
min(symbol) MinSymbol, max(symbol) MaxSymbol
from dbQ2024Minute..MinutePolygonLog
where date > DATEADD(YEAR, -1, getdate())
group by folder order by 1 desc;

-- ===========================================
-- =====  Compare daily & minute quotes  =====
-- ===========================================
-- Missing Minute quotes: 33 secs (DayPolygon from 2016-01-01)
select a.* from
(select * FROM dbQ2024..DayPolygon
WHERE IsTest IS NULL AND Volume*[Close]>= 1000000 and tradecount>=1000 and Date>'2016-01-01') a
left join dbQ2024Minute..MinutePolygonLog b
on a.Symbol=b.Symbol and a.Date=b.Date
where b.Date is null order by a.Date desc
-- 2024-01-23: 16 rows (WTM)
-- 2024-03-02: 19 rows (WTM)
-- 2024-03-30: 22 rows (WTM)
-- 2024-05-04: 24 rows (WTM)
-- 2024-06-15: 25 rows (WTM + WINA)
-- 2024-09-07: 26 rows (WTM + WINA + ATRI)
-- 2024-09-28: 27 rows (WTM + WINA + ATRI)
-- 2024-10-19: 28 rows (WTM + WINA + ATRI)
-- 2024-11-23: 29 rows (WTM + WINA + ATRI)
-- 2024-11-30: 42 rows (WTM + WINA + ATRI) (13 rows at 2024-11-25,26,27) 
-- 2024-12-07: 30 rows
-- 2025-01-25: 163 rows (132 rows at 2025-01-24)
-- 2025-02-01: 32 rows
-- 2025-02-08: 210 rows (178 rows at 2025-02-06)
-- 2025-02-15: 92 rows (59 rows at 2025-02-13)

-- ==========================================
-- =====  Check symbol/date duplicates  =====
-- ==========================================
-- Compare duplicates: 34 secs (MinutePolygonLog from 2023-01-01)
select symbol, date, count(*) Recs, max([Close]*[Volume])/1000000 MaxTradeValue,
min(TradeCount) MinTradeCount, max(TradeCount) MaxTradeCount,
max(TradeCount)-min(TradeCount) TradeCountDiff,
min(Volume) MinVolume, max(Volume) MaxVolume,
max(Volume)-min(Volume) VolumeDiff,
min(folder) Folder1, max(folder) Folder2
from dbQ2024Minute..MinutePolygonLog
-- WHERE Date>'2016-01-01'
WHERE Date>'2023-01-01' and RowStatus<>1
group by symbol, date
having count(*)<>1 and ((max(TradeCount)-min(TradeCount))>5 or (max(Volume)-min(Volume))>10000 )
AND max(Volume*[Close])/1000000>40
-- and  max(TradeCount)-min(TradeCount)>1
order by date desc, 6 desc --date desc, symbol
-- 2024-01-23: 0 rows
-- 2024-02-10: 3 rows
-- 2024-02-24: 7 rows
-- 2024-03-02: 11 rows
-- 2024-03-23: 16 rows
-- 2024-03-30: 5 rows (added MaxTradeValue filter)
-- 2024-05-04: 22 rows
-- 2024-05-18: 23 rows
-- 2024-06-15: 24 rows
-- 2024-06-29: 25 rows
-- 2024-07-06: 27 rows
-- 2024-07-20: 28 rows
-- 2024-07-27: 29 rows
-- 2024-08-03: 29 rows (added in filter: RowStatus<>1)
-- 2024-08-31: 30 rows
-- 2024-09-07: 33 rows
-- 2024-09-21: 34 rows
-- 2024-09-28: 36 rows
-- 2024-10-05: 138 rows (102 rows for 2024-09-26)
-- 2024-10-19: 141 rows
-- 2024-11-16: 204 rows (63 rows from 2024-11-07 (61 rows at 2024-11-07 + 2 rows at 2024-11-08) with enough difference)
-- 2024-11-23: 473 rows (269 rows at 2024-11-15 with small difference)
-- 2024-11-30: 474 rows
-- 2024-12-07: 526 rows (many with small difference)
-- 2024-12-14: 527 rows
-- 2024-12-21: 528 rows
-- 2024-12-28: 619 rows (91 rows at 2024-12-20 with small difference)
-- 2025-01-11: 620 rows
-- 2025-01-25: 622 rows
-- 2025-02-01: 625 rows

-- Duplicates by date: 36 secs (MinutePolygonLog from 2016-01-01)
select date, count(*) Recs, max(MaxTradeValue) MaxTradeValue,
max(DiffVolume) MaxDiffVolume, max(DiffCount) MaxDiffCount,
avg(DiffVolumePercent) AvgDiffVolumePercent, avg(DiffCountPercent) AvgDiffCountPercent
from (select symbol, date, count(*) Recs, max([Close]*[Volume])/1000000 MaxTradeValue,
		(max(Volume)-min(Volume)) DiffVolume,
		(max([Count])-min([Count])) DiffCount,
		(max(Volume)-min(Volume))/(max(Volume)+min(Volume))/2*100 DiffVolumePercent,
		(max(1.0*[Count])-min([Count]))/(max([Count])+min([Count]))/2*100 DiffCountPercent
	from dbQ2024Minute..MinutePolygonLog
	WHERE Date>'2016-01-01' and RowStatus<>1
	group by symbol, date
	having max([Count])<>min([Count]) or (max(Volume)-min(Volume))>10000) x
group by date
having max(MaxTradeValue)>40
order by 1 desc
-- 2024-01-23: 0 rows
-- 2024-02-10: 1 row
-- 2024-02-16: 3 rows
-- 2024-02-24: 5 rows
-- 2024-03-02: 7 rows
-- 2024-03-09: 9 rows
-- 2024-03-30: 5 rows (added MaxTradeValue filter)
-- 2024-04-13: 7 rows
-- 2024-05-04: 14 rows
-- 2024-05-18: 15 rows
-- 2024-06-08: 16 rows
-- 2024-06-22: 17 rows
-- 2024-06-29: 18 rows
-- 2024-07-06: 20 rows
-- 2024-07-20: 21 rows
-- 2024-07-27: 22 rows
-- 2024-08-03: 22 rows (added in filter: RowStatus<>1)
-- 2024-08-31: 23 rows
-- 2024-09-07: 24 rows
-- 2024-09-21: 25 rows
-- 2024-09-28: 26 rows
-- 2024-10-05: 27 rows
-- 2024-10-19: 28 rows
-- 2024-11-16: 30 rows (2024-11-07 has 314 records of difference)
-- 2024-11-23: 32 rows (2024-11-15 has 481 records of difference)
-- 2024-11-30: 33 rows
-- 2024-12-07: 34 rows
-- 2024-12-14: 35 rows
-- 2024-12-21: 36 rows
-- 2024-12-28: 38 rows
-- 2025-01-11: 39 rows
-- 2025-01-25: 40 rows
-- 2025-02-01: 42 rows
-- 2025-02-06: 43 rows
