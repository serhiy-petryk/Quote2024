-- Summary by folder
select substring([file],1, charindex('\', [file])-1) Folder, count(*) Recs, min(date) MinDate,
min([timestamp]) MinTimeStasmp, max([timestamp]) MaxTimeStamp, min(created) MinCreated, max(created) MaxCreated
from FileLogMinuteAlphaVantage
group by substring([file],1, charindex('\', [file])-1) order by 1

select top 100 * from FileLogMinuteAlphaVantage where [file] like '%MinuteAlphaVantage_20230215%'

-- 40124
select count(*) from 
(select * from FileLogMinuteAlphaVantage where [file] like '%MinuteAlphaVantage_20230211%') a
left join (select * from FileLogMinuteAlphaVantage where [timestamp]<'2023-02-16') b 
on a.Symbol=b.Symbol and a.Date=b.Date
where b.Symbol is null

select distinct a.symbol, a.date from 
(select * from FileLogMinuteAlphaVantage where [file] like '%MinuteAlphaVantage_20230211%') a
inner join (select * from FileLogMinuteAlphaVantage) b 
on a.Symbol=b.Symbol and a.Date=b.Date

select count(*) from FileLogMinuteAlphaVantage where [file] like '%MinuteAlphaVantage_20230211%'