use dbQ2024;

-- Time: Wnd7-Sql2014, Wnd10-Sql2022, Wnd10-Sql2014
-- =================================
-- ===========  Tests  =============
-- =================================
-- Bad Open/High/Low/Close in DayPolygon: 15/26/20 secs
select * from dbQ2024..DayPolygon where [open]>high or [open]<low or [close]>high or [close]<low or low<=0 or volume<0 or TradeCount<0;
-- 2024-01-18: 0 recs

-- Bad Open/High/Low/Close in DayEoddata: 2/5/3 secs
select * from dbQ2024..DayEoddata where [open]>high or [open]<low or [close]>high or [close]<low or low<0 or volume<0;
-- 2024-01-18: 0 recs

-- Trading days for DayPolygon: 12/28/13 secs
select a.* from dbQ2024..DayPolygon a left join dbQ2024..TradingDays b on a.Date=b.Date
where b.Date is null;
-- 2024-01-18: 0 recs

-- Trading days for DayEoddata: 2/4/4 secs
select a.* from dbQ2024..DayEoddata a left join dbQ2024..TradingDays b on a.Date=b.Date
where b.Date is null;
-- 2024-01-18: 0 recs

-- ============================================
-- ===========  Link Day->Symbol  =============
-- ============================================
-- Must be 0 rows!!! Link DayPolygon -> SymbolsPolygon: 8 secs for last year; 7/17/9 secs
select a.*
from dbQ2024..DayPolygon a
left join dbQ2024..SymbolsPolygon b on a.Symbol=b.Symbol and a.Date between b.Date and isnull(b.[To], '2099-12-31')
where a.IsTest is null and b.Symbol is null
and a.Date > DATEADD(YEAR, -1, GetDate())
-- 2024-01-18: 0 rows

-- Link DayEoddaata -> SymbolsPolygon: 18/36/31 secs
select a.Volume*a.[Close]/1000000 TradeValue,  a.* 
from dbQ2024..DayEoddata a
left join dbQ2024..SymbolsPolygon b on a.Symbol=b.EoddataSymbol and a.Date between b.Date and isnull(b.[To], '2099-12-31')
where a.Symbol not like '%TEST%' and a.Volume<>0 and b.Symbol is null
and NOT(a.Symbol='VHA.X' and a.Date<'2024-06-01')
order by a.Date desc, a.Symbol
-- 2024-01-18: 17 rows
-- 2024-02-24: 19 rows (VHA.X/AMEX/2024-02-23, VHA.X/AMEX/2024-02-22)
-- 2024-03-02: 17 rows
-- 2024-06-08: 21 rows (added VHA-B: VHAI-WB (Polygon) was VHA.X before 06-2024 and VHA-B after 06-2024)
-- 2024-06-15: 17 rows (after sql correction: and NOT(a.Symbol='VHA.X' and a.Date<'2024-06-01'))

-- ============================================
-- ===========  Link Day->Day  =============
-- ============================================

-- Compare Eoddata&Polygon day count by date: 10/24/18 secs
SELECT isnull(b.Recs,0)-isnull(a.Recs,0) RowsDifference, a.Date, a.Recs DayEoddataRows, b.Recs DayPolygonRows from
(select Date, count(*) Recs from dbQ2024..DayEoddata 
	WHERE Symbol not like '%TEST%' and Volume<>0 GROUP BY Date) a
FULL JOIN
(select Date, count(*) Recs from dbQ2024..DayPolygon
	WHERE IsTest is null and Volume<>0 and Date>'2022-01-01' GROUP BY Date) b on a.Date=b.Date
ORDER BY 2 DESC
-- many diferences from 2024-11-27

-- Missing symbol/date in DayPolygon (Turnover > 1 mln): 22/47/35 secs
select ROUND(a.[Close]*a.Volume/1000000.0,1) EoddataTurnover, a.*, b.Symbol PolygonSymbol, b.Date SymbolDate, b.[To] SymbolTo, b.Name -- 963
from dbQ2024..DayEoddata a
inner join SymbolsPolygon b on a.Symbol=b.EoddataSymbol and a.Date between b.Date and isnull(b.[To], '2099-12-31')
left join (SELECT * from DayPolygon WHERE IsTest IS NULL and Date>'2022-01-01') c on c.Symbol=b.Symbol and c.Date=a.Date
where a.symbol not like '%TEST%' and a.Volume<>0 and c.Symbol is null
and a.[Close]*a.Volume/1000000.0>1.0
order by a.Date desc
-- 2024-01-18: 11 rows (or 963 rows without Turnover filter)
-- 2024-08-31: 12 rows
-- 2024-09-21: 13 rows

-- Missing symbol/date in DayEoddata (Turnover > 1 mln): 23/55/31 secs
select ROUND(a.[Close]*a.Volume/1000000.0,1) TradeValue, b.EoddataSymbol, a.* -- 59819/2178(2023-01-01)
 from DayPolygon a
inner join SymbolsPolygon b on a.Symbol=b.Symbol and a.Date between b.Date and isnull(b.[To], '2099-12-31')
left join dbQ2024..DayEoddata c on b.EoddataSymbol=c.Symbol and a.Date=c.Date
where a.IsTest is null and a.Volume<>0 and a.Date>'2022-01-01' and c.Symbol is null
and a.[Close]*a.Volume/1000000.0>1.0
order by a.Date desc, a.Symbol
-- 2024-01-18: 17'331 rows (or 59'813 rows without Turnover filter)
-- 2024-03-09: 17'342 rows
-- 2024-03-16: 17'345 rows
-- 2024-05-18: 17'373 rows
-- 2024-07-06: 17'393 rows
-- 2024-08-03: 17'397 rows
-- 2024-08-10: 17'398 rows
-- 2024-08-17: 17'400 rows
-- 2024-08-24: 17'402 rows
-- 2024-08-31: 17'403 rows
-- 2024-09-07: 17'404 rows
-- 2024-09-21: 17'406 rows
-- 2024-09-28: 17'410 rows
-- 2024-10-12: 17'484 rows
-- 2024-10-18: 17'488 rows
-- 2024-10-26: 17'489 rows
-- 2024-11-02: 17'498 rows
-- 2024-11-09: 17'499 rows
-- 2024-11-16: 17'500 rows
-- 2024-11-23: 17'501 rows
-- 2024-11-30: 23639 rows (missing day Eoddata for AMEX,Nasdaq for 2024-11-27,29)
-- 2024-12-06: many rows -> missing data from 2024-11-27
-- 2024-12-14: 41775 rows
-- 2024-12-21: 42002 rows
-- 2024-12-28: 42173 rows
-- 2025-01-04: 42390 rows
-- 2025-01-11: 42394 rows
-- 2025-01-18: 42396 rows
-- 2025-01-25: 42397 rows
-- 2025-02-01: 42398 rows
-- 2025-02-08: 42416 rows
-- 2025-02-15: 42419 rows
 
-- Different Open/High/Low/Close in day tables: 108 secs
-- Wnd7: 28:05,29:10; Wnd10: 4:17,5:01
-- (inner merge join Hints) 2:37; Wnd10: 3:13
-- (inner loop join Hints) 2:01; Wnd10: 2:21; Wnd10-Sql2014: 2:11
select *
from dbQ2024..DayEoddata a
inner loop join SymbolsPolygon b on a.Symbol=b.EoddataSymbol and a.Date between b.Date and isnull(b.[To], '2099-12-31')
inner loop join (SELECT * from DayPolygon WHERE IsTest IS NULL and Date>'2022-01-01') c
	on c.Symbol=b.Symbol and c.Date=a.Date
where a.symbol not like '%TEST%' and a.Volume<>0 
and a.[Open] not between 0.9*c.[Open] and 1.1*c.[Open] -- 1329 rows
and a.[High] not between 0.9*c.[High] and 1.1*c.[High] -- 559 rows
and a.[Low] not between 0.9*c.[Low] and 1.1*c.[Low] -- 766 rows
and a.[Close] not between 0.9*c.[Close] and 1.1*c.[Close] -- 637 rows
and (a.[Close]*a.[Volume]>1000000.0 or c.[Close]*c.[Volume]>1000000.0) -- 0 rows
order by a.Date desc, a.Symbol
-- 2024-01-18: 0 rows (304 rows without turnover filter)
