use dbPolygon2003;

-- missing dates in SymbolsPolygon 
select c.Mindate, a.* 
from DayPolygon a
left join SymbolsPolygon b on a.Symbol=b.Symbol and a.Date between b.Date and isnull(b.[To], GetDate())
inner join (select symbol, min(date) MinDate from SymbolsPolygon group by symbol) c on a.Symbol=c.Symbol
where b.Symbol is null

-- check date duplicates in SymbolsPolygon
select *
from SymbolsPolygon a
inner join SymbolsPolygon b on a.Symbol=b.Symbol and b.Date between a.Date and isnull(a.[To],GetDate())
where a.Date<>b.Date

-- exec pUpdateSymbolsPolygon;