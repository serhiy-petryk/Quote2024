-- =======  Big volume  =======

--select * from DayYahoo2013 where Symbol='CTEL'

use dbQuote2022;

/*drop table Temp_Query003;

select a.*,
(p1.[Close]+p2.[Close]+p3.[Close]+p4.[Close]+p5.[Close]+p6.[Close]+p7.[Close])/7.0 as AverCL, 
(p1.[Volume]+p2.[Volume]+p3.[Volume]+p4.[Volume]+p5.[Volume]+p6.[Volume]+p7.[Volume])/7.0 as AverVOL,
(SELECT Max(v) FROM (VALUES (p1.Volume),(p2.Volume),(p3.Volume),(p4.Volume),(p5.Volume),(p6.Volume),(p7.Volume)) AS value(v)) as [MaxPVol],
(SELECT Min(v) FROM (VALUES (p1.Volume),(p2.Volume),(p3.Volume),(p4.Volume),(p5.Volume),(p6.Volume),(p7.Volume)) AS value(v)) as [MinPVol],
(SELECT Max(v) FROM (VALUES (p1.High),(p2.High),(p3.High),(p4.High),(p5.High),(p6.High),(p7.High)) AS value(v)) as [MaxPHigh],
(SELECT Min(v) FROM (VALUES (p1.Low),(p2.Low),(p3.Low),(p4.Low),(p5.Low),(p6.Low),(p7.Low)) AS value(v)) as [MinPLow],
p1.[Open] Open_P1, p1.High High_P1, p1.Low Low_P1, p1.[Close] Close_P1, p1.Volume Volume_P1, 
n1.[Open] Open_N1, n1.High High_N1, n1.Low Low_N1, n1.[Close] Close_N1, n1.Volume Volume_N1,
n2.[Open] Open_N2, n2.High High_N2, n2.Low Low_N2, n2.[Close] Close_N2, n2.Volume Volume_N2,
n3.[Open] Open_N3, n3.High High_N3, n3.Low Low_N3, n3.[Close] Close_N3, n3.Volume Volume_N3,
n4.[Open] Open_N4, n4.High High_N4, n4.Low Low_N4, n4.[Close] Close_N4, n4.Volume Volume_N4,
n5.[Open] Open_N5, n5.High High_N5, n5.Low Low_N5, n5.[Close] Close_N5, n5.Volume Volume_N5
into Temp_Query003
from vDayYahoo2013 a

inner join TradingDays d on d.Date=a.Date
inner join vDayYahoo2013 p1 on p1.Symbol=a.Symbol and p1.Date=d.Prev1
inner join vDayYahoo2013 p2 on p2.Symbol=a.Symbol and p2.Date=d.Prev2
inner join vDayYahoo2013 p3 on p3.Symbol=a.Symbol and p3.Date=d.Prev3
inner join vDayYahoo2013 p4 on p4.Symbol=a.Symbol and p4.Date=d.Prev4
inner join vDayYahoo2013 p5 on p5.Symbol=a.Symbol and p5.Date=d.Prev5
inner join vDayYahoo2013 p6 on p6.Symbol=a.Symbol and p6.Date=d.Prev6
inner join vDayYahoo2013 p7 on p7.Symbol=a.Symbol and p7.Date=d.Prev7

inner join vDayYahoo2013 n1 on n1.Symbol=a.Symbol and n1.Date=d.Next1
left join vDayYahoo2013 n2 on n2.Symbol=a.Symbol and n2.Date=d.Next2
left join vDayYahoo2013 n3 on n3.Symbol=a.Symbol and n3.Date=d.Next3
left join vDayYahoo2013 n4 on n4.Symbol=a.Symbol and n4.Date=d.Next4
left join vDayYahoo2013 n5 on n5.Symbol=a.Symbol and n5.Date=d.Next5
WHERE p1.Volume>0 and p2.Volume>0 and p3.Volume>0 and p4.Volume>0 and p5.Volume>0 and p6.Volume>0 and p7.Volume>0;
*/

select count(*) from Temp_Query003
where [Close] >=5 and Volume > 300000; -- 1819761

/* drop view vDayYahoo2013BigVolume;
create view vDayYahoo2013BigVolume as 
select 1 Cnt, Open_N1/Close_N1 R1, Open_N1/Close_N2 R2, Open_N1/Close_N3 R3, Open_N1/Close_N4 R4, Open_N1/Close_N5 R5, 
Volume/AverVOL VolToAver, MaxPVol/AverVOL MaxPVolToAver, [Close]/ AverCl CloseToAver, [Close]/ [Open] CloseToOpen, a.*
from Temp_Query003 a
where [Close] >=1 and Volume > 300000  and Volume > 2* AverVOL and AverVOL > 50000 and MinPVol>1;*/

-- !!! G2=9 (CloseToAver>1.10)

select G0, G1, G2, G3, G4, count(*) as Cnt,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, 
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5
from
(select 
iif(VolToAver<2.087, 0, iif(VolToAver<2.19, 1, iif(VolToAver<2.32, 2, iif(VolToAver<2.48, 3, iif(VolToAver<2.69, 4, iif(VolToAver<2.99, 5, iif(VolToAver<3.435, 6, iif(VolToAver<4.22, 7, iif(VolToAver<6.01, 8, 9))))))))) as G0,
iif(MaxPVolToAver<1.3,0, iif(MaxPVolToAver<1.39,1, iif(MaxPVolToAver<1.47,2, iif(MaxPVolToAver<1.55,3, iif(MaxPVolToAver<1.645,4, iif(MaxPVolToAver<1.76,5, iif(MaxPVolToAver<1.91,6, iif(MaxPVolToAver<2.14,7, iif(MaxPVolToAver<2.585,8,9))))))))) as G1,
iif(CloseToAver<0.915,0, iif(CloseToAver<0.95,1, iif(CloseToAver<0.974,2, iif(CloseToAver<0.99,3, iif(CloseToAver<1,4, iif(CloseToAver<1.017,5, iif(CloseToAver<1.035,6, iif(CloseToAver<1.06,7, iif(CloseToAver<1.106,8,9))))))))) as G2,
iif(CloseToOpen<0.9523196,0, iif(CloseToOpen<0.9742948,1, iif(CloseToOpen<0.9866623,2, iif(CloseToOpen<0.9950334,3, iif(CloseToOpen<1.000579,4, iif(CloseToOpen<1.007083,5, iif(CloseToOpen<1.016453,6, iif(CloseToOpen<1.030835,7, iif(CloseToOpen<1.056931,8,9))))))))) as G3,
iif([Close]<3.01,0, iif([Close]<5.72,1, iif([Close]<9.07,2, iif([Close]<13.16,3, iif([Close]<17.82,4, iif([Close]<23.45,5, iif([Close]<30.23,6, iif([Close]<40.18,7, iif([Close]<56.64,8,9))))))))) as G4,
* from vDayYahoo2013BigVolume) x
group by G0, G1, G2, G3, G4
having avg(r1)>1.05
order by 6 desc, 1,2,3,4,5;

select count(*) as Cnt, 
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, 
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5
from
(select 
iif(VolToAver<2.087, 0, iif(VolToAver<2.19, 1, iif(VolToAver<2.32, 2, iif(VolToAver<2.48, 3, iif(VolToAver<2.69, 4, iif(VolToAver<2.99, 5, iif(VolToAver<3.435, 6, iif(VolToAver<4.22, 7, iif(VolToAver<6.01, 8, 9))))))))) as G0,
iif(MaxPVolToAver<1.3,0, iif(MaxPVolToAver<1.39,1, iif(MaxPVolToAver<1.47,2, iif(MaxPVolToAver<1.55,3, iif(MaxPVolToAver<1.645,4, iif(MaxPVolToAver<1.76,5, iif(MaxPVolToAver<1.91,6, iif(MaxPVolToAver<2.14,7, iif(MaxPVolToAver<2.585,8,9))))))))) as G1,
iif(CloseToAver<0.915,0, iif(CloseToAver<0.95,1, iif(CloseToAver<0.974,2, iif(CloseToAver<0.99,3, iif(CloseToAver<1,4, iif(CloseToAver<1.017,5, iif(CloseToAver<1.035,6, iif(CloseToAver<1.06,7, iif(CloseToAver<1.106,8,9))))))))) as G2,
iif(CloseToOpen<0.9523196,0, iif(CloseToOpen<0.9742948,1, iif(CloseToOpen<0.9866623,2, iif(CloseToOpen<0.9950334,3, iif(CloseToOpen<1.000579,4, iif(CloseToOpen<1.007083,5, iif(CloseToOpen<1.016453,6, iif(CloseToOpen<1.030835,7, iif(CloseToOpen<1.056931,8,9))))))))) as G3,
iif([Close]<3.01,0, iif([Close]<5.72,1, iif([Close]<9.07,2, iif([Close]<13.16,3, iif([Close]<17.82,4, iif([Close]<23.45,5, iif([Close]<30.23,6, iif([Close]<40.18,7, iif([Close]<56.64,8,9))))))))) as G4,
* from vDayYahoo2013BigVolume) x
order by 1;

select * from
(select 
iif(VolToAver<2.087, 0, iif(VolToAver<2.19, 1, iif(VolToAver<2.32, 2, iif(VolToAver<2.48, 3, iif(VolToAver<2.69, 4, iif(VolToAver<2.99, 5, iif(VolToAver<3.435, 6, iif(VolToAver<4.22, 7, iif(VolToAver<6.01, 8, 9))))))))) as G0,
iif(MaxPVolToAver<1.3,0, iif(MaxPVolToAver<1.39,1, iif(MaxPVolToAver<1.47,2, iif(MaxPVolToAver<1.55,3, iif(MaxPVolToAver<1.645,4, iif(MaxPVolToAver<1.76,5, iif(MaxPVolToAver<1.91,6, iif(MaxPVolToAver<2.14,7, iif(MaxPVolToAver<2.585,8,9))))))))) as G1,
iif(CloseToAver<0.915,0, iif(CloseToAver<0.95,1, iif(CloseToAver<0.974,2, iif(CloseToAver<0.99,3, iif(CloseToAver<1,4, iif(CloseToAver<1.017,5, iif(CloseToAver<1.035,6, iif(CloseToAver<1.06,7, iif(CloseToAver<1.106,8,9))))))))) as G2,
iif(CloseToOpen<0.9523196,0, iif(CloseToOpen<0.9742948,1, iif(CloseToOpen<0.9866623,2, iif(CloseToOpen<0.9950334,3, iif(CloseToOpen<1.000579,4, iif(CloseToOpen<1.007083,5, iif(CloseToOpen<1.016453,6, iif(CloseToOpen<1.030835,7, iif(CloseToOpen<1.056931,8,9))))))))) as G3,
iif([Close]<3.01,0, iif([Close]<5.72,1, iif([Close]<9.07,2, iif([Close]<13.16,3, iif([Close]<17.82,4, iif([Close]<23.45,5, iif([Close]<30.23,6, iif([Close]<40.18,7, iif([Close]<56.64,8,9))))))))) as G4,
* from vDayYahoo2013BigVolume) x
where G0=4 and G1=8 and G2=0 and G3=1 and G4=0;


-- =============================================
select 1 Cnt, Open_N1/Close_N1 R1, Open_N1/Close_N2 R2, Open_N1/Close_N3 R3, Open_N1/Close_N4 R4, Open_N1/Close_N5 R5, 
Volume/AverVOL VolToAver, MaxPVol/AverVOL MaxPVolToAver, [Close]/ AverCl CloseToAver, [Close]/ [Open] CloseToOpen, a.*
from Temp_Query003 a
where [Close] >=1 and Volume > 300000  and Volume > 2* AverVOL and AverVOL > 50000-- all
-- where [Close] >=1 and Volume > 300000 and Volume > 5 * AverVOL and [MaxPVol]< 2* AverVOL and [Close] > 1.5 * AverCl and [Open]<[Close] -- 159 recs, open/close_n1 average = 1.047, open/close_n2 average = 1.082
--where [Close] >=1 and [Close]<5 and Volume > 300000 and Volume > 5 * AverVOL and [MaxPVol]< 2* AverVOL and [Close] > 1.5 * AverCl and [Open]<[Close] -- 86 recs, open/close_n1 average = 1.080, open/close_n2 average = 1.135, open/close_n3 average = 1.157
-- where [Close] >=1 and [Close]<5 and Volume > 300000 and Volume > 3 * AverVOL and [MaxPVol]< 2* AverVOL and [Close] > 1.5 * AverCl and [Open]<[Close] and Close_N5 is not null -- 96 recs, open/close_n1 average = 1.076, open/close_n2 average = 1.132, open/close_n3 average = 1.157
-- where [Close] >=1 and [Close]<5 and Volume > 300000 and Volume > 5 * AverVOL and [MaxPVol]< 2* AverVOL and [Close] < 0.7 * AverCl and [Open]>[Close] -- 134 recs, open/close_n1 average = 1.036, open/close_n2 average = 1.051, open/close_n3 average = 1.058
-- where [Close] >=5 and Volume > 300000 and Volume > 5 * AverVOL and [MaxPVol]< 2* AverVOL and [Close] > 1.5 * AverCl and [Open]<[Close] -- 73 recs, open/close_n1 average = 1.008
-- where [Close] >=5 and Volume > 300000 and Volume > 5 * AverVOL and [MaxPVol]< 2* AverVOL and [Close] > 1.2 * AverCl and [Open]<[Close] -- 700 recs, open/close_n1 average = 0.9996

