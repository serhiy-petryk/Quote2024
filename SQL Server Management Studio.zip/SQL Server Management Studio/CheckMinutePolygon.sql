USE dbQ2023;

-- Check for 'PARTIAL' loadings
select * from FileLogMinutePolygon where position='PARTIAL'

 -- 13 secs
select a.* from
(select * FROM dbQ2023..DayPolygon
WHERE Volume*[Close]>= 5000000 and tradecount>1000) a
left join dbQ2023..FileLogMinutePolygon b
on a.Symbol=b.Symbol and a.Date=b.Date
where b.Date is null order by a.Date desc
-- 2023-12-14: 14 records (WTM)
-- 2023-12-30: 15 records (WTM)
-- 2024-01-27: 17 records (WTM)

-- Check: all minute data is downloaded (~ 4:30 min/2:35; 25 secs - SSD)
select a.* from
(select * FROM dbQ2023..DayPolygon
 WHERE Volume*[Close]>= 5000000 and Date >= DATEADD(day, -14, GetDate())) a
left join dbQ2023..FileLogMinutePolygon b
on a.Symbol=b.Symbol and a.Date=b.Date
where b.Date is null
-- 2023-04-04: 1 record (USPX, 2023-03-31)
-- 2023-04-22: 1 record (UNIY, 2023-04-11)
-- 2023-04-29: 0 record
-- 2023-05-06: 1 record (WTM, 2023-05-03)
-- 2023-05-20: 1 record (IQSM, 2023-05-17)
-- 2023-06-03: 0 record
-- 2023-06-17: 1 record (CLRG, 2023-06-16)
-- 2023-07-01: 3 records (BUJAU/2023-06-28, GENK/2023-06-28, WTM/2023-06-27)
-- 2023-07-08: 2 records (WTM/2023-06-27, 2023-07-07)
-- 2023-07-15: 3 records (CLRG/2023-07-11, IQSM/2023-07-11, WTM/2023-07-07)
-- 2023-07-15: 2 records (CLRG/2023-07-11, IQSM/2023-07-11)
-- 2023-08-05: 2 records (WTM/2023-07-28, WTM/2023-08-01)
-- 2023-08-12: 3 records (CLRG/2023-08-10, IQSM/2023-08-10, WTM/2023-08-01)
-- 2023-09-02: 2 records (WTM/2023-08-30, WTM/2023-09-01)
-- 2023-09-09: 4 records (WTM/2023-08-30, WTM/2023-09-01, WTM/2023-09-05, WTM/2023-09-06)
-- 2023-09-16: 3 records (WTM/2023-09-05, WTM/2023-09-06, WTM/2023-09-11)
-- 2023-09-23: 2 records (WTM/2023-09-11, WTM/2023-09-20)
-- 2023-09-30: 1 record (WTM/2023-09-20)
-- 2023-10-14: 4 record (BBEM/2023-10-03, CLRG/2023-10-11, DARP/2023-10-05, IQSM/2023-10-11)
-- 2023-11-04: 1 record (WTM/2023-10-26)
-- 2023-11-11: 0 record
-- 2023-11-18: 1 record (CLRG/2023-11-17)
-- 2023-12-20: 2 records (WTM/2023-12-19, WTM/2023-12-27)

-- non-existing symbols/dates
select *
from FileLogMinutePolygon a
left join SymbolsPolygon b on a.Symbol=b.Symbol and a.Date between b.Date and isnull(b.[To], GetDate())
where b.Symbol is null and a.Date>='2018-03-27'
order by a.date desc
-- 2023-06-01: 3307 recs
-- 2023-06-03: 3007 recs
-- 2023-06-17: 3008 recs
-- 2023-06-24: 3010 recs
-- 2023-07-22: 3022 recs
-- 2023-08-05: 3053 recs
-- 2023-08-12: 3056 recs
-- 2023-09-02: 3061 recs
-- 2023-09-30: 3066 recs
-- 2023-10-14: 3067 recs
-- 2023-10-21: 3076 recs
-- 2023-10-28: 3084 recs
-- 2023-12-14: 2967 recs
-- 2023-12-30: 3052 recs
-- 2024-01-06: 3061 recs
-- 2024-01-13: 3080 recs
-- 2024-01-20: 3087 recs
-- 2024-01-27: 3108 recs

-- Compare duplicates (40 secs; 2-8 secs - SSD,  (~35 secs))
select symbol, date, count(*) Recs, min(TradeCount) MinTradeCount, max(TradeCount) MaxTradeCount,
max(TradeCount)-min(TradeCount) TradeCountDiff,
min(VolumeFull) MinVolume, max(VolumeFull) MaxVolume,
max(VolumeFull)-min(VolumeFull) VolumeDiff,
min(folder) Folder1, max(folder) Folder2
from dbQ2023..FileLogMinutePolygon
where folder not like 'MinutePolygon2023_%'
group by symbol, date
having (min(TradeCount)<>max(TradeCount)/* or min(VolumeFull)<>max(VolumeFull)*/)
-- and (min(folder) like 'MinutePolygon2023_%' or max(folder) like 'MinutePolygon2023_%')
-- and  max(TradeCount)-min(TradeCount)>1
order by date desc, symbol
-- 2023-04-16: 180 recs
-- 2023-04-22: 1325 recs
-- 2023-04-29: 2288 recs
-- 2023-05-06: 3621 recs
-- 2023-05-13: 4885 recs
-- 2023-05-20: 6027 recs
-- 2023-05-27: 6619 recs
-- 2023-06-03: 10433 recs
-- 2023-06-10: 10460 recs
-- 2023-06-17: 10479 recs
-- 2023-06-24: 10498 recs
-- 2023-07-01: 10634 recs
-- 2023-07-08: 10644 recs
-- 2023-07-15: 10663 recs
-- 2023-07-22: 10801 recs
-- 2023-08-05: 10814 recs
-- 2023-08-12: 10828 recs
-- 2023-08-19: 10834 recs
-- 2023-08-26: 10850 recs
-- 2023-09-02: 10861 recs
-- 2023-09-09: 10882 recs
-- 2023-09-16: 10903 recs
-- 2023-09-23: 10919 recs
-- 2023-09-30: 10938 recs
-- 2023-10-07: 11248 recs
-- 2023-10-14: 11298 recs
-- 2023-10-21: 11306 recs
-- 2023-10-28: 11316 recs
-- 2023-11-04: 11333 recs
-- 2023-11-11: 11415 recs
-- 2023-11-18: 11419 recs
-- 2023-11-25: 11438 recs
-- 2023-12-02: 11439 recs
-- 2023-12-14: 228'508 recs
-- 2023-12-30: 11509 recs
-- 2024-01-13: 11523 recs
-- 2024-01-20: 11560 recs
-- 2024-01-27: 11968 recs (11500 - only TradeCount difference)

 -- (~35 secs)
select a.symbol, a.date, count(*) Recs, min(a.TradeCount),max(a.TradeCount), min(a.VolumeFull), max(a.VolumeFull),
min(a.folder), max(a.folder)
from dbQ2023..FileLogMinutePolygon a
inner join dbQ2023..SymbolsPolygon b on a.Symbol=b.Symbol and a.Date between b.Date and isnull(b.[To], GetDate())
group by a.symbol, a.date
having min(a.TradeCount)<>max(a.TradeCount) or min(a.VolumeFull)<>max(a.VolumeFull)
order by 2, 1

-- Duplicates by date (~11 secs)
select date, count(*)
from (select symbol, date, count(*) Recs
from dbQ2023..FileLogMinutePolygon
where folder not like 'MinutePolygon2023_%'
group by symbol, date
having min([Count])<>max([Count]) or min(Volume)<>max(Volume)) x
group by date
order by 1 desc

-- New symbol & date (~3 secs)
select a.* from 
(select * from FileLogMinutePolygon where folder='MinutePolygon_20240127') a
left join (select * from FileLogMinutePolygon where folder<>'MinutePolygon_20240127') b
on a.Symbol=b.Symbol and a.Date=b.Date
where b.Date is null
order by 3, 4
-- 2023-04-22: 21881
-- 2023-04-29: 21964
-- 2023-05-06: 23060
-- 2023-05-13: 22798
-- 2023-05-20: 22239
-- 2023-05-27: 21432
-- 2023-06-03: 18702
-- 2023-06-10: 22322
-- 2023-06-17: 23680
-- 2023-06-24: 20846
-- 2023-07-01: 24480
-- 2023-07-08: 17358
-- 2023-07-15: 21548
-- 2023-07-22: 22061
-- 2023-08-05: 47631
-- 2023-08-12: 22586
-- 2023-08-26: 21143
-- 2023-09-02: 21081
-- 2023-09-09: 16869
-- 2023-09-16: 22219
-- 2023-09-23: 22228
-- 2023-09-30: 22110
-- 2023-10-07: 21550
-- 2023-11-04: 22427
-- 2023-11-25: 17161
-- 2023-12-16: 51268 -> downloaded all symbols
-- 2023-12-30: 17543
-- 2024-01-06: 81496 -> downloaded all symbols
-- 2024-01-06: 50555 -> downloaded all symbols

-- Difference (~ 3 secs)
select (a.CountFull-b.CountFull) DiffCountFull, a.CountFull, 
(a.VolumeFull-b.VolumeFull) DiffVolumeFull, a.Volume,
* from 
(select * from FileLogMinutePolygon where folder='MinutePolygon_20240127') a
inner join (select * from FileLogMinutePolygon where folder<>'MinutePolygon_20240127') b
on a.Symbol=b.Symbol and a.Date=b.Date
WHERE (a.CountFull-b.CountFull)<>0 or (a.VolumeFull-b.VolumeFull)<>0
order by 1
-- 2023-05-20 (TOP 2023-05-12 (count diff: -23)
-- 2023-05-27 (TOP 2023-05-12 (count diff: -592)
-- 2023-06-03 (~3800 differences with count>1)
-- 2023-06-10: 27 rows 
-- 2023-06-19: 19 rows 
-- 2023-07-01: 136 rows 
-- 2023-07-08: 10 rows 
-- 2023-07-15: 19 rows 
-- 2023-07-22: 138 rows 
-- 2023-08-05: 13 rows 
-- 2023-08-12: 14 rows 
-- 2023-09-09: 21 rows
-- 2023-09-23: 16 rows
-- 2023-09-30: 19 rows
-- 2023-10-07: 310 rows (309 rows has DiffCountFull = -1)
-- 2023-10-14: 50 rows (all rows has DiffCountFull = -1)
-- 2023-10-21: 8 rows
-- 2023-11-04: 17 rows
-- 2023-11-11: 82 rows (2 rows has DiffCountFull=-2, other rows has DiffCountFull=-1)
-- 2023-11-18: 4 rows
-- 2023-11-25: 19 rows (2 rows has DiffCountFull=-2, other rows has DiffCountFull=-1)
-- 2023-12-02: 1 row
-- 2023-12-16: 17 rows (1 row has DiffCountFull=-2, other rows has DiffCountFull=-1)
-- 2023-12-23: 37 rows (4 rows has DiffCountFull=-2, other rows has DiffCountFull=-1)
-- 2023-12-30: 6 rows (CUEN/2023-12-22 row has DiffCountFull=-22, other rows has DiffCountFull=-1)
-- 2024-01-06: 4 rows
-- 2024-01-20: 37 rows
-- 2024-01-27: 408 rows (most of all are small volume difference)

-- =========================================
-- Zip Log
-- =========================================
-- Last 2 weeks: Check missing symbol/date from DayPolygon and ZipLogMinutePolygon (~2 secs)
select a.* from
(select * FROM dbQ2023..DayPolygon
 WHERE Volume*[Close]>= 5000000 and Date >= DATEADD(day, -14, GetDate())) a
left join dbQ2023..ZipLogMinutePolygon b
on a.Symbol=b.Symbol and a.Date=b.Date
where b.Date is null
order by a.Symbol, a.Date

-- 2023-04-16: 1 record (USPX,2023-03-31)
-- 2023-04-22: 1 record (UNIY,2023-04-11)
-- 2023-04-29: 0 record
-- 2023-05-06: 1 record (WTM, 2023-05-03)
-- 2023-05-20: 1 record (IQSM, 2023-05-17)
-- 2023-06-17: 2 records (CLRG/2023-06-16, WKC/2023-06-16)
-- 2023-06-24: 1 records (CLRG/2023-06-16)
-- 2023-07-01: 3 records (BUJAU/2023-06-28, GENK/2023-06-28, WTM/2023-06-27)
-- 2023-07-08: 2 records (WTM/2023-06-27, 2023-07-07)
-- 2023-07-15: 3 records (CLRG/2023-07-11, IQSM/2023-07-11, WTM/2023-07-07)
-- 2023-07-22: 2 records (CLRG/2023-07-11, IQSM/2023-07-11)
-- 2023-08-05: 2 records (WTM/2023-07-28, WTM/2023-08-01)
-- 2023-08-12: 3 records (CLRG/2023-08-10, IQSM/2023-08-10, WTM/2023-08-01)
-- 2023-09-02: 2 records (WTM/2023-08-30, WTM/2023-09-01)
-- 2023-09-09: 4 records (WTM/2023-08-30, WTM/2023-09-01, WTM/2023-09-05, WTM/2023-09-06)
-- 2023-09-16: 3 records (WTM/2023-09-05, WTM/2023-09-06, WTM/2023-09-11)
-- 2023-09-23: 2 records (WTM/2023-09-11, WTM/2023-09-20)
-- 2023-09-30: 1 records (WTM/2023-09-20)
-- 2023-10-14: 4 records (BBEM/2023-10-03, CLRG/2023-10-11, DARP/2023-10-05, IQSM/2023-10-11)
-- 2023-11-04: 1 record (WTM/2023-10-26)
-- 2023-11-11: 0 record
-- 2023-11-18: 1 record (CLRG/2023-11-17)
-- 2023-12-09: 3 record (CLRG/2023-11-28, SOF/2023-12-01, WTM/2023-12-05)
-- 2023-12-30: 2 recs (WTM/2023-12-19, WTM/2023-12-27)

-- ALL dates: Check symbol/date from DayPolygon and ZipLogMinutePolygon (~5 secs)
select a.*
from dbQ2023..DayPolygon a
left join dbQ2023..ZipLogMinutePolygon b
on a.Symbol=b.Symbol and a.Date=b.Date
where a.Volume*a.[Close]>= 5000000 and b.Date is null and a.Date>'2018-03-28'
order by a.date desc

/*select a.Date, count(*)
from dbQ2023..DayPolygon a
left join dbQ2023..ZipLogMinutePolygon b
on a.Symbol=b.Symbol and a.Date=b.Date
where a.Volume*a.[Close]>= 5000000 and b.Date is null and a.Date>'2018-03-28'
group by a.date order by 1*/

-- 2023-04-16: 92 records
-- 2023-05-06: 93 records
-- 2023-05-20: 94 records
-- 2023-06-17: 96 records
-- 2023-06-24: 95 records
-- 2023-07-01: 98 records
-- 2023-07-08: 97 records
-- 2023-07-15: 99 records
-- 2023-08-05: 101 records
-- 2023-08-12: 103 records
-- 2023-09-02: 105 records
-- 2023-09-09: 107 records
-- 2023-09-09: 108 records
-- 2023-09-26: 109 records
-- 2023-10-07: 111 records
-- 2023-10-14: 113 records
-- 2023-10-28: 114 records
-- 2023-11-18: 115 records
-- 2023-12-02: 117 records
-- 2023-12-09: 118 records
-- 2023-12-23: 121 records
-- 2023-12-30: 122 records
-- 2024-01-13: 159 records (+37 for 2023-05-26, 2023-06-09)
-- 2024-01-27: 161 records

-- Difference (minute & daily) ~6 secs
select a.*
from dbQ2023..ZipLogMinutePolygon a
left join dbQ2023..DayPolygon b on a.Symbol=b.Symbol and a.Date=b.Date
where b.Symbol is null and a.Count<>0
order by date desc
-- 2023-05-27: 2437 recs
-- 2023-06-01: 2 recs
-- 2023-06-10: 10 recs
-- 2023-06-17: 14 recs
-- 2024-01-13: 4 recs

-- non-trading days (8 secs)
select *
from dbQ2023..ZipLogMinutePolygon a
left join dbQ2023..SymbolsPolygon b on a.Symbol=b.Symbol and a.Date between b.Date and isnull(b.[To], '2099-12-31')
where b.Symbol is null
-- 2023-06-24: 0 recs
-- 2024-01-06: 15 recs
-- 2024-01-13: 0 recs

