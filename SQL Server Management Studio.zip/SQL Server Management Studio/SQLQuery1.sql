-- 32'018'011
-- select count(*) from DayPolygon where IsTest is null and year(date)>=2010

-- 26'889'737	2,37892503977306	1,00006284776285
select count(*), AVG((High-Low)/(High+Low)*200), AVG([Close]/[Open])
from DayPolygon where IsTest is null and year(date)>=2010 and high>=5.0

-- 2'852'178	8,24235562226417	1,0002362956223
select count(*), AVG((High-Low)/(High+Low)*200), AVG([Close]/[Open])
from DayPolygon where IsTest is null and year(date)>=2010 and high>=5.0 and (High-Low)/(High+Low)*200>=5.0

-- 157'349	23,1924905943894	1,01632723877027	1,02024847892875
select count(*), AVG((High-Low)/(High+Low)*200), AVG([Close]/[Open]), AVG([Open]/[Close])
from DayPolygon where IsTest is null and year(date)>=2010 and high>=5.0 and (High-Low)/(High+Low)*200>=15.0

-- 2'330'520	8,26233851108914	1,00014259058021	1,00365650960308
select count(*), AVG((High-Low)/(High+Low)*200), AVG([Close]/[Open]), AVG([Open]/[Close])
from DayPolygon where IsTest is null and year(date)>=2010 and high>=5.0 and (High-Low)/(High+Low)*200>=5.0
and Volume*[High]>=500000 and TradeCount>=100

select year(date) Year, count(*) Recs, AVG((High-Low)/(High+Low)*200), AVG([Close]/[Open]), AVG([Open]/[Close])
from DayPolygon where IsTest is null and year(date)>=2010 and high>=5.0 and (High-Low)/(High+Low)*200>=5.0
and Volume*High>=500000 and TradeCount>=100
group by year(date) order by 1


