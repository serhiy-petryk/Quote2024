use dbQ2024;

-- select top 100 * from TradingDays order by date desc

-- Check dead Sector corrections: not need
/*select b.Symbol, b.Date, b.Sector, a.Sector, b.Name, a.Name from Bfr_SectorYahoo a
inner join 
(select * from SectorCorrections where date>'2024-01-01') b on a.PolygonSymbol=b.Symbol
order by b.Date desc*/

-- 102 secs: 2 sql procedures
exec pUpdateSymbolsXrefAndSectors;
exec dbQ2024..pUpdateSymbolsXref;

-- MsSector not defined
select *
from SymbolsPolygon a
where (a.[To] is null or a.[To]>'2020-01-01') and
a.IsTest is null and a.MyType not like 'E%' and isnull(a.MyType,'') != 'INDEX'
and a.MsSector is null
order by [To], Date desc
-- 2024-06-29: 833 rows
-- 2024-08-03: 840 rows
-- 2024-08-10: 834 rows
-- 2024-08-10: 834 rows
-- 2024-09-21: 833 rows
-- 2024-09-28: 834 rows
-- 2024-10-05: 833 rows
-- 2024-10-12: 840 rows
-- 2024-10-19: 833 rows
-- 2024-11-02: 831 rows
-- 2024-11-09: 832 rows
-- 2024-11-16: 834 rows ???
-- 2024-11-23: 832 rows
-- 2025-01-18: 826 rows (added a.MyType != 'INDEX')
-- 2025-02-01: 825 rows
-- 2025-02-08: 826 rows
-- 2025-02-15: 825 rows

-- Check interception of symbol/date
select * from SymbolsPolygon a
inner join SymbolsPolygon b on a.Symbol=b.Symbol and b.Date>a.Date and b.Date<=isnull(a.[To], '2099-12-31')
-- 2024-01-16: 0 recs

select * from SymbolsPolygon a
inner join SymbolsPolygon b on a.Symbol=b.Symbol and isnull(b.[To],'2099-12-31') between a.Date and isnull(a.[To], '2099-12-31') and a.Date<>b.Date
-- 2024-01-16: 0 recs

select * from SymbolsPolygon a
where IsTest is null and exchange in ('No', 'Day') and date>'2019-01-01'
order by date desc
-- 2024-02-04: 0 rows
-- 2024-09-28: 14 rows (no symbol data for 2024-09-26 for some symbols)
-- 2024-11-16: 3 rows ('HSPTU','STSB','TSSI')
-- 2024-12-07: 0 rows
-- 2024-12-21: 16 rows (no symbol data for 2024-12-20 for some symbols) 
-- 2024-12-28: 33 rows (no symbol data for 2024-12-26/27 for some symbols) 
-- 2025-01-18: 2 rows (at 2025-01-17)
-- 2025-01-25: 0 rows 

/*-- Check missings in dbQ2023Others..ScreenerNasdaqGithub
select * 
from dbQ2024..TradingDays a
left join (select Date, count(*) Recs from dbQ2023Others..ScreenerNasdaqGithub a group by Date) b on a.Date=b.Date
where a.Date> (SELECT min(Date) from dbQ2023Others..ScreenerNasdaqGithub) and b.Date is null
order by a.Date desc
-- 2024-02-23: 2 rows (2022-12-28, 2022-12-21)*/

/*-- Check xref symbols in ScreenerChartmill
select a.*
from dbQ2023Others..ScreenerChartmill a
left join dbQ2024..SymbolsPolygon b on a.Symbol=b.EoddataSymbol
where b.EoddataSymbol is null and a.Sector is not null
-- !!! must be 0*/

-- =======
-- Sectors
-- =======
select MsSector from SymbolsPolygon where MsSector is not null group by MsSector order by 1
-- !!!must be 11 sectors

-- Check sector for big trades: 19 secs
select b.*, a.*
from SymbolsPolygon a
inner join 
(select Symbol, sum(Volume*[Close])/1000000 TradeValue, count(*) TradingDays, min(date) MinDate, max(date) MaxDate
from DayPolygon where IsTest is null and Date>'2020-01-01' and volume*[Close]>=50000000
group by symbol) b on a.Symbol=b.Symbol and
(a.Date between b.MinDate and b.MaxDate or b.MinDate between a.Date and isnull(a.[To], '2099-12-31'))
where (a.[To] is null or a.[To]>'2020-01-01')
and a.IsTest is null and a.MyType not like 'E%'
and a.MsSector is null
order by TradingDays desc, b.MaxDate desc, a.symbol
-- 2024-07-29: 136 rows, 1 trading day
-- 2024-08-10: 136 rows (NULL - 3 rows)
-- 2024-10-12: 137 rows (NULL - 4 rows)
-- 2024-10-19: 136 rows (NULL - 3 rows)

/*select symbol, min(MyType) Type, min(QDate) MinQuoteDate, max(QDate) MaxQuoteDate, min(Name) Name
from
	(select b.*, a.Date QDate from dbQ2024..DayPolygon a
		inner join dbQ2024..SymbolsPolygon b on a.Symbol=b.Symbol and a.Date between b.[Date] and isnull(b.[To], '2099-12-31')
		where a.Date>'2022-01-01' and a.Volume*a.[Close]>=50000000 and a.TradeCount>=5000
		and b.MyType not like 'ET[A-Z]'
		and b.MsSector is null
	) x
group by symbol order by 1
-- 2024-02-28: 4 rows ('DNAA','DNAC','GPCO','VTAQ')
-- 2024-03-23: 6 rows ('AUNA','DNAA','DNAC','GPCO','MRNO','VTAQ')
-- 2024-03-30: 4 rows ('DNAA','DNAC','GPCO','VTAQ')
-- 2024-04-13: 5 rows ('DNAA','DNAC','GPCO','ULS', 'VTAQ')
-- 2024-04-20: 4 rows ('DNAA','DNAC','GPCO','VTAQ')
-- 2024-05-25: 5 rows ('BOW', 'DNAA','DNAC','GPCO','VTAQ')
-- 2024-06-01: 5 rows ('DNAA','DNAC','GPCO','OXLC','VTAQ')
-- 2024-06-08: 6 rows ('DNAA','DNAC','GPCO','OXLC','VTAQ','WAY')
-- 2024-06-15: 9 rows ('DNAA','DNAC','DSY','GPCO','OXLC','SILA','TEM','VTAQ','WAY')
-- 2024-06-29: 15 rows no Chrtmill/MorningStar updates ('AIEV','DNAA','DNAC','DSY','GPCO','GRAF.U','GRAL','LB','OXLC','SILA','TEM','VTAQ','WAY','WBTN','WENA')
-- 2024-07-06: 16 rows no Chrtmill/MorningStar updates ('AIEV','DNAA','DNAC','DSY','FUN','GPCO','GRAF.U','GRAL','LB','OXLC','SILA','TEM','VTAQ','WAY','WBTN','WENA')
-- 2024-07-13: 20 rows no Chrtmill/MorningStar updates*/

-- select * from dbQ2024..vCheckSymbolSectors
-- 2024-02-28: 739 rows
-- 2024-03-16: 746 rows
-- 2024-03-23: 756 rows
-- 2024-05-04: 768 rows
-- 2024-05-18: 776 rows

-- ========================
-- MorningStar symbols Xref
-- ========================
/*select * from
dbQ2023Others..ScreenerMorningStar a
left join dbQ2024..SymbolsPolygon b on a.Symbol=b.Symbol and a.Exchange=b.Exchange
	and (a.Date between DATEADD(Day,-97,b.Date) and DATEADD(Day,97,isnull(b.[To], '2099-12-31'))
	or b.Date between DATEADD(Day,-97,a.Date) and DATEADD(Day,97,a.LastUpdated))
where b.Symbol is null*/

/*select 'Exists in Polygon' Label,  a.symbol, a.exchange, a.date, a.[To], a.name, a.Updated, a.[TimeStamp], NULL MyType, NULL PolygonName
from (select * from dbQ2024..SymbolsPolygon where [To] is null) a
left join dbQ2023Others..ScreenerMorningStar b on a.Symbol=b.Symbol and a.Exchange=b.Exchange
where a.IsTest is null and a.MyType in ('ADRC','CS','PFD', 'UNIT') AND (a.[To] is null or a.[To]>'2024-01-01')
and b.Symbol is null
UNION
select 'Exists in MorningStar' Label, a.symbol, a.exchange, a.date, a.[To], a.name, a.LastUpdated, a.[TimeStamp], c.MyType, c.Name PolygonName
from dbQ2023Others..ScreenerMorningStar a
left join (select * from dbQ2024..SymbolsPolygon where IsTest is null and MyType in ('ADRC','CS','PFD', 'UNIT','SP') AND isnull([To],'2099-12-31')>'2024-01-01') b on a.Symbol=b.Symbol and a.Exchange=b.Exchange
left join (select * from dbQ2024..SymbolsPolygon where MyType not in ('ADRC','CS','PFD', 'UNIT') AND ([To] is null or [To]>'2024-01-01')) c on a.Symbol=c.Symbol and a.Exchange=c.Exchange
where b.Symbol is null
order by 2,4 desc
-- order by 4 desc,2 
-- 2024-02-25: 89 rows
-- 2024-03-09: 70 rows (after add 'SP' to MyType list)
-- 2024-04-13: 76 rows
-- 2024-05-18: 81 rows
-- 2024-06-08: 115 rows
-- 2024-06-15: 123 rows - no MorningStar update
-- 2024-06-22: 129 rows - no MorningStar update
-- 2024-06-29: 136 rows - no MorningStar update
-- 2024-07-06: 120 rows - no MorningStar update
-- 2024-07-13: 156 rows - no MorningStar update
*/
-- ====================
-- Eoddata symbols Xref
-- ====================
-- Not defined Eoddata symbols in SymbolsPolygon
select * from SymbolsPolygon WHERE ([To] is null or [To]>'2022-01-01') and IsTest is null
and EoddataSymbol is null
-- 2024-01-16: 2 recs (TWNT.U,TWNT.WS)
-- 2024-05-25: 3 recs (NYCB.PRU,TWNT.U,TWNT.WS)
-- 2024-07-06: 2 recs (TWNT.U,TWNT.WS)

-- Different symbols Xref
select b.PolygonSymbol PolygonSymbolInEoddata, b.Symbol EoddataSymbol, *
from SymbolsPolygon a
inner join dbQ2024..SymbolsEoddata b on a.EoddataSymbol=b.Symbol
where (a.[To] is null or a.[To]>'2022-01-01') and a.Symbol <> isnull(b.PolygonSymbol,'') 
and a.Symbol not like '%.RTW'
-- 2024-01-16: 2 recs (FLYX.WS,FLYA.WS)
-- 2024-09-28: 3 recs (FLYX.WS,FLYA.WS) + SEG.WI (need to check later)
-- 2024-10-12: 4 recs (FLYX.WS,FLYA.WS) + SEG.WI, SBXD.WS (need to check later)
-- 2024-09-28: 3 recs (FLYX.WS,FLYA.WS) + SEG.WI

select Symbol, min(PolygonSymbol) MinPolygonSymbol, max(PolygonSymbol) MaxPolygonSymbol
from dbQ2024..SymbolsEoddata
group by Symbol
having min(PolygonSymbol)<>max(PolygonSymbol)
-- 2024-01-16: 1 rec (FLY.W)

-- Symbols exist in SymbolsEoddata and missing in SymbolsPolygon
select a.*
from dbQ2024..SymbolsEoddata a
left join (select * from SymbolsPolygon WHERE ([To] is null or [To]>'2022-01-01') and IsTest is null) b
on a.Symbol=b.EoddataSymbol
where b.Symbol is null and a.IsTest is null
-- 2024-01-16: 0 recs
-- 2024-06-08: 1 row (VHA.X)

-- Symbols exist in SymbolsPolygon and missing in SymbolsEoddata: 7 secs
select c.LastTrade, c.AverTurnover, a.EoddataSymbol, *
from SymbolsPolygon a
left join dbQ2024..SymbolsEoddata b on a.EoddataSymbol=b.Symbol
inner join (SELECT y.symbol, y.date, max(x.Date) LastTrade, round(sum(x.volume*x.[Close])/count(*)/1000000.0,3) AverTurnover from DayPolygon x
		inner join SymbolsPolygon y on x.Symbol=y.Symbol and x.Date between y.Date and isnull(y.[To],'2099-12-31')
		where x.date>'2022-01-01'
		group by y.Symbol, y.Date) c on c.Symbol=a.Symbol and c.Date=a.Date
where (a.[To] is null or a.[To]>'2022-01-01') and b.Symbol is null and a.IsTest is null
order by isnull(a.[To], '2099-12-31') desc, a.Date desc
-- 2024-01-16: 624 recs (7 records have [To]=null, 3 items are new)
-- 2024-01-20: 622 recs (6 records have [To]=null, 2 items are new)
-- 2024-02-03: 619 recs (5 records have [To]=null, 1 item is new)
-- 2024-02-24: 624 recs (5 records have [To]=null, VHAI.WS.A is new)
-- 2024-03-02: 631 recs (9 records have [To]=null, VHAI.WS.A is new)
-- 2024-03-09: 626 recs (6 records have [To]=null, VHAI.WS.A is new)
-- 2024-03-16: 632 recs (12 records have [To]=null, 7 items are new)
-- 2024-03-23: 663 recs (8 records have [To]=null, 33 items are new (many ETFs)
-- 2024-04-06: 626 recs (11 records have [To]=null)
-- 2024-05-18: 649 recs (32 records have [To]=null)
-- 2024-05-25: 616 recs (9 records have [To]=null) (sql changed -> c.LastTrade is not null == inner join instead of left join)
-- 2024-06-15: 611 recs (4 records have [To]=null)
-- 2024-06-29: 612 recs (5 records have [To]=null)
-- 2024-07-06: 619 recs (12 records have [To]=null)
-- 2024-07-13: 611 recs (5 records have [To]=null)
-- 2024-07-29: 609 recs (3 records have [To]=null)
-- 2024-08-03: 612 recs (5 records have [To]=null)
-- 2024-08-17: 611 recs (4 records have [To]=null)
-- 2024-08-24: 609 recs (1 record have [To]=null)
-- 2024-08-31: 610 recs (2 records have [To]=null)
-- 2024-08-31: 609 recs (3 records have [To]=null)
-- 2024-09-14: 606 recs (no records have [To]=null)
-- 2024-09-21: 609 recs (3 records have [To]=null)
-- 2024-09-28: 613 recs (2 records have [To]=null)
-- 2024-10-04: 632 recs (25 records have [To]=null)
-- 2024-10-12: 658 recs (52 records have [To]=null)
-- 2024-10-19: 613 recs (7 records have [To]=null)
-- 2024-10-26: 610 recs (4 records have [To]=null)
-- 2024-11-02: 618 recs (12 records have [To]=null)
-- 2024-11-09: 614 recs (5 records have [To]=null)
-- 2024-11-16: 607 recs (1 record has [To]=null)
-- 2024-11-16: 611 recs (6 records have [To]=null)
-- 2024-11-30: 622 recs (15 records have [To]=null)
-- 2024-12-07: 674 recs (67 records have [To]=null)
-- 2024-12-14: 719 recs (113 records have [To]=null)
-- 2024-12-21: 778 recs (156 records have [To]=null)
-- 2024-12-28: 792 recs (156 records have [To]=null)
-- 2025-01-04: 858 recs (220 records have [To]=null)
-- 2025-01-11: 612 recs (4 records have [To]=null)
-- 2025-01-18: 609 recs (1 record has [To]=null)
-- 2025-01-25: 610 recs (4 records have [To]=null)
-- 2025-02-01: 617 recs (9 records have [To]=null)
-- 2025-02-08: 614 recs (7 records have [To]=null)
-- 2025-02-15: 613 recs (6 records have [To]=null)

-- ====================
-- Yahoo symbols Xref
-- ====================
-- Not defined Yahoo symbols in SymbolsPolygon
select * from SymbolsPolygon
WHERE ([To] is null or [To]>'2003-01-01') and IsTest is null
and YahooSymbol is null and symbol not like '%.WD' and symbol not like '%.CL'
order by isnull([To],'2099-12-31') desc
-- 2024-01-16: 1 row (HAF.EC)
-- 2024-05-25: 2 rows (NYCB.PRU, HAF.EC)
-- 2024-06-30: 1 row (NYCB.PRU added to test symbols)


/*-- ====================
-- Nasdaq symbols Xref
-- ====================
-- Startdate ScreenerNasdaqStock:	2021-02-06 02:16:00
-- Startdate ScreenerNasdaqEtf:		2023-03-01 03:32:00

-- Not defined Nasdaq symbols in SymbolsPolygon
select * from SymbolsPolygon WHERE ([To] is null or [To]>'2021-02-01') and IsTest is null
and NasdaqSymbol is null order by isnull([To],'2099-12-31') desc
-- 2024-01-16: 32 recs (.RTW, .WD)
-- 2024-02-10: 33 rows

-- Missing stock tickers in ScreenerNasdaqStock
select *
from (SELECT * from SymbolsPolygon  WHERE ([To] is null or [To]>'2021-02-01') and IsTest is null) a
left join dbQ2023Others..ScreenerNasdaqStock b on a.NasdaqSymbol=b.Symbol
where b.Symbol is null and a.Type not in ('ETF','ETN','ETS','ETV')
and a.symbol not like '%.U' and a.symbol not like '%.W%' and a.symbol not like '%.RT%' 
order by a.Date desc
-- 2024-01-16: 31 rows
-- 2024-02-10: 32 rows
-- 2024-02-16: 33 rows
-- 2024-02-24: 36 rows

-- Missing etf tickers in ScreenerNasdaqEtf -> ??? ScreenerNasdaqEtf shows data for not all etf tickers
select *
from (SELECT * from SymbolsPolygon  WHERE ([To] is null or [To]>'2023-03-01') and IsTest is null) a
left join dbQ2023Others..ScreenerNasdaqEtf b on a.NasdaqSymbol=b.Symbol
where b.Symbol is null and a.Type in ('ETF','ETN','ETS','ETV')
order by isnull(a.[To], '2099-12-31') desc, a.Date desc
-- 2024-01-16: 137 rows
-- 2024-01-20: 135 rows
-- 2024-02-03: 166 rows

-- Symbols exist in ScreenerNasdaqEtf and missing in SymbolsPolygon
select a.*
from dbQ2023Others..ScreenerNasdaqEtf a
left join (select * from SymbolsPolygon WHERE ([To] is null or [To]>'2023-02-21') and IsTest is null) b
on a.Symbol=b.NasdaqSymbol
where b.Symbol is null
-- 2024-01-16: 0 recs

-- Symbols exist in ScreenerNasdaqStock and missing in SymbolsPolygon
select a.*
from dbQ2023Others..ScreenerNasdaqStock a
left join (select * from SymbolsPolygon WHERE ([To] is null or [To]>'2021-02-01') and IsTest is null) b
on a.Symbol=b.NasdaqSymbol
where b.Symbol is null
-- 2024-01-16: 5 recs (CANB,GMGT,IMCI,PBIO,QSAM)

-- ====================
-- TradingView symbols Xref
-- ====================
-- Startdate ScreenerNasdaqStock:	2023-01-13 07:04:00

-- Not defined Nasdaq symbols in SymbolsPolygon
select * from SymbolsPolygon WHERE ([To] is null or [To]>'2023-01-01') and IsTest is null
and TradingViewSymbol is null order by isnull([To],'2099-12-31') desc
-- 2024-01-16: 7 recs (.RTW, .WD)
-- 2024-02-10: 8 rows

-- Missing stock tickers in ScreenerTradingView
select *
from (SELECT * from SymbolsPolygon  WHERE ([To] is null or [To]>'2023-01-01') and IsTest is null) a
left join dbQ2023Others..ScreenerTradingView b on a.TradingViewSymbol=b.Symbol
where b.Symbol is null and a.Type not in ('WARRANT','RIGHT') and a.Symbol not like '%.W%'
order by isnull(a.[To], '2099-12-31') desc
-- 2024-01-16: 66 rows (7 rows have [To]=null)
-- 2024-01-20: 67 rows (8 rows have [To]=null)
-- 2024-02-16: 68 rows (9 rows have [To]=null)

-- Symbols exist in ScreenerTradingView and missing in SymbolsPolygon
select a.*
from dbQ2023Others..ScreenerTradingView a
left join (select * from SymbolsPolygon WHERE ([To] is null or [To]>'2023-01-01') and IsTest is null) b
on a.Symbol=b.TradingViewSymbol
where b.Symbol is null
-- 2024-01-16: 1 row (MURAV)*/
