-- 85709/ 75060/7858
-- drop table dbQuote2022..XX_Recommend;

select a.RecId, a.TradeDate, b.Next1, b.Next2, b.Next3, b.Next4, b.Next5, c.* into dbQuote2022..XX_Recommend  from 
(select
iif (Recommend<-0.8, -5, iif (Recommend<-0.6, -4, iif (Recommend<-0.4, -3, iif (Recommend<-0.2, -2,
iif (Recommend<0, -1, iif (Recommend<0.2, 1,iif (Recommend<0.4, 2, iif (Recommend<0.6, 3, iif (Recommend<0.8, 4,5 ))) )) )))) RecId,
* from dbQuote2023..ScreenerTvRecommend where [TimeStamp] not in ('2023-01-12','2023-01-13','2023-01-19')) a
inner join dbQuote2022..TradingDays b on a.TradeDate=b.Date
inner join dbQuote2022..vSymbolsLive c on a.Symbol=c.TradingViewSymbol
where b.Next1 is not null


select a.RecId, a.TradeDate, count(*) recs, AVG((b.[Close]-b.[PrevClose])/b.[Close] *100.0) onCalcDay,
AVG((c.[Close]-b.[PrevClose])/c.[Close] *100.0) onPrevClose,
AVG((c.[Close]-b.[Close])/c.[Close] *100.0) onClose,
AVG((c.[Close]-c.[Open])/c.[Close] *100.0) onOpen
from dbQuote2022..XX_Recommend a
inner join dbQuote2022..vSymbolAndDateLive b on a.Symbol=b.Symbol and a.Exchange=b.Exchange and a.TradeDate=b.Date
inner join dbQuote2022..DayEoddata c on a.Symbol=c.Symbol and a.Exchange=c.Exchange and a.Next1=c.Date
group by a.RecId, a.TradeDate order by 1, 2

select a.RecId, count(*) recs, AVG((c.[Close]-b.[Close])/c.[Close] *100.0) rezPrevDay, AVG((c.[Close]-c.[Open])/c.[Close] *100.0) rezOnOpen
from dbQuote2022..XX_Recommend a
inner join dbQuote2022..vSymbolAndDateLive b on a.Symbol=b.Symbol and a.Exchange=b.Exchange and a.TradeDate=b.Date
inner join dbQuote2022..DayEoddata c on a.Symbol=c.Symbol and a.Exchange=c.Exchange and a.Next1=c.Date
group by a.RecId order by 1

select a.RecId, count(*) recs, AVG((c.[Close]-b.PrevClose)/c.[Close] *100.0) rezPrevDay, AVG((c.[Close]-c.[Open])/c.[Close] *100.0) rezOnOpen
from dbQuote2022..XX_Recommend a
inner join dbQuote2022..vSymbolAndDateLive b on a.Symbol=b.Symbol and a.Exchange=b.Exchange and a.TradeDate=b.Date
inner join dbQuote2022..DayEoddata c on a.Symbol=c.Symbol and a.Exchange=c.Exchange and a.Next2=c.Date
group by a.RecId order by 1

select a.RecId, count(*) recs, AVG((c.[Close]-b.PrevClose)/c.[Close] *100.0) rezPrevDay, AVG((c.[Close]-c.[Open])/c.[Close] *100.0) rezOnOpen
from dbQuote2022..XX_Recommend a
inner join dbQuote2022..vSymbolAndDateLive b on a.Symbol=b.Symbol and a.Exchange=b.Exchange and a.TradeDate=b.Date
inner join dbQuote2022..DayEoddata c on a.Symbol=c.Symbol and a.Exchange=c.Exchange and a.Next3=c.Date
group by a.RecId order by 1

select a.RecId, count(*) recs, AVG((c.[Close]-b.PrevClose)/c.[Close] *100.0) rezPrevDay, AVG((c.[Close]-c.[Open])/c.[Close] *100.0) rezOnOpen
from dbQuote2022..XX_Recommend a
inner join dbQuote2022..vSymbolAndDateLive b on a.Symbol=b.Symbol and a.Exchange=b.Exchange and a.TradeDate=b.Date
inner join dbQuote2022..DayEoddata c on a.Symbol=c.Symbol and a.Exchange=c.Exchange and a.Next5=c.Date
group by a.RecId order by 1


-- where c.Symbol is null

/*select * from dbQuote2023..ScreenerTvRecommend

update ScreenerTvRecommend SET TradeDate=[TimeStamp];
update ScreenerTvRecommend SET TradeDate=DATEADD(day, -1, [TimeStamp]) where [TimeStamp] in ('2023-01-14','2023-01-21','2023-01-28')*/
