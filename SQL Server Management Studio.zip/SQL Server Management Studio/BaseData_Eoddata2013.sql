-- =======  Big volume  =======
-- Check
-- select * from DayEoddata2013 where High<[Open] or High<[Close] or Low>[Open] or Low>[Close]
-- select * from DayEoddata2013 where abs(High)<abs([Open]) or abs(High)<abs([Close]) or abs(Low)>abs([Open]) or abs(Low)>abs([Close])
-- select * from DayEoddata2013 where [Open]<0 or High<0 or Low<0 or [Close]<0 or Volume<0
-- select symbol, date from DayEoddata2013 group by symbol, date having count(*)<>1;

-- select * from DayEoddata where High<[Open] or High<[Close] or Low>[Open] or Low>[Close]
-- select * from DayEoddata where abs(High)<abs([Open]) or abs(High)<abs([Close]) or abs(Low)>abs([Open]) or abs(Low)>abs([Close])
-- select * from DayEoddata where [Open]<0 or High<0 or Low<0 or [Close]<0 or Volume<0
-- select symbol, date from DayEoddata group by symbol, date having count(*)<>1;

use dbQuote2022;

drop table Temp_BaseDataEoddata2013;

select a.*,
d.DJI/d.DJI_Avg DJI_ToAvg, d.DJI/d.DJI_WAvg DJI_ToWAvg, d.GSPC/d.GSPC_Avg GSPC_ToAvg, d.GSPC/d.GSPC_WAvg GSPC_ToWAvg,
(p1.[Close]+p2.[Close]+p3.[Close]+p4.[Close]+p5.[Close]+p6.[Close]+p7.[Close])/7.0 as AvgCL,
(p1.[Close]*7.0+p2.[Close]*6.0+p3.[Close]*5.0+p4.[Close]*4.0+p5.[Close]*3.0+p6.[Close]*2.0+p7.[Close])/28.0 as WAvgCL,
(p1.[Volume]+p2.[Volume]+p3.[Volume]+p4.[Volume]+p5.[Volume]+p6.[Volume]+p7.[Volume])/7.0 as AvgVLM,
(p1.[Volume]*7.0+p2.[Volume]*6.0+p3.[Volume]*5.0+p4.[Volume]*4.0+p5.[Volume]*3.0+p6.[Volume]*2.0+p7.[Volume])/28.0 as WAvgVLM,
((p1.High-p1.Low)/p1.[Close]+(p2.High-p2.Low)/p2.[Close]+(p3.High-p3.Low)/p3.[Close]+(p4.High-p4.Low)/p4.[Close]+
(p5.High-p5.Low)/p5.[Close]+(p6.High-p6.Low)/p6.[Close]+(p7.High-p7.Low)/p7.[Close])/7.0*100.0 as AvgVolatility,
((p1.High-p1.Low)/p1.[Close]*7.0+(p2.High-p2.Low)/p2.[Close]*6.0+(p3.High-p3.Low)/p3.[Close]*5.0+(p4.High-p4.Low)/p4.[Close]*4.0+
(p5.High-p5.Low)/p5.[Close]*3.0+(p6.High-p6.Low)/p6.[Close]*2.0+(p7.High-p7.Low)/p7.[Close])/28.0*100.0 as WAvgVolatility,
(SELECT Max(v) FROM (VALUES (p1.Volume),(p2.Volume),(p3.Volume),(p4.Volume),(p5.Volume),(p6.Volume),(p7.Volume)) AS value(v)) as [MaxPVLM],
(SELECT Min(v) FROM (VALUES (p1.Volume),(p2.Volume),(p3.Volume),(p4.Volume),(p5.Volume),(p6.Volume),(p7.Volume)) AS value(v)) as [MinPVLM],
(SELECT Max(v) FROM (VALUES (p1.High),(p2.High),(p3.High),(p4.High),(p5.High),(p6.High),(p7.High)) AS value(v)) as [MaxPHigh],
(SELECT Min(v) FROM (VALUES (p1.Low),(p2.Low),(p3.Low),(p4.Low),(p5.Low),(p6.Low),(p7.Low)) AS value(v)) as [MinPLow],
p1.[Open] Open_P1, p1.High High_P1, p1.Low Low_P1, p1.[Close] CL_P1, p1.Volume VLM_P1, 
n1.[Open] Open_N1, n1.High High_N1, n1.Low Low_N1, n1.[Close] CL_N1, n1.Volume VLM_N1,
n2.[Open] Open_N2, n2.High High_N2, n2.Low Low_N2, n2.[Close] CL_N2, n2.Volume VLM_N2,
n3.[Open] Open_N3, n3.High High_N3, n3.Low Low_N3, n3.[Close] CL_N3, n3.Volume VLM_N3,
n4.[Open] Open_N4, n4.High High_N4, n4.Low Low_N4, n4.[Close] CL_N4, n4.Volume VLM_N4,
n5.[Open] Open_N5, n5.High High_N5, n5.Low Low_N5, n5.[Close] CL_N5, n5.Volume VLM_N5,
sn1.Split as Split_N1, sn2.Split as Split_N2, sn3.Split as Split_N3, sn4.Split as Split_N4, sn5.Split as Split_N5
into Temp_BaseDataEoddata2013
from DayEoddata2013 a

inner join TradingDays d on d.Date=a.Date
inner join DayEoddata2013 p1 on p1.Symbol=a.Symbol and p1.Date=d.Prev1
inner join DayEoddata2013 p2 on p2.Symbol=a.Symbol and p2.Date=d.Prev2
inner join DayEoddata2013 p3 on p3.Symbol=a.Symbol and p3.Date=d.Prev3
inner join DayEoddata2013 p4 on p4.Symbol=a.Symbol and p4.Date=d.Prev4
inner join DayEoddata2013 p5 on p5.Symbol=a.Symbol and p5.Date=d.Prev5
inner join DayEoddata2013 p6 on p6.Symbol=a.Symbol and p6.Date=d.Prev6
inner join DayEoddata2013 p7 on p7.Symbol=a.Symbol and p7.Date=d.Prev7

left join Splits s on s.Symbol=a.Symbol and s.Date=a.Date
left join Splits s1 on s1.Symbol=a.Symbol and s1.Date=d.Prev1
left join Splits s2 on s2.Symbol=a.Symbol and s2.Date=d.Prev2
left join Splits s3 on s3.Symbol=a.Symbol and s3.Date=d.Prev3
left join Splits s4 on s4.Symbol=a.Symbol and s4.Date=d.Prev4
left join Splits s5 on s5.Symbol=a.Symbol and s5.Date=d.Prev5
left join Splits s6 on s6.Symbol=a.Symbol and s6.Date=d.Prev6
left join Splits s7 on s7.Symbol=a.Symbol and s7.Date=d.Prev7
left join Splits sn1 on sn1.Symbol=a.Symbol and sn1.Date=d.Next1
left join Splits sn2 on sn2.Symbol=a.Symbol and sn2.Date=d.Next2
left join Splits sn3 on sn3.Symbol=a.Symbol and sn3.Date=d.Next3
left join Splits sn4 on sn4.Symbol=a.Symbol and sn4.Date=d.Next4
left join Splits sn5 on sn5.Symbol=a.Symbol and sn5.Date=d.Next5

inner join DayEoddata2013 n1 on n1.Symbol=a.Symbol and n1.Date=d.Next1
left join DayEoddata2013 n2 on n2.Symbol=a.Symbol and n2.Date=d.Next2
left join DayEoddata2013 n3 on n3.Symbol=a.Symbol and n3.Date=d.Next3
left join DayEoddata2013 n4 on n4.Symbol=a.Symbol and n4.Date=d.Next4
left join DayEoddata2013 n5 on n5.Symbol=a.Symbol and n5.Date=d.Next5
WHERE a.Volume>0 and p1.Volume>0 and p2.Volume>0 and p3.Volume>0 and p4.Volume>0 and p5.Volume>0 and p6.Volume>0 and p7.Volume>0
and s.Symbol is null and s1.Symbol is null and s2.Symbol is null and s3.Symbol is null and s4.Symbol is null and s5.Symbol is null and s6.Symbol is null and s7.Symbol is null
and a.Symbol<>'SEB';

select count(*) Cnt, AVG([Open]/ [Close]) as OpenToClose, ROUND(STDEV([Open]/ [Close])*100,1) as D,
CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N1,
CAST(ROUND(SUM(iif([Open_N1]<[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Buy_N1,
min(Date) MinDate, max(date) MaxDate
from Temp_BaseDataEoddata2013 where [Close] >=5 and Volume > 300000; -- 1372634, 1.0002, 2.2, 48.5

select Exchange, count(*) Cnt, AVG([Open]/ [Close]) as OpenToClose, ROUND(STDEV([Open]/ [Close])*100,1) as D,
CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N1,
CAST(ROUND(SUM(iif([Open_N1]<[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Buy_N1,
cast(round(100.0*sum(iif([High]<[Open]+0.005,1,0))/count(*),2) as real) H0,
cast(round(100.0*sum(iif([Low]>[Open]-0.005,1,0))/count(*),2) as real) L0
from Temp_BaseDataEoddata2013 where [Close] >=5 and Volume > 300000
group by Exchange order by 1; 
/*Exchange	Cnt	OpenToClose	D	Sell_N1	Buy_N1	H0	L0
AMEX	155364	1,00075011423995	2	48,1	49,6	6,1	4,77
NASDAQ	389175	0,999975683950862	2,8	49,1	49,2	5,35	5,18
NYSE	828095	1,00020094854005	2	48,3	50,2	5	4,53*/

-- =============================================
-- =============================================
-- =============================================
/* drop view vDayYahoo2013BigVolume3000;
create view vDayYahoo2013BigVolume3000 as 
select 1 Cnt, Open_N1/CL_N1 R1, Open_N1/CL_N2 R2, Open_N1/CL_N3 R3, Open_N1/CL_N4 R4, Open_N1/CL_N5 R5, 
Volume/AverVOL VolToAver, MaxPVol/AverVOL MaxPVolToAver, [Close]/AverCl CloseToAver, [Open]/ [Close] OpenToClose, a.*
from Temp_Query003 a where [Close] >=1 and Volume > 300000 and Volume > 2* AverVOL and AverVOL > 300000;*/

select count(*) Cnt, AVG([Open]/ [Close]) as OpenToClose, ROUND(STDEV([Open]/ [Close])*100,1) as D,
CAST(ROUND(SUM(iif([Open]>[Close],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5, CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N5
from vDayYahoo2013BigVolume3000; -- 105362, 0.9997, 5.4

-- Ranges
-- Level 1
SELECT G0, min(VolToAver) MinValue, max(VolToAver) MaxValue, count(*) Cnt,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5, CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY VolToAver ASC) /(SELECT (count(*)+6)/8 FROM vDayYahoo2013BigVolume3000) as int) AS G0,
* from vDayYahoo2013BigVolume3000) x GROUP BY G0 ORDER BY 1

SELECT G1, min(MaxPVolToAver) MinValue, max(MaxPVolToAver) MaxValue, count(*) Cnt,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5, CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY MaxPVolToAver ASC) /(SELECT (count(*)+6)/8 FROM vDayYahoo2013BigVolume3000) as int) AS G1,
* from vDayYahoo2013BigVolume3000) x GROUP BY G1 ORDER BY 1

SELECT G2, min(CloseToAver) MinValue, max(CloseToAver) MaxValue, count(*) Cnt,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5, CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY CloseToAver ASC) /(SELECT (count(*)+6)/8 FROM vDayYahoo2013BigVolume3000) as int) AS G2,
* from vDayYahoo2013BigVolume3000) x GROUP BY G2 ORDER BY 1

SELECT G3, min(OpenToClose) MinValue, max(OpenToClose) MaxValue, count(*) Cnt,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5, CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY OpenToClose ASC) /(SELECT (count(*)+6)/8 FROM vDayYahoo2013BigVolume3000) as int) AS G3,
* from vDayYahoo2013BigVolume3000) x GROUP BY G3 ORDER BY 1

SELECT G4, min([Close]) MinValue, max([Close]) MaxValue, count(*) Cnt,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5, CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY [Close] ASC) /(SELECT (count(*)+6)/8 FROM vDayYahoo2013BigVolume3000) as int) AS G4,
* from vDayYahoo2013BigVolume3000) x GROUP BY G4 ORDER BY 1

SELECT G5, min(AverVOL) MinValue, max(AverVOL) MaxValue, count(*) Cnt,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5, CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY AverVOL ASC) /(SELECT (count(*)+6)/8 FROM vDayYahoo2013BigVolume3000) as int) AS G5,
* from vDayYahoo2013BigVolume3000) x GROUP BY G5 ORDER BY 1

SELECT G6, min(DJI_ToAver) MinValue, max(DJI_ToAver) MaxValue, count(*) Cnt,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5, CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY DJI_ToAver ASC) /(SELECT (count(*)+6)/8 FROM vDayYahoo2013BigVolume3000) as int) AS G6,
* from vDayYahoo2013BigVolume3000) x GROUP BY G6 ORDER BY 1

SELECT G7, min(GSPC_ToAver) MinValue, max(GSPC_ToAver) MaxValue, count(*) Cnt,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5, CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY GSPC_ToAver ASC) /(SELECT (count(*)+6)/8 FROM vDayYahoo2013BigVolume3000) as int) AS G7,
* from vDayYahoo2013BigVolume3000) x GROUP BY G7 ORDER BY 1
-- =======================================
-- Level 2
-- VolToAver, MaxPVolToAver
SELECT G0, G1, count(*) Cnt, AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5 FROM
(SELECT CAST(ROW_NUMBER() OVER(ORDER BY VolToAver ASC) /(SELECT (count(*)+6)/8 FROM vDayYahoo2013BigVolume3000) as int) AS G0,
CAST(ROW_NUMBER() OVER(ORDER BY MaxPVolToAver ASC) /(SELECT (count(*)+6)/8 FROM vDayYahoo2013BigVolume3000) as int) AS G1,
* from vDayYahoo2013BigVolume3000) x GROUP BY G0, G1 ORDER BY 1,2;

-- CloseToAver, OpenToClose
SELECT G2, G3, count(*) Cnt, AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5 FROM
(SELECT CAST(ROW_NUMBER() OVER(ORDER BY CloseToAver ASC) /(SELECT (count(*)+6)/8 FROM vDayYahoo2013BigVolume3000) as int) AS G2,
CAST(ROW_NUMBER() OVER(ORDER BY OpenToClose ASC) /(SELECT (count(*)+6)/8 FROM vDayYahoo2013BigVolume3000) as int) AS G3,
* from vDayYahoo2013BigVolume3000) x GROUP BY G2, G3 ORDER BY 1,2;

-- =======================================
-- Level 3
-- CloseToAver, OpenToClose, Close
SELECT G2, G3, G4, count(*) Cnt, 
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, CAST(ROUND(SUM(Sell_N1)*100.0/Count(*),1) as real) as Sell_N1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, CAST(ROUND(SUM(Sell_N2)*100.0/Count(*),1) as real) as Sell_N2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, CAST(ROUND(SUM(Sell_N3)*100.0/Count(*),1) as real) as Sell_N3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, CAST(ROUND(SUM(Sell_N4)*100.0/Count(*),1) as real) as Sell_N4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5, CAST(ROUND(SUM(Sell_N5)*100.0/Count(*),1) as real) as Sell_N5 FROM
(SELECT CAST(ROW_NUMBER() OVER(ORDER BY CloseToAver ASC) /(SELECT (count(*)+6)/8 FROM vDayYahoo2013BigVolume3000) as int) AS G2,
CAST(ROW_NUMBER() OVER(ORDER BY OpenToClose ASC) /(SELECT (count(*)+6)/8 FROM vDayYahoo2013BigVolume3000) as int) AS G3,
CAST(ROW_NUMBER() OVER(ORDER BY [Close] ASC) /(SELECT (count(*)+6)/8 FROM vDayYahoo2013BigVolume3000) as int) AS G4,
iif([Open_N1]>[CL_N1],1.0,0.0) as Sell_N1, iif([Open_N2]>[CL_N2],1.0,0.0) as Sell_N2, iif([Open_N3]>[CL_N3],1,0) as Sell_N3, iif([Open_N4]>[CL_N4],1,0) as Sell_N4, iif([Open_N5]>[CL_N5],1,0) as Sell_N5,
* from vDayYahoo2013BigVolume3000) x GROUP BY G2, G3, G4 ORDER BY 1,2,3;

-- Details WHERE G2=7 and G3=6 and G4=2
SELECT * FROM
(SELECT CAST(ROW_NUMBER() OVER(ORDER BY CloseToAver ASC) /(SELECT (count(*)+6)/8 FROM vDayYahoo2013BigVolume3000) as int) AS G2,
CAST(ROW_NUMBER() OVER(ORDER BY OpenToClose ASC) /(SELECT (count(*)+6)/8 FROM vDayYahoo2013BigVolume3000) as int) AS G3,
CAST(ROW_NUMBER() OVER(ORDER BY [Close] ASC) /(SELECT (count(*)+6)/8 FROM vDayYahoo2013BigVolume3000) as int) AS G4,
* from vDayYahoo2013BigVolume3000) x WHERE G2=7 and G3=6 and G4=2 ORDER BY Date, Symbol;

-- Details WHERE G2=7 and G3=7 and G4=0
SELECT * FROM
(SELECT CAST(ROW_NUMBER() OVER(ORDER BY CloseToAver ASC) /(SELECT (count(*)+6)/8 FROM vDayYahoo2013BigVolume3000) as int) AS G2,
CAST(ROW_NUMBER() OVER(ORDER BY OpenToClose ASC) /(SELECT (count(*)+6)/8 FROM vDayYahoo2013BigVolume3000) as int) AS G3,
CAST(ROW_NUMBER() OVER(ORDER BY [Close] ASC) /(SELECT (count(*)+6)/8 FROM vDayYahoo2013BigVolume3000) as int) AS G4,
* from vDayYahoo2013BigVolume3000) x WHERE G2=7 and G3=7 and G4=0 ORDER BY Date, Symbol;

-- ==========================================
-- !!! G2=9 (CloseToAver>1.10)

select G0, G1, G2, G3, G4, count(*) as Cnt,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, 
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5
from
(select 
iif(VolToAver<2.087, 0, iif(VolToAver<2.19, 1, iif(VolToAver<2.32, 2, iif(VolToAver<2.48, 3, iif(VolToAver<2.69, 4, iif(VolToAver<2.99, 5, iif(VolToAver<3.435, 6, iif(VolToAver<4.22, 7, iif(VolToAver<6.01, 8, 9))))))))) as G0,
iif(MaxPVolToAver<1.3,0, iif(MaxPVolToAver<1.39,1, iif(MaxPVolToAver<1.47,2, iif(MaxPVolToAver<1.55,3, iif(MaxPVolToAver<1.645,4, iif(MaxPVolToAver<1.76,5, iif(MaxPVolToAver<1.91,6, iif(MaxPVolToAver<2.14,7, iif(MaxPVolToAver<2.585,8,9))))))))) as G1,
iif(CloseToAver<0.915,0, iif(CloseToAver<0.95,1, iif(CloseToAver<0.974,2, iif(CloseToAver<0.99,3, iif(CloseToAver<1,4, iif(CloseToAver<1.017,5, iif(CloseToAver<1.035,6, iif(CloseToAver<1.06,7, iif(CloseToAver<1.106,8,9))))))))) as G2,
iif(CloseToOpen<0.9523196,0, iif(CloseToOpen<0.9742948,1, iif(CloseToOpen<0.9866623,2, iif(CloseToOpen<0.9950334,3, iif(CloseToOpen<1.000579,4, iif(CloseToOpen<1.007083,5, iif(CloseToOpen<1.016453,6, iif(CloseToOpen<1.030835,7, iif(CloseToOpen<1.056931,8,9))))))))) as G3,
iif([Close]<3.01,0, iif([Close]<5.72,1, iif([Close]<9.07,2, iif([Close]<13.16,3, iif([Close]<17.82,4, iif([Close]<23.45,5, iif([Close]<30.23,6, iif([Close]<40.18,7, iif([Close]<56.64,8,9))))))))) as G4,
* from vDayYahoo2013BigVolume3000) x
group by G0, G1, G2, G3, G4
having avg(r1)>1.05
order by 6 desc, 1,2,3,4,5;

select count(*) as Cnt, 
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, 
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5
from
(select 
iif(VolToAver<2.087, 0, iif(VolToAver<2.19, 1, iif(VolToAver<2.32, 2, iif(VolToAver<2.48, 3, iif(VolToAver<2.69, 4, iif(VolToAver<2.99, 5, iif(VolToAver<3.435, 6, iif(VolToAver<4.22, 7, iif(VolToAver<6.01, 8, 9))))))))) as G0,
iif(MaxPVolToAver<1.3,0, iif(MaxPVolToAver<1.39,1, iif(MaxPVolToAver<1.47,2, iif(MaxPVolToAver<1.55,3, iif(MaxPVolToAver<1.645,4, iif(MaxPVolToAver<1.76,5, iif(MaxPVolToAver<1.91,6, iif(MaxPVolToAver<2.14,7, iif(MaxPVolToAver<2.585,8,9))))))))) as G1,
iif(CloseToAver<0.915,0, iif(CloseToAver<0.95,1, iif(CloseToAver<0.974,2, iif(CloseToAver<0.99,3, iif(CloseToAver<1,4, iif(CloseToAver<1.017,5, iif(CloseToAver<1.035,6, iif(CloseToAver<1.06,7, iif(CloseToAver<1.106,8,9))))))))) as G2,
iif(CloseToOpen<0.9523196,0, iif(CloseToOpen<0.9742948,1, iif(CloseToOpen<0.9866623,2, iif(CloseToOpen<0.9950334,3, iif(CloseToOpen<1.000579,4, iif(CloseToOpen<1.007083,5, iif(CloseToOpen<1.016453,6, iif(CloseToOpen<1.030835,7, iif(CloseToOpen<1.056931,8,9))))))))) as G3,
iif([Close]<3.01,0, iif([Close]<5.72,1, iif([Close]<9.07,2, iif([Close]<13.16,3, iif([Close]<17.82,4, iif([Close]<23.45,5, iif([Close]<30.23,6, iif([Close]<40.18,7, iif([Close]<56.64,8,9))))))))) as G4,
* from vDayYahoo2013BigVolume3000) x
order by 1;

select * from
(select 
iif(VolToAver<2.087, 0, iif(VolToAver<2.19, 1, iif(VolToAver<2.32, 2, iif(VolToAver<2.48, 3, iif(VolToAver<2.69, 4, iif(VolToAver<2.99, 5, iif(VolToAver<3.435, 6, iif(VolToAver<4.22, 7, iif(VolToAver<6.01, 8, 9))))))))) as G0,
iif(MaxPVolToAver<1.3,0, iif(MaxPVolToAver<1.39,1, iif(MaxPVolToAver<1.47,2, iif(MaxPVolToAver<1.55,3, iif(MaxPVolToAver<1.645,4, iif(MaxPVolToAver<1.76,5, iif(MaxPVolToAver<1.91,6, iif(MaxPVolToAver<2.14,7, iif(MaxPVolToAver<2.585,8,9))))))))) as G1,
iif(CloseToAver<0.915,0, iif(CloseToAver<0.95,1, iif(CloseToAver<0.974,2, iif(CloseToAver<0.99,3, iif(CloseToAver<1,4, iif(CloseToAver<1.017,5, iif(CloseToAver<1.035,6, iif(CloseToAver<1.06,7, iif(CloseToAver<1.106,8,9))))))))) as G2,
iif(CloseToOpen<0.9523196,0, iif(CloseToOpen<0.9742948,1, iif(CloseToOpen<0.9866623,2, iif(CloseToOpen<0.9950334,3, iif(CloseToOpen<1.000579,4, iif(CloseToOpen<1.007083,5, iif(CloseToOpen<1.016453,6, iif(CloseToOpen<1.030835,7, iif(CloseToOpen<1.056931,8,9))))))))) as G3,
iif([Close]<3.01,0, iif([Close]<5.72,1, iif([Close]<9.07,2, iif([Close]<13.16,3, iif([Close]<17.82,4, iif([Close]<23.45,5, iif([Close]<30.23,6, iif([Close]<40.18,7, iif([Close]<56.64,8,9))))))))) as G4,
* from vDayYahoo2013BigVolume3000) x
where G0=4 and G1=8 and G2=0 and G3=1 and G4=0;


-- =============================================
select 1 Cnt, Open_N1/CL_N1 R1, Open_N1/CL_N2 R2, Open_N1/CL_N3 R3, Open_N1/CL_N4 R4, Open_N1/CL_N5 R5, 
Volume/AverVOL VolToAver, MaxPVol/AverVOL MaxPVolToAver, [Close]/ AverCl CloseToAver, [Close]/ [Open] CloseToOpen, a.*
from Temp_Query003 a
where [Close] >=1 and Volume > 300000  and Volume > 2* AverVOL and AverVOL > 50000-- all
-- where [Close] >=1 and Volume > 300000 and Volume > 5 * AverVOL and [MaxPVol]< 2* AverVOL and [Close] > 1.5 * AverCl and [Open]<[Close] -- 159 recs, open/CL_N1 average = 1.047, open/CL_N2 average = 1.082
--where [Close] >=1 and [Close]<5 and Volume > 300000 and Volume > 5 * AverVOL and [MaxPVol]< 2* AverVOL and [Close] > 1.5 * AverCl and [Open]<[Close] -- 86 recs, open/CL_N1 average = 1.080, open/CL_N2 average = 1.135, open/CL_N3 average = 1.157
-- where [Close] >=1 and [Close]<5 and Volume > 300000 and Volume > 3 * AverVOL and [MaxPVol]< 2* AverVOL and [Close] > 1.5 * AverCl and [Open]<[Close] and CL_N5 is not null -- 96 recs, open/CL_N1 average = 1.076, open/CL_N2 average = 1.132, open/CL_N3 average = 1.157
-- where [Close] >=1 and [Close]<5 and Volume > 300000 and Volume > 5 * AverVOL and [MaxPVol]< 2* AverVOL and [Close] < 0.7 * AverCl and [Open]>[Close] -- 134 recs, open/CL_N1 average = 1.036, open/CL_N2 average = 1.051, open/CL_N3 average = 1.058
-- where [Close] >=5 and Volume > 300000 and Volume > 5 * AverVOL and [MaxPVol]< 2* AverVOL and [Close] > 1.5 * AverCl and [Open]<[Close] -- 73 recs, open/CL_N1 average = 1.008
-- where [Close] >=5 and Volume > 300000 and Volume > 5 * AverVOL and [MaxPVol]< 2* AverVOL and [Close] > 1.2 * AverCl and [Open]<[Close] -- 700 recs, open/CL_N1 average = 0.9996

