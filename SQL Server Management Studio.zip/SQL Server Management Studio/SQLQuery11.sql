select a.Symbol, a.Exchange, min(a.Date), max(a.Date), AVG(a.[Close]*a.Volume)/1000000,
count(*) recs
from dbQuote2022..DayEoddata2013 a
left join dbQuote2023..HSymbolsEoddata b on a.Symbol=b.Symbol and a.Exchange=b.Exchange
where b.Symbol is null 
group by a.Symbol, a.Exchange
order by 1,2

select a.*
from dbQuote2022..SymbolsEoddata2013 a
left join dbQuote2023..HSymbolsEoddata b on a.Symbol=b.Symbol and a.Exchange=b.Exchange
where b.Symbol is null and a.Exchange not in ('Index') 
order by 1,2
