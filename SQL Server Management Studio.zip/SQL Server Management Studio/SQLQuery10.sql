-- For more details see in Q2024.Days.2024-03-01.sql

-- Execution duration is 95 seconds (from 2010 year)
;with data as
	(
		select ([Open]-[Close])/[Open]*100 PrevOpenRate, ([Open]-[Close])/([Open]+[Close])*200 PrevCO,
		([High]-[Low])/(High+Low)*200 PrevHL,
		a.* from dbQ2024..DayPolygon a 
		where a.IsTest is null and
--			 year(a.Date)>=2010 and
			 year(a.Date) in (2022,2023) and
			a.Volume*a.[Close]>=50000000 and a.TradeCount>=10000 --and a.[Close]>5.0
	),
	data2 as (
		select c.ProfitReal,
		iif(c.[Open]<c.[Close], 1, 0) UpCount,
		iif(c.[Open]>c.[Close], 1, 0) DownCount,
		c.ProfitDownRate, c.ProfitUpRate,
		-- (d1.[High]-d1.[Low])/(d1.High+d1.Low)*200 BeforePrevHL,
		-- (d2.[High]-d2.[Low])/(d2.High+d2.Low)*200 Before2PrevHL,
		 a.* from data a
		inner join dbQ2024..TradingDays b on a.Date=b.Date
		inner join (SELECT ([Open]-[Close])/[Open]*100 ProfitReal,
			dbQ2024.dbo.ProfitRateDown([Open], [High], [Close], 0.002*[Open]+0.02, 0.0) ProfitDownRate,
			dbQ2024.dbo.ProfitRateUp([Open], [Low], [Close], 0.002*[Open]+0.02, 0.0) ProfitUpRate,
			*
			FROM dbQ2024..DayPolygon) c on a.Symbol=c.Symbol and c.Date=b.Next1
		inner join  dbQ2024..DayPolygon d1 on d1.Symbol=a.Symbol and d1.Date=b.Prev1
		-- inner join  dbQ2024..DayPolygon d2 on d2.Symbol=a.Symbol and d2.Date=b.Prev2
		WHERE c.[Open] between 5.0 and 500.0 --and c.[Open]<a.High*0.95 and c.[Open]>a.Low
-- !! 60.17/1426		 and (d1.[High]-d1.[Low])/(d1.High+d1.Low)*200>=14
-- 57.27/2064 and (d1.[High]-d1.[Low])/(d1.High+d1.Low)*200>=7
	--	 and (d1.[High]-d1.[Low])/(d1.High+d1.Low)*200>=8 and PrevHL>=10
		 -- and (d2.[High]-d2.[Low])/(d2.High+d2.Low)*200>=8 
		-- /*and a.[Close]>c.[Open]*/ and d.[Close]>a.[Close]
--		and c.[Open] not between a.WeightedVolumePrice*0.99 and a.WeightedVolumePrice*1.01
-- !! 57.3/2295		and c.[Open] not between a.WeightedVolumePrice*0.99 and a.WeightedVolumePrice*1.01
-- !! 57.6/2205		and c.[Open] not between a.WeightedVolumePrice*0.98 and a.WeightedVolumePrice*1.02
-- 57.28/2191	and c.[Open] not between a.WeightedVolumePrice*0.98 and a.WeightedVolumePrice*1.02
-- 57.79/1686	and c.[Open] not between a.WeightedVolumePrice*0.95 and a.WeightedVolumePrice*1.05
-- 56.96/848	and c.[Open] >= a.WeightedVolumePrice*1.05
-- 57.72/1140	and c.[Open] <= a.WeightedVolumePrice*0.95
-- 58.82/561	and c.[Open] <= a.WeightedVolumePrice*0.9
-- !!! 60/880 and (c.[Open] <= a.WeightedVolumePrice*0.9 or c.[Open] >= a.WeightedVolumePrice*1.1)
-- and (c.[Open] <= a.WeightedVolumePrice*0.9 or c.[Open] >= a.WeightedVolumePrice*1.1)
-- 57.7/1286 and (c.[Open] <= a.WeightedVolumePrice*0.9 or c.[Open] >= a.WeightedVolumePrice*1.05)
-- 57.74/1673 and (c.[Open] <= a.WeightedVolumePrice*0.92 or c.[Open] >= a.WeightedVolumePrice*1.03)
-- 56.08/2040 and (c.[Open] <= a.WeightedVolumePrice*0.92 or c.[Open] >= a.WeightedVolumePrice*1.0)
-- 55.69/1977 and (c.[Open] <= a.WeightedVolumePrice*0.9 or c.[Open] >= a.WeightedVolumePrice*1.0)
-- 57.44/1809 and (c.[Open] not between a.WeightedVolumePrice*0.92 and a.WeightedVolumePrice*1.02 )
-- !!! 59.36/1149 and (c.[Open] not between a.WeightedVolumePrice*0.92 and a.WeightedVolumePrice*1.08 )
-- 58.67/1222 and (c.[Open] not between a.WeightedVolumePrice*0.925 and a.WeightedVolumePrice*1.075 )
-- 55.78/1902 	and c.[Open] <= a.WeightedVolumePrice
--	54.89/2261 and c.[Open] <= a.WeightedVolumePrice*1.05
-- 56.9		and c.[Open] not between a.[Close]*0.99 and a.[Close]*1.01
-- 56.16		and c.[Open] not between (a.[Open]+a.[Close])/2*0.99 and (a.[Open]+a.[Close])/2*1.01
--	56.7	and c.[Open] not between (a.High+a.Low)/2*0.99 and (a.High+a.Low)/2*1.01
-- 54.31/2252		and d.TradeCount<a.TradeCount
-- 54.93/2314		and d1.TradeCount<a.TradeCount*1.5
-- 54.7/2289		and d1.TradeCount<a.TradeCount*1.25
-- 55.29/946		and d.TradeCount>a.TradeCount
-- 56.51/1267		and d1.TradeCount*1.25>a.TradeCount
-- 55.72/1486		and d1.TradeCount*1.5>a.TradeCount
-- 54.34/1117		and d1.TradeCount between a.TradeCount*0.7 and a.TradeCount*1.5
-- 55.26/1692		and d1.TradeCount between a.TradeCount*0.5 and a.TradeCount*2.0
-- 55.45/2121		and d1.TradeCount between a.TradeCount*0.25 and a.TradeCount*4.0
-- 55.08/2242		and d1.TradeCount not between a.TradeCount*0.7 and a.TradeCount*1.5
-- 56.04/2334  and c.[Open]>a.Low
-- 56.32/2294  and c.[Open]>a.Low*1.02
-- 53.77/478  and c.[Open]<a.Low
-- 55.64/2315	and c.[Open]<a.High
-- 55.05/2278	and c.[Open] between a.[Low] and a.[High]
-- 54.19/1670	and c.[Open] between a.[Low]*1.05 and a.[High]*0.95
-- 54.98/1988	and c.[Open] not between a.[Low]*1.05 and a.[High]*0.95
-- 53.4/1528 and a.PrevCO>5
-- 55.51/2032 and a.PrevCO<=5
-- 56.85/2220 and (d.[High]-d.[Low])/(d.High+d.Low)*200>5
-- !! 58.5/1764 and (d.[High]-d.[Low])/(d.High+d.Low)*200>10
-- !! 59.74/1329 and (d.[High]-d.[Low])/(d.High+d.Low)*200>15
-- !! 59.27/1591 and (c.[Open] <= a.WeightedVolumePrice*0.9 or c.[Open] >= a.WeightedVolumePrice*1.1 or (d.[High]-d.[Low])/(d.High+d.Low)*200>15)
-- !! 58.64/1823 and (c.[Open] <= a.WeightedVolumePrice*0.9 or (d.[High]-d.[Low])/(d.High+d.Low)*200>10)
-- 56.2/1420 and (c.[Open] <= a.WeightedVolumePrice*0.9 or c.[Open] <= d.WeightedVolumePrice*0.9)
-- 58.96/402 and c.[Open] <= a.WeightedVolumePrice*0.875
-- 56.64/399 and c.[Open] between a.WeightedVolumePrice*0.87 and a.WeightedVolumePrice*0.92
-- 48.47/881 and (d.[High]-d.[Low])/(d.High+d.Low)*200<5
-- !! 62.7/815 and (a.[Close] not between a.WeightedVolumePrice*0.92 and a.WeightedVolumePrice*1.08)
-- 57.34/1559 and (a.[Close] not between a.WeightedVolumePrice*0.95 and a.WeightedVolumePrice*1.05)
-- !58.21/1895 and (a.[Close] not between a.WeightedVolumePrice*0.95 and a.WeightedVolumePrice*1.05 or c.[Open] not between a.WeightedVolumePrice*0.95 and a.WeightedVolumePrice*1.05)
-- 58.75/1503 and (a.[Close] not between a.WeightedVolumePrice*0.93 and a.WeightedVolumePrice*1.07 or c.[Open] not between a.WeightedVolumePrice*0.93 and a.WeightedVolumePrice*1.07)
-- 52.74/2260 and (a.[Close] between a.WeightedVolumePrice*0.92 and a.WeightedVolumePrice*1.08)
-- 55.85/2084 and (a.[Open] not between a.WeightedVolumePrice*0.92 and a.WeightedVolumePrice*1.08)
-- 56.77/2341 and (a.[High] not between a.WeightedVolumePrice*0.95 and a.WeightedVolumePrice*1.05)
-- 57.24/2140 and (a.[High] not between a.WeightedVolumePrice*0.92 and a.WeightedVolumePrice*1.08)
-- 56.92/2347 and (a.[Low] not between a.WeightedVolumePrice*0.95 and a.WeightedVolumePrice*1.05)
-- 57.43/2166 and (a.[Low] not between a.WeightedVolumePrice*0.92 and a.WeightedVolumePrice*1.08)
-- 57.66/1894 and (a.[Low] not between a.WeightedVolumePrice*0.9 and a.WeightedVolumePrice*1.1)
-- 56.84/2310 and (a.[Low] not between a.WeightedVolumePrice*0.95 and a.WeightedVolumePrice*1.05 and
-- 	a.[High] not between a.WeightedVolumePrice*0.95 and a.WeightedVolumePrice*1.05)
-- !59.21/1667 and (a.[Low] not between a.WeightedVolumePrice*0.92 and a.WeightedVolumePrice*1.08 and
-- 	a.[High] not between a.WeightedVolumePrice*0.92 and a.WeightedVolumePrice*1.08)
-- 58.13/1660 and (a.[Low] not between a.WeightedVolumePrice*0.95 and a.WeightedVolumePrice*1.05 and
--	a.[High] not between a.WeightedVolumePrice*0.95 and a.WeightedVolumePrice*1.05 and
--	c.[Open] not between a.WeightedVolumePrice*0.95 and a.WeightedVolumePrice*1.05)
		-- WHERE b.IsShortened is null
	),
	data3 as (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date ORDER BY PrevHL DESC), *
--       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date ORDER BY ABS(1.0-WeightedVolumePrice/[Open]) DESC), *
	   FROM data2
	),
	data4 as (SELECT * from data3 WHERE RN<=5 AND PrevHL>=14) 

	-- select * from data4

	select 'Total' Year, ROUND(avg(ProfitReal),3) ProfitReal,
	ROUND(sum(UpCount)*1E2/count(*),2) UpPerc,
	ROUND(sum(DownCount)*1E2/count(*),2) DownPerc,
	ROUND(avg(ProfitDownRate*1E2),3) 'ProfitDown%', ROUND(sum(ProfitDownRate),2) ProfitDownAmt,
	ROUND(sum(iif(ProfitDownRate>0E0,1E2,0E0))/count(*),2) WinsDown,
	ROUND(avg(ProfitUpRate*1E2),3) 'ProfitUp%', ROUND(sum(ProfitUpRate),2) ProfitUpAmt,
	ROUND(sum(iif(ProfitUpRate>0E0,1E2,0E0))/count(*),2) WinsUp,
	ROUND(avg(PrevHL),1) PrevHL, count(*) Recs
	from data4
	UNION ALL
	select format(Date, 'yyyy') Year, ROUND(avg(ProfitReal),3) ProfitReal,
	ROUND(sum(UpCount)*1E2/count(*),2) UpPerc,
	ROUND(sum(DownCount)*1E2/count(*),2) DownPerc,
	ROUND(avg(ProfitDownRate*1E2),3) 'ProfitDown%', ROUND(sum(ProfitDownRate),2) ProfitDownAmt,
	ROUND(sum(iif(ProfitDownRate>0E0,1E2,0E0))/count(*),2) WinsDown,
	ROUND(avg(ProfitUpRate*1E2),3) 'ProfitUp%', ROUND(sum(ProfitUpRate),2) ProfitUpAmt,
	ROUND(sum(iif(ProfitUpRate>0E0,1E2,0E0))/count(*),2) WinsUp,
	ROUND(avg(PrevHL),1) PrevHL, count(*) Recs
	from data4
	GROUP BY FORMAT(Date, 'yyyy') order by 1 desc

/* RN<=5 and PrevHL>=18.2
Year	ProfitReal	UpPerc	DownPerc	Recs	PrevHL	Profit1USD	ProfitWithCommision
Total	1,44	41,73	57,8	9812	35,6	14125,43	14109,26
2024	1,382	42,63	56,92	882	40,2	1218,84	1217,24
2023	2,584	40,35	59,43	917	39	2369,35	2367,7
2022	1,281	42,33	57,29	1063	39,1	1361,36	1359,45
2021	2,116	37,22	62,46	1252	46,5	2649,38	2647,15
2020	1,129	41,87	57,6	1144	39,7	1291,02	1289,05
2019	1,173	42,64	56,42	537	32,6	630,13	629,28
2018	1,314	42,84	56,43	684	30,1	898,75	897,76
2017	1,515	42,74	56,64	482	30,6	730,13	729,38
2016	1,05	46,24	53,27	612	29,3	642,48	641,54
2015	0,917	43,39	56,12	613	28,5	561,94	561,1
2014	1,278	41,92	57,69	520	26,8	664,47	663,73
2013	1,15	43,79	55,9	322	28	370,3	369,78
2012	0,947	37,27	61,99	271	24,9	256,75	256,33
2011	0,414	42,9	57,1	317	27,3	131,36	130,93
2010	1,781	41,33	57,65	196	33	349,15	348,85

By Period: Profit for 40 periods (from 178) < 0 
*/

/* RN<=5 and PrevHL>=14 (Limit/commission: 0.001*[Open]+0.01, 0.0), Open between 5 and 500
Year	ProfitReal	UpPerc	DownPerc	ProfitDown%	ProfitDownAmt	WinsDown	ProfitUp%	ProfitUpAmt	WinsUp	PrevHL	Recs
Total	1,131	43,19	56,26	0,344	47,3	5,51	0,14	19,24	3,62	30	13744
2024	1,203	42,96	56,54	0,346	3,47	4,3	0,34	3,4	3,8	37,4	1001
2023	2,144	42,61	57,13	0,408	4,72	5,45	-0,011	-0,13	2,33	34,2	1157
2022	0,955	43,29	56,3	0,288	3,49	3,46	0,169	2,06	2,96	35,9	1215
2021	2,124	37,22	62,46	0,376	4,74	4,21	0,038	0,48	1,51	46,3	1260
2020	1,145	41,85	57,58	0,584	7,24	5,97	0,259	3,21	2,82	37,9	1240
2019	0,895	45,8	53,43	0,324	2,93	5,42	0,158	1,43	4,42	25,9	904
2018	0,958	43,77	55,64	0,403	4,1	5,89	0,141	1,43	3,83	25,5	1019
2017	0,812	45,33	53,7	0,224	1,85	5,45	0,087	0,72	4	24,5	825
2016	0,791	46,92	52,76	0,222	2,09	4,25	0,245	2,31	4,99	24,6	942
2015	0,63	44,85	54,54	0,273	2,67	5,5	0,149	1,46	5,1	23,8	981
2014	1,172	42,19	57,58	0,325	2,85	5,59	0,131	1,15	3,19	22,4	877
2013	1,14	42,79	56,74	0,225	1,42	6,97	0,123	0,78	5,23	22,1	631
2012	0,571	42,09	57,07	0,251	1,49	8,59	0,15	0,89	6,23	20	594
2011	0,365	45,3	54,08	0,384	2,49	8,47	0,038	0,25	3,54	21,5	649
2010	1,038	44,32	54,12	0,387	1,74	7,8	-0,047	-0,21	2,9	23,3	449

By Period: Profit for 38 periods (from 178) < 0 
*/

/* RN<=10 and PrevHL>=14
Year	ProfitReal	UpPerc	DownPerc	Recs	PrevHL	Profit1USD
Total	0,885	44,08	55,43	20516	26,7	18160,86
2024	0,754	43,45	56,04	1763	29,2	1329,92
2023	1,469	45,3	54,35	1757	28,5	2580,93
2022	0,534	45,07	54,47	2192	28,6	1169,47
2021	1,737	38,93	60,79	2502	36,1	4345,38
2020	0,795	42,81	56,8	2331	30,4	1853,38
2019	0,756	47,02	52,38	1157	23,8	874,21
2018	0,832	44,9	54,48	1452	22,8	1208,54
2017	0,76	45,37	53,82	994	23	755,93
2016	0,621	46,66	52,96	1301	22,6	807,45
2015	0,23	47,35	52,14	1356	22	312,33
2014	0,961	44,47	55,35	1075	21,3	1033,52
2013	1,061	43,45	55,98	702	21,4	745,11
2012	0,48	43,07	56,02	664	19,5	318,96
2011	0,398	44,26	55,23	784	20,7	312,21
2010	1,057	43,21	55,35	486	24,5	513,5

By Period: Profit for 37 periods (from 178) < 0 
*/

-- ========================================
-- ==========  2022-2023 years  ===========
-- ========================================
/* 2022-2023 years
;with data as
	(
		select ([Open]-[Close])/[Open]*100 PrevOpenRate, ([Open]-[Close])/([Open]+[Close])*200 PrevCO,
		([High]-[Low])/(High+Low)*200 PrevHL,
		a.* from dbQ2024..DayPolygon a 
		where a.IsTest is null and year(a.Date) in (2022, 2023) and
			a.Volume*a.[Close]>=50000000 and a.TradeCount>=5000 -- and a.[Close]>5.0
	),
	data2 as (
		select c.ProfitReal, c.Profit, (c.[Open]-c.[Close]) ProfitValue, a.* from data a
		inner join dbQ2024..TradingDays b on a.Date=b.Date
		inner join (select ([Open]-[Close])/[Open]*100 ProfitReal,
			([Open]-[Close])/([Open]+[Close]) * 200.0 Profit, * from dbQ2024..DayPolygon where [Open]>=5.0)
		c on a.Symbol=c.Symbol and c.Date=b.Next1
		where b.IsShortened is null
	),
	data3 as (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date ORDER BY PrevHL DESC), *
	   FROM data2
	)

	-- select Date, RN, Symbol, ProfitReal, PrevHL from data3 WHERE RN<=5 and PrevHL>15 order by Date, RN
	select avg(ProfitReal) ProfitReal, avg(Profit) Profit, count(*) Recs, avg(PrevHL) PrevHL,
	ROUND(sum(ProfitValue),0) ProfitValue from data3
    WHERE RN<=5 and PrevHL>15*/
-- PrevHL desc, RN=5: 1,45840094434079	2505	1486
-- PrevHL(>15) desc, RN=5: 1,60664487931608	2307	1494
-- PrevHL(>20) desc, RN=5: 2,09192811379787	1740	1471
-- PrevHL(>25) desc, RN=5: 2,82318279959227	1284	1467
-- PrevHL(>30) desc, RN=5: 3,60795701275943	951	1483
-- PrevHL(>35) desc, RN=5: 4,2400278066021	748	1397
-- PrevHL desc, RN=10: 0,738772196036962	5010	1363
-- PrevHL desc, RN=25: 0,287135720958737	12525 1455
-- PrevCO desc, RN=5: 0,675292429198583	2505
-- PrevOpenRate desc, RN=5: 0,675292429198583	2505
-- PrevCO asc, RN=5: 0,820855568293594	2505
-- PrevOpenRate asc, RN=5: 0,820855568293594	2505