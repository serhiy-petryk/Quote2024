;with data as
(
select (a.[Open]-a.[Close])/a.[Open]*100 PrevOpenRate,
(a.[Open]-a.[Close])/(a.[Open]+a.[Close])*200 PrevCOProfit,
(a.[High]-a.[Low])/(a.High+a.Low)*200 PrevHLProfit,
a.*, b.MyType, b.Sector from dbQ2024..DayPolygon a 
inner join dbQ2024..SymbolsPolygon b on a.Symbol=b.Symbol and a.Date between b.Date and isnull(b.[To],'2099-12-31')
where a.IsTest is null and year(a.Date) in (2022,2023) and
a.Volume*a.[Close]>=50000000 and a.TradeCount>=10000 --and a.Low>=5.0
-- !!?? and a.[Close] between a.Low*1.05 and a.High*0.95  -- !!?? is worse
),
data2 as (
select c.Profit, (O0935-ISNULL(O1520, ISNULL(O1525, ISNULL(O1530, ISNULL(O1535, ISNULL(O1540, ISNULL(O1545, ISNULL(O1550, ISNULL(O1555, O1600))))))))) ProfitValue, a.* from data a
inner join dbQ2024..TradingDays b on a.Date=b.Prev1
inner join (select (O0935-ISNULL(O1520, ISNULL(O1525, ISNULL(O1530, ISNULL(O1535, ISNULL(O1540, ISNULL(O1545, ISNULL(O1550, ISNULL(O1555, O1600)))))))))/O0935*100 Profit,
*
from dbQ2024MinuteScanner..DailyBy5Minutes
where O0935>=5.0 and H1025 is not null /*Bad quote: EDTX/2023-07-14*/
 and O0930 is not null and O0935 is not null and ISNULL(O1520, ISNULL(O1525, ISNULL(O1530, ISNULL(O1535, ISNULL(O1540, ISNULL(O1545, ISNULL(O1550, ISNULL(O1555, O1600)))))))) is not null)
c on a.Symbol=c.Symbol and a.Date=c.PrevDate
--and c.[Open] between a.Low and a.High -- is worse
--and (c.[Open] <= a.Low or c.[Open]>=a.High) -- is worse
where b.IsShortened is null
),
data3 as (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date ORDER BY PrevHLProfit DESC), *
   FROM data2
)

select cast(ROUND(avg(Profit),3) as real) Profit, count(*) Recs, ROUND(avg(PrevHLProfit),2) PrevHLProfit,
ROUND(sum(ProfitValue),0) ProfitValue
from data3
    WHERE RN<=10 and PrevHLProfit>10

-- 0,969	2293	34,1	-1054
-- 1,023	2276	34,02	-952	0
-- 0,876	1890	28,32	-919	0