-- 1203/1067	1980/1018
select symbol, date, min(CountFull),max(CountFull), min(VolumeFull),max(VolumeFull), min(Created), max(Created)
from FileLogMinutePolygon
where folder<>'MinutePolygon_20230402' and
position<>'PARTIAL' and date>='2023-03-27'
group by symbol, date
having min(CountFull)<>max(CountFull)-- or min(VolumeFull)<>max(VolumeFull)
order by 7

-- 2 days: 16, 1 day: 100, 30 hours: 41, 33 hours: 28/33/41/26, 36 hours: 26, 39 hours: 26, 42 hours: 16, 66 hours: 1
select symbol, date, min(CountFull),max(CountFull), min(VolumeFull),max(VolumeFull), min(Created), max(Created)
from FileLogMinutePolygon
where -- folder<>'MinutePolygon_20230402' and
position<>'PARTIAL' and date>='2023-03-27'
and date<DATEADD(hour,-34,Created)
group by symbol, date
having min(CountFull)<>max(CountFull)-- or min(VolumeFull)<>max(VolumeFull)
order by 7




select  * from FileLogMinutePolygon
-- order by symbol
where folder='MinutePolygon_20230402' and Position like 'PART%';


select * from FileLogMinutePolygon where symbol='SHOO' and date='2023-01-30'
