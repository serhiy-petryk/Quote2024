select count(*) Cnt, AVG([Open]/ CL) as OpenToClose, ROUND(STDEV([Open]/ CL)*100,1) as D,
CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N1,
CAST(ROUND(SUM(iif([Open_N1]<[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Buy_N1,
cast(round(100.0*sum(iif(([High]-[Open])<0.00995,1,0))/count(*),2) as real) H,
cast(round(100.0*sum(iif(([Open]-[Low])<0.00995,1,0))/count(*),2) as real) L,
min(Date) MinDate, Max(Date) MaxDate
from vDayEoddata2013Extended;

select count(*) Cnt, AVG([Open]/ CL) as OpenToClose, ROUND(STDEV([Open]/ CL)*100,1) as D,
CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N1,
CAST(ROUND(SUM(iif([Open_N1]<[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Buy_N1,
cast(round(100.0*sum(iif(([High]-[Open])<0.00995,1,0))/count(*),2) as real) H,
cast(round(100.0*sum(iif(([Open]-[Low])<0.00995,1,0))/count(*),2) as real) L,
min(Date) MinDate, Max(Date) MaxDate
from vDayEoddata2013Extended where CL>=5.0 and VLM>=3000000.0;

select count(*) Cnt, AVG([Open]/ CL) as OpenToClose, ROUND(STDEV([Open]/ CL)*100,1) as D,
CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N1,
CAST(ROUND(SUM(iif([Open_N1]<[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Buy_N1,
cast(round(100.0*sum(iif(([High]-[Open])<0.00995,1,0))/count(*),2) as real) H,
cast(round(100.0*sum(iif(([Open]-[Low])<0.00995,1,0))/count(*),2) as real) L,
min(Date) MinDate, Max(Date) MaxDate
from vDayEoddata2013Extended where CL>=5.0 and VLM>=1000000.0;

select DATEPART(WEEKDAY, date) as DayNo, DATENAME(WEEKDAY, date) DayName, count(*) Cnt, 
AVG([Open]/CL) as OpenToClose, ROUND(STDEV([Open]/CL)*100,1) as D,
CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N1,
CAST(ROUND(SUM(iif([Open_N1]<[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Buy_N1,
cast(round(100.0*sum(iif(([High]-[Open])<0.00995,1,0))/count(*),2) as real) H,
cast(round(100.0*sum(iif(([Open]-[Low])<0.00995,1,0))/count(*),2) as real) L,
min(Date) MinDate, Max(Date) MaxDate
from vDayEoddata2013Extended
group by DATEPART(WEEKDAY, date), DATENAME(WEEKDAY, date) order by DATEPART(WEEKDAY, date);


select Exchange, count(*)
from vDayEoddata2013Extended
group by Exchange;
/*NASDAQ	145576
NYSE	399993*/

select count(*) Cnt, AVG([Open]/CL) as OpenToClose, ROUND(STDEV([Open]/CL)*100,1) as D,
cast(round(100.0*sum(iif([High]<[Open]+0.005,1,0))/count(*),2) as real) H0,
cast(round(100.0*sum(iif([Low]>[Open]-0.005,1,0))/count(*),2) as real) L0,
CAST(ROUND(SUM(iif([Open]>CL,1.0,0.0))*100.0/Count(*),1) as real) as Sell_N,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1,
CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0)*100.0*K1)/SUM(K1),1) as real) as Sell_N1,
cast(round(SUM(100.0*iif([High_N1]<[Open_N1]+0.005,1.0,0.0)*K1)/SUM(K1),2) as real) H1,
cast(round(SUM(100.0*iif([Low_N1]>[Open_N1]-0.005,1.0,0.0)*K1)/SUM(K1),2) as real) L1,

AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2,
CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0)*100.0*K2)/SUM(K2),1) as real) as Sell_N2,
cast(round(SUM(100.0*iif([High_N2]<[Open_N2]+0.005,1.0,0.0)*K2)/SUM(K2),2) as real) H2,
cast(round(SUM(100.0*iif([Low_N2]>[Open_N2]-0.005,1.0,0.0)*K2)/SUM(K2),2) as real) L2,

AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3,
CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0)*100.0*K3)/SUM(K3),1) as real) as Sell_N3,
cast(round(SUM(100.0*iif([High_N3]<[Open_N3]+0.005,1.0,0.0)*K3)/SUM(K3),2) as real) H3,
cast(round(SUM(100.0*iif([Low_N3]>[Open_N3]-0.005,1.0,0.0)*K3)/SUM(K3),2) as real) L3,

AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4,
CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0)*100.0*K4)/SUM(K4),1) as real) as Sell_N4,
cast(round(SUM(100.0*iif([High_N4]<[Open_N4]+0.005,1.0,0.0)*K4)/SUM(K4),2) as real) H4,
cast(round(SUM(100.0*iif([Low_N4]>[Open_N4]-0.005,1.0,0.0)*K4)/SUM(K4),2) as real) L4,

AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5,
CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0)*100.0*K5)/SUM(K5),1) as real) as Sell_N5,
cast(round(SUM(100.0*iif([High_N5]<[Open_N5]+0.005,1.0,0.0)*K5)/SUM(K5),2) as real) H5,
cast(round(SUM(100.0*iif([Low_N5]>[Open_N5]-0.005,1.0,0.0)*K3)/SUM(K5),2) as real) L5
from vDayEoddata2013Extended; -- 545569, 1.0005, 2.2

-- Ranges
-- Level 1
SELECT G0, min(VlmToWAvg) MinValue, max(VlmToWAvg) MaxValue, count(*) Cnt,
cast(round(100.0*sum(iif([High]<[Open]+0.005,1,0))/count(*),2) as real) H0,
cast(round(100.0*sum(iif([Low]>[Open]-0.005,1,0))/count(*),2) as real) L0,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1,
CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/SUM(K1),1) as real) as Sell_N1,
cast(round(SUM(100.0*iif([High_N1]<[Open_N1]+0.005,1.0,0.0)*K1)/SUM(K1),2) as real) H1,
cast(round(SUM(100.0*iif([Low_N1]>[Open_N1]-0.005,1.0,0.0)*K1)/SUM(K1),2) as real) L1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2,
CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/SUM(K2),1) as real) as Sell_N2,
cast(round(SUM(100.0*iif([High_N2]<[Open_N2]+0.005,1.0,0.0)*K2)/SUM(K2),2) as real) H2,
cast(round(SUM(100.0*iif([Low_N2]>[Open_N2]-0.005,1.0,0.0)*K2)/SUM(K2),2) as real) L2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3,
CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/SUM(K3),1) as real) as Sell_N3,
cast(round(SUM(100.0*iif([High_N3]<[Open_N3]+0.005,1.0,0.0)*K3)/SUM(K3),2) as real) H3,
cast(round(SUM(100.0*iif([Low_N3]>[Open_N3]-0.005,1.0,0.0)*K3)/SUM(K3),2) as real) L3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4,
CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/SUM(K4),1) as real) as Sell_N4,
cast(round(SUM(100.0*iif([High_N4]<[Open_N4]+0.005,1.0,0.0)*K4)/SUM(K4),2) as real) H4,
cast(round(SUM(100.0*iif([Low_N4]>[Open_N4]-0.005,1.0,0.0)*K4)/SUM(K4),2) as real) L4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5,
CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/SUM(K5),1) as real) as Sell_N5,
cast(round(SUM(100.0*iif([High_N5]<[Open_N5]+0.005,1.0,0.0)*K5)/SUM(K5),2) as real) H5,
cast(round(SUM(100.0*iif([Low_N5]>[Open_N5]-0.005,1.0,0.0)*K3)/SUM(K5),2) as real) L5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY VlmToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G0,
* from vDayEoddata2013Extended) x GROUP BY G0 ORDER BY 1;

SELECT G1, min(MaxPVlmToWAvg) MinValue, max(MaxPVlmToWAvg) MaxValue, count(*) Cnt,
cast(round(100.0*sum(iif([High]<[Open]+0.005,1,0))/count(*),2) as real) H0,
cast(round(100.0*sum(iif([Low]>[Open]-0.005,1,0))/count(*),2) as real) L0,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1,
CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/SUM(K1),1) as real) as Sell_N1,
cast(round(SUM(100.0*iif([High_N1]<[Open_N1]+0.005,1.0,0.0)*K1)/SUM(K1),2) as real) H1,
cast(round(SUM(100.0*iif([Low_N1]>[Open_N1]-0.005,1.0,0.0)*K1)/SUM(K1),2) as real) L1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2,
CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/SUM(K2),1) as real) as Sell_N2,
cast(round(SUM(100.0*iif([High_N2]<[Open_N2]+0.005,1.0,0.0)*K2)/SUM(K2),2) as real) H2,
cast(round(SUM(100.0*iif([Low_N2]>[Open_N2]-0.005,1.0,0.0)*K2)/SUM(K2),2) as real) L2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3,
CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/SUM(K3),1) as real) as Sell_N3,
cast(round(SUM(100.0*iif([High_N3]<[Open_N3]+0.005,1.0,0.0)*K3)/SUM(K3),2) as real) H3,
cast(round(SUM(100.0*iif([Low_N3]>[Open_N3]-0.005,1.0,0.0)*K3)/SUM(K3),2) as real) L3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4,
CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/SUM(K4),1) as real) as Sell_N4,
cast(round(SUM(100.0*iif([High_N4]<[Open_N4]+0.005,1.0,0.0)*K4)/SUM(K4),2) as real) H4,
cast(round(SUM(100.0*iif([Low_N4]>[Open_N4]-0.005,1.0,0.0)*K4)/SUM(K4),2) as real) L4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5,
CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/SUM(K5),1) as real) as Sell_N5,
cast(round(SUM(100.0*iif([High_N5]<[Open_N5]+0.005,1.0,0.0)*K5)/SUM(K5),2) as real) H5,
cast(round(SUM(100.0*iif([Low_N5]>[Open_N5]-0.005,1.0,0.0)*K3)/SUM(K5),2) as real) L5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY MaxPVlmToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G1,
* from vDayEoddata2013Extended) x GROUP BY G1 ORDER BY 1;

SELECT G2, min(CloseToWAvg) MinValue, max(CloseToWAvg) MaxValue, count(*) Cnt,
cast(round(100.0*sum(iif([High]<[Open]+0.005,1,0))/count(*),2) as real) H0,
cast(round(100.0*sum(iif([Low]>[Open]-0.005,1,0))/count(*),2) as real) L0,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1,
CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/SUM(K1),1) as real) as Sell_N1,
cast(round(SUM(100.0*iif([High_N1]<[Open_N1]+0.005,1.0,0.0)*K1)/SUM(K1),2) as real) H1,
cast(round(SUM(100.0*iif([Low_N1]>[Open_N1]-0.005,1.0,0.0)*K1)/SUM(K1),2) as real) L1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2,
CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/SUM(K2),1) as real) as Sell_N2,
cast(round(SUM(100.0*iif([High_N2]<[Open_N2]+0.005,1.0,0.0)*K2)/SUM(K2),2) as real) H2,
cast(round(SUM(100.0*iif([Low_N2]>[Open_N2]-0.005,1.0,0.0)*K2)/SUM(K2),2) as real) L2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3,
CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/SUM(K3),1) as real) as Sell_N3,
cast(round(SUM(100.0*iif([High_N3]<[Open_N3]+0.005,1.0,0.0)*K3)/SUM(K3),2) as real) H3,
cast(round(SUM(100.0*iif([Low_N3]>[Open_N3]-0.005,1.0,0.0)*K3)/SUM(K3),2) as real) L3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4,
CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/SUM(K4),1) as real) as Sell_N4,
cast(round(SUM(100.0*iif([High_N4]<[Open_N4]+0.005,1.0,0.0)*K4)/SUM(K4),2) as real) H4,
cast(round(SUM(100.0*iif([Low_N4]>[Open_N4]-0.005,1.0,0.0)*K4)/SUM(K4),2) as real) L4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5,
CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/SUM(K5),1) as real) as Sell_N5,
cast(round(SUM(100.0*iif([High_N5]<[Open_N5]+0.005,1.0,0.0)*K5)/SUM(K5),2) as real) H5,
cast(round(SUM(100.0*iif([Low_N5]>[Open_N5]-0.005,1.0,0.0)*K3)/SUM(K5),2) as real) L5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY CloseToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G2,
* from vDayEoddata2013Extended) x GROUP BY G2 ORDER BY 1;

SELECT G3, min(OpenToClose) MinValue, max(OpenToClose) MaxValue, count(*) Cnt,
cast(round(100.0*sum(iif([High]<[Open]+0.005,1,0))/count(*),2) as real) H0,
cast(round(100.0*sum(iif([Low]>[Open]-0.005,1,0))/count(*),2) as real) L0,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1,
CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/SUM(K1),1) as real) as Sell_N1,
cast(round(SUM(100.0*iif([High_N1]<[Open_N1]+0.005,1.0,0.0)*K1)/SUM(K1),2) as real) H1,
cast(round(SUM(100.0*iif([Low_N1]>[Open_N1]-0.005,1.0,0.0)*K1)/SUM(K1),2) as real) L1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2,
CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/SUM(K2),1) as real) as Sell_N2,
cast(round(SUM(100.0*iif([High_N2]<[Open_N2]+0.005,1.0,0.0)*K2)/SUM(K2),2) as real) H2,
cast(round(SUM(100.0*iif([Low_N2]>[Open_N2]-0.005,1.0,0.0)*K2)/SUM(K2),2) as real) L2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3,
CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/SUM(K3),1) as real) as Sell_N3,
cast(round(SUM(100.0*iif([High_N3]<[Open_N3]+0.005,1.0,0.0)*K3)/SUM(K3),2) as real) H3,
cast(round(SUM(100.0*iif([Low_N3]>[Open_N3]-0.005,1.0,0.0)*K3)/SUM(K3),2) as real) L3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4,
CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/SUM(K4),1) as real) as Sell_N4,
cast(round(SUM(100.0*iif([High_N4]<[Open_N4]+0.005,1.0,0.0)*K4)/SUM(K4),2) as real) H4,
cast(round(SUM(100.0*iif([Low_N4]>[Open_N4]-0.005,1.0,0.0)*K4)/SUM(K4),2) as real) L4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5,
CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/SUM(K5),1) as real) as Sell_N5,
cast(round(SUM(100.0*iif([High_N5]<[Open_N5]+0.005,1.0,0.0)*K5)/SUM(K5),2) as real) H5,
cast(round(SUM(100.0*iif([Low_N5]>[Open_N5]-0.005,1.0,0.0)*K3)/SUM(K5),2) as real) L5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY OpenToClose ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G3,
* from vDayEoddata2013Extended) x GROUP BY G3 ORDER BY 1;

SELECT G4, min(CL) MinValue, max(CL) MaxValue, count(*) Cnt,
cast(round(100.0*sum(iif([High]<[Open]+0.005,1,0))/count(*),2) as real) H0,
cast(round(100.0*sum(iif([Low]>[Open]-0.005,1,0))/count(*),2) as real) L0,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1,
CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/SUM(K1),1) as real) as Sell_N1,
cast(round(SUM(100.0*iif([High_N1]<[Open_N1]+0.005,1.0,0.0)*K1)/SUM(K1),2) as real) H1,
cast(round(SUM(100.0*iif([Low_N1]>[Open_N1]-0.005,1.0,0.0)*K1)/SUM(K1),2) as real) L1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2,
CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/SUM(K2),1) as real) as Sell_N2,
cast(round(SUM(100.0*iif([High_N2]<[Open_N2]+0.005,1.0,0.0)*K2)/SUM(K2),2) as real) H2,
cast(round(SUM(100.0*iif([Low_N2]>[Open_N2]-0.005,1.0,0.0)*K2)/SUM(K2),2) as real) L2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3,
CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/SUM(K3),1) as real) as Sell_N3,
cast(round(SUM(100.0*iif([High_N3]<[Open_N3]+0.005,1.0,0.0)*K3)/SUM(K3),2) as real) H3,
cast(round(SUM(100.0*iif([Low_N3]>[Open_N3]-0.005,1.0,0.0)*K3)/SUM(K3),2) as real) L3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4,
CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/SUM(K4),1) as real) as Sell_N4,
cast(round(SUM(100.0*iif([High_N4]<[Open_N4]+0.005,1.0,0.0)*K4)/SUM(K4),2) as real) H4,
cast(round(SUM(100.0*iif([Low_N4]>[Open_N4]-0.005,1.0,0.0)*K4)/SUM(K4),2) as real) L4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5,
CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/SUM(K5),1) as real) as Sell_N5,
cast(round(SUM(100.0*iif([High_N5]<[Open_N5]+0.005,1.0,0.0)*K5)/SUM(K5),2) as real) H5,
cast(round(SUM(100.0*iif([Low_N5]>[Open_N5]-0.005,1.0,0.0)*K3)/SUM(K5),2) as real) L5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY CL ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G4,
* from vDayEoddata2013Extended) x GROUP BY G4 ORDER BY 1;

SELECT G5, min(WAvgVLM) MinValue, max(WAvgVLM) MaxValue, count(*) Cnt,
cast(round(100.0*sum(iif([High]<[Open]+0.005,1,0))/count(*),2) as real) H0,
cast(round(100.0*sum(iif([Low]>[Open]-0.005,1,0))/count(*),2) as real) L0,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1,
CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/SUM(K1),1) as real) as Sell_N1,
cast(round(SUM(100.0*iif([High_N1]<[Open_N1]+0.005,1.0,0.0)*K1)/SUM(K1),2) as real) H1,
cast(round(SUM(100.0*iif([Low_N1]>[Open_N1]-0.005,1.0,0.0)*K1)/SUM(K1),2) as real) L1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2,
CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/SUM(K2),1) as real) as Sell_N2,
cast(round(SUM(100.0*iif([High_N2]<[Open_N2]+0.005,1.0,0.0)*K2)/SUM(K2),2) as real) H2,
cast(round(SUM(100.0*iif([Low_N2]>[Open_N2]-0.005,1.0,0.0)*K2)/SUM(K2),2) as real) L2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3,
CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/SUM(K3),1) as real) as Sell_N3,
cast(round(SUM(100.0*iif([High_N3]<[Open_N3]+0.005,1.0,0.0)*K3)/SUM(K3),2) as real) H3,
cast(round(SUM(100.0*iif([Low_N3]>[Open_N3]-0.005,1.0,0.0)*K3)/SUM(K3),2) as real) L3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4,
CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/SUM(K4),1) as real) as Sell_N4,
cast(round(SUM(100.0*iif([High_N4]<[Open_N4]+0.005,1.0,0.0)*K4)/SUM(K4),2) as real) H4,
cast(round(SUM(100.0*iif([Low_N4]>[Open_N4]-0.005,1.0,0.0)*K4)/SUM(K4),2) as real) L4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5,
CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/SUM(K5),1) as real) as Sell_N5,
cast(round(SUM(100.0*iif([High_N5]<[Open_N5]+0.005,1.0,0.0)*K5)/SUM(K5),2) as real) H5,
cast(round(SUM(100.0*iif([Low_N5]>[Open_N5]-0.005,1.0,0.0)*K3)/SUM(K5),2) as real) L5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY WAvgVLM ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G5,
* from vDayEoddata2013Extended) x GROUP BY G5 ORDER BY 1;

SELECT G6, min(DJI_ToWAvg) MinValue, max(DJI_ToWAvg) MaxValue, count(*) Cnt,
cast(round(100.0*sum(iif([High]<[Open]+0.005,1,0))/count(*),2) as real) H0,
cast(round(100.0*sum(iif([Low]>[Open]-0.005,1,0))/count(*),2) as real) L0,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1,
CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/SUM(K1),1) as real) as Sell_N1,
cast(round(SUM(100.0*iif([High_N1]<[Open_N1]+0.005,1.0,0.0)*K1)/SUM(K1),2) as real) H1,
cast(round(SUM(100.0*iif([Low_N1]>[Open_N1]-0.005,1.0,0.0)*K1)/SUM(K1),2) as real) L1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2,
CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/SUM(K2),1) as real) as Sell_N2,
cast(round(SUM(100.0*iif([High_N2]<[Open_N2]+0.005,1.0,0.0)*K2)/SUM(K2),2) as real) H2,
cast(round(SUM(100.0*iif([Low_N2]>[Open_N2]-0.005,1.0,0.0)*K2)/SUM(K2),2) as real) L2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3,
CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/SUM(K3),1) as real) as Sell_N3,
cast(round(SUM(100.0*iif([High_N3]<[Open_N3]+0.005,1.0,0.0)*K3)/SUM(K3),2) as real) H3,
cast(round(SUM(100.0*iif([Low_N3]>[Open_N3]-0.005,1.0,0.0)*K3)/SUM(K3),2) as real) L3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4,
CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/SUM(K4),1) as real) as Sell_N4,
cast(round(SUM(100.0*iif([High_N4]<[Open_N4]+0.005,1.0,0.0)*K4)/SUM(K4),2) as real) H4,
cast(round(SUM(100.0*iif([Low_N4]>[Open_N4]-0.005,1.0,0.0)*K4)/SUM(K4),2) as real) L4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5,
CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/SUM(K5),1) as real) as Sell_N5,
cast(round(SUM(100.0*iif([High_N5]<[Open_N5]+0.005,1.0,0.0)*K5)/SUM(K5),2) as real) H5,
cast(round(SUM(100.0*iif([Low_N5]>[Open_N5]-0.005,1.0,0.0)*K3)/SUM(K5),2) as real) L5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY DJI_ToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G6,
* from vDayEoddata2013Extended) x GROUP BY G6 ORDER BY 1;

SELECT G7, min(GSPC_ToWAvg) MinValue, max(GSPC_ToWAvg) MaxValue, count(*) Cnt,
cast(round(100.0*sum(iif([High]<[Open]+0.005,1,0))/count(*),2) as real) H0,
cast(round(100.0*sum(iif([Low]>[Open]-0.005,1,0))/count(*),2) as real) L0,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1,
CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/SUM(K1),1) as real) as Sell_N1,
cast(round(SUM(100.0*iif([High_N1]<[Open_N1]+0.005,1.0,0.0)*K1)/SUM(K1),2) as real) H1,
cast(round(SUM(100.0*iif([Low_N1]>[Open_N1]-0.005,1.0,0.0)*K1)/SUM(K1),2) as real) L1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2,
CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/SUM(K2),1) as real) as Sell_N2,
cast(round(SUM(100.0*iif([High_N2]<[Open_N2]+0.005,1.0,0.0)*K2)/SUM(K2),2) as real) H2,
cast(round(SUM(100.0*iif([Low_N2]>[Open_N2]-0.005,1.0,0.0)*K2)/SUM(K2),2) as real) L2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3,
CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/SUM(K3),1) as real) as Sell_N3,
cast(round(SUM(100.0*iif([High_N3]<[Open_N3]+0.005,1.0,0.0)*K3)/SUM(K3),2) as real) H3,
cast(round(SUM(100.0*iif([Low_N3]>[Open_N3]-0.005,1.0,0.0)*K3)/SUM(K3),2) as real) L3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4,
CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/SUM(K4),1) as real) as Sell_N4,
cast(round(SUM(100.0*iif([High_N4]<[Open_N4]+0.005,1.0,0.0)*K4)/SUM(K4),2) as real) H4,
cast(round(SUM(100.0*iif([Low_N4]>[Open_N4]-0.005,1.0,0.0)*K4)/SUM(K4),2) as real) L4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5,
CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/SUM(K5),1) as real) as Sell_N5,
cast(round(SUM(100.0*iif([High_N5]<[Open_N5]+0.005,1.0,0.0)*K5)/SUM(K5),2) as real) H5,
cast(round(SUM(100.0*iif([Low_N5]>[Open_N5]-0.005,1.0,0.0)*K3)/SUM(K5),2) as real) L5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY GSPC_ToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G7,
* from vDayEoddata2013Extended) x GROUP BY G7 ORDER BY 1;

SELECT G8, min(WAvgVolatility) MinValue, max(WAvgVolatility) MaxValue, count(*) Cnt,
cast(round(100.0*sum(iif([High]<[Open]+0.005,1,0))/count(*),2) as real) H0,
cast(round(100.0*sum(iif([Low]>[Open]-0.005,1,0))/count(*),2) as real) L0,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1,
CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/SUM(K1),1) as real) as Sell_N1,
cast(round(SUM(100.0*iif([High_N1]<[Open_N1]+0.005,1.0,0.0)*K1)/SUM(K1),2) as real) H1,
cast(round(SUM(100.0*iif([Low_N1]>[Open_N1]-0.005,1.0,0.0)*K1)/SUM(K1),2) as real) L1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2,
CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/SUM(K2),1) as real) as Sell_N2,
cast(round(SUM(100.0*iif([High_N2]<[Open_N2]+0.005,1.0,0.0)*K2)/SUM(K2),2) as real) H2,
cast(round(SUM(100.0*iif([Low_N2]>[Open_N2]-0.005,1.0,0.0)*K2)/SUM(K2),2) as real) L2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3,
CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/SUM(K3),1) as real) as Sell_N3,
cast(round(SUM(100.0*iif([High_N3]<[Open_N3]+0.005,1.0,0.0)*K3)/SUM(K3),2) as real) H3,
cast(round(SUM(100.0*iif([Low_N3]>[Open_N3]-0.005,1.0,0.0)*K3)/SUM(K3),2) as real) L3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4,
CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/SUM(K4),1) as real) as Sell_N4,
cast(round(SUM(100.0*iif([High_N4]<[Open_N4]+0.005,1.0,0.0)*K4)/SUM(K4),2) as real) H4,
cast(round(SUM(100.0*iif([Low_N4]>[Open_N4]-0.005,1.0,0.0)*K4)/SUM(K4),2) as real) L4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5,
CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/SUM(K5),1) as real) as Sell_N5,
cast(round(SUM(100.0*iif([High_N5]<[Open_N5]+0.005,1.0,0.0)*K5)/SUM(K5),2) as real) H5,
cast(round(SUM(100.0*iif([Low_N5]>[Open_N5]-0.005,1.0,0.0)*K3)/SUM(K5),2) as real) L5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY WAvgVolatility ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G8,
* from vDayEoddata2013Extended) x GROUP BY G8 ORDER BY 1;

SELECT G9, min((High-Low)/CL*100.0/WAvgVolatility) MinValue, max((High-Low)/CL*100.0/WAvgVolatility) MaxValue, count(*) Cnt,
cast(round(100.0*sum(iif([High]<[Open]+0.005,1,0))/count(*),2) as real) H0,
cast(round(100.0*sum(iif([Low]>[Open]-0.005,1,0))/count(*),2) as real) L0,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1,
CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/SUM(K1),1) as real) as Sell_N1,
cast(round(SUM(100.0*iif([High_N1]<[Open_N1]+0.005,1.0,0.0)*K1)/SUM(K1),2) as real) H1,
cast(round(SUM(100.0*iif([Low_N1]>[Open_N1]-0.005,1.0,0.0)*K1)/SUM(K1),2) as real) L1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2,
CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/SUM(K2),1) as real) as Sell_N2,
cast(round(SUM(100.0*iif([High_N2]<[Open_N2]+0.005,1.0,0.0)*K2)/SUM(K2),2) as real) H2,
cast(round(SUM(100.0*iif([Low_N2]>[Open_N2]-0.005,1.0,0.0)*K2)/SUM(K2),2) as real) L2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3,
CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/SUM(K3),1) as real) as Sell_N3,
cast(round(SUM(100.0*iif([High_N3]<[Open_N3]+0.005,1.0,0.0)*K3)/SUM(K3),2) as real) H3,
cast(round(SUM(100.0*iif([Low_N3]>[Open_N3]-0.005,1.0,0.0)*K3)/SUM(K3),2) as real) L3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4,
CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/SUM(K4),1) as real) as Sell_N4,
cast(round(SUM(100.0*iif([High_N4]<[Open_N4]+0.005,1.0,0.0)*K4)/SUM(K4),2) as real) H4,
cast(round(SUM(100.0*iif([Low_N4]>[Open_N4]-0.005,1.0,0.0)*K4)/SUM(K4),2) as real) L4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5,
CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/SUM(K5),1) as real) as Sell_N5,
cast(round(SUM(100.0*iif([High_N5]<[Open_N5]+0.005,1.0,0.0)*K5)/SUM(K5),2) as real) H5,
cast(round(SUM(100.0*iif([Low_N5]>[Open_N5]-0.005,1.0,0.0)*K3)/SUM(K5),2) as real) L5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY (High-Low)/CL*100.0/WAvgVolatility ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G9,
* from vDayEoddata2013Extended) x GROUP BY G9 ORDER BY 1;

-- ========================================
-- ========================================
-- ========================================
-- ========================================

SELECT G1, min(MaxPVlmToWAvg) MinValue, max(MaxPVlmToWAvg) MaxValue, count(*) Cnt,
cast(round(100.0*sum(iif([High]<[Open]+0.005,1,0))/count(*),2) as real) H1,
cast(round(100.0*sum(iif([Low]>[Open]-0.005,1,0))/count(*),2) as real) L1,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5, CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY MaxPVlmToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G1,
* from vDayEoddata2013Extended) x GROUP BY G1 ORDER BY 1

SELECT G2, min(CloseToWAvg) MinValue, max(CloseToWAvg) MaxValue, count(*) Cnt,
cast(round(100.0*sum(iif([High]<[Open]+0.005,1,0))/count(*),2) as real) H1,
cast(round(100.0*sum(iif([Low]>[Open]-0.005,1,0))/count(*),2) as real) L1,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5, CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY CloseToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G2,
* from vDayEoddata2013Extended) x GROUP BY G2 ORDER BY 1

SELECT G3, min(OpenToClose) MinValue, max(OpenToClose) MaxValue, count(*) Cnt,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5, CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY OpenToClose ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G3,
* from vDayEoddata2013Extended) x GROUP BY G3 ORDER BY 1

SELECT G4, min(CL) MinValue, max(CL) MaxValue, count(*) Cnt,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5, CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY CL ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G4,
* from vDayEoddata2013Extended) x GROUP BY G4 ORDER BY 1

SELECT G5, min(WAvgVOL) MinValue, max(WAvgVOL) MaxValue, count(*) Cnt,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5, CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY WAvgVOL ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G5,
* from vDayEoddata2013Extended) x GROUP BY G5 ORDER BY 1

SELECT G6, min(DJI_ToWAvg) MinValue, max(DJI_ToWAvg) MaxValue, count(*) Cnt,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5, CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY DJI_ToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G6,
* from vDayEoddata2013Extended) x GROUP BY G6 ORDER BY 1

SELECT G7, min(GSPC_ToWAvg) MinValue, max(GSPC_ToWAvg) MaxValue, count(*) Cnt,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5, CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY GSPC_ToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G7,
* from vDayEoddata2013Extended) x GROUP BY G7 ORDER BY 1

SELECT G8, min(AvgVolatility) MinValue, max(AvgVolatility) MaxValue, count(*) Cnt,
100.0*sum(iif([High]<[Open]+0.005,1,0))/count(*) H1, 100.0*sum(iif([Low]>[Open]-0.005,1,0))/count(*) L1,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5, CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY AvgVolatility ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G8,
* from vDayEoddata2013Extended) x GROUP BY G8 ORDER BY 1

SELECT G9, min((High-Low)/CL*100.0/AvgVolatility) MinValue, max((High-Low)/CL*100.0/AvgVolatility) MaxValue, count(*) Cnt,
cast(round(100.0*sum(iif([High]<[Open]+0.005,1,0))/count(*),2) as real) H1,
cast(round(100.0*sum(iif([Low]>[Open]-0.005,1,0))/count(*),2) as real) L1,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5, CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY (High-Low)/CL*100.0/AvgVolatility ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G9,
* from vDayEoddata2013Extended) x GROUP BY G9 ORDER BY 1
-- =======================================
-- Level 2
-- VolToWAvg, MaxPVolToWAvg
SELECT G0, G1, count(*) Cnt,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5, CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY VolToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G0,
CAST(ROW_NUMBER() OVER(ORDER BY MaxPVolToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G1,
* from vDayEoddata2013Extended) x GROUP BY G0, G1 ORDER BY 1,2;

-- VolToWAvg, CloseToWAvg
SELECT G0, G2, count(*) Cnt,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5, CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY VolToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G0,
CAST(ROW_NUMBER() OVER(ORDER BY CloseToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G2,
* from vDayEoddata2013Extended) x GROUP BY G0, G2 ORDER BY 1,2;

-- VolToWAvg, OpenToClose
SELECT G0, G3, count(*) Cnt,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5, CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY VolToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G0,
CAST(ROW_NUMBER() OVER(ORDER BY OpenToClose ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G3,
* from vDayEoddata2013Extended) x GROUP BY G0, G3 ORDER BY 1,2;

-- VolToWAvg, [Close]
SELECT G0, G4, count(*) Cnt,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5, CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY VolToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G0,
CAST(ROW_NUMBER() OVER(ORDER BY [Close] ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G4,
* from vDayEoddata2013Extended) x GROUP BY G0, G4 ORDER BY 1,2;

-- VolToWAvg, WAvgVOL
SELECT G0, G5, count(*) Cnt,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5, CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY VolToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G0,
CAST(ROW_NUMBER() OVER(ORDER BY WAvgVOL ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G5,
* from vDayEoddata2013Extended) x GROUP BY G0, G5 ORDER BY 1,2;

-- VolToWAvg, DJI_ToWAvg
SELECT G0, G6, count(*) Cnt,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5, CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY VolToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G0,
CAST(ROW_NUMBER() OVER(ORDER BY DJI_ToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G6,
* from vDayEoddata2013Extended) x GROUP BY G0, G6 ORDER BY 1,2;

-- VolToWAvg, GSPC_ToWAvg
SELECT G0, G7, count(*) Cnt,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5, CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/Count(*),1) as real) as Sell_N5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY VolToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G0,
CAST(ROW_NUMBER() OVER(ORDER BY GSPC_ToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G7,
* from vDayEoddata2013Extended) x GROUP BY G0, G7 ORDER BY 1,2;

/*-- =======================================
-- Level 2
-- VolToWAvg, MaxPVolToWAvg
SELECT G0, G1, count(*) Cnt, AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5 FROM
(SELECT CAST(ROW_NUMBER() OVER(ORDER BY VolToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G0,
CAST(ROW_NUMBER() OVER(ORDER BY MaxPVolToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G1,
* from vDayEoddata2013Extended) x GROUP BY G0, G1 ORDER BY 1,2;

-- CloseToWAvg, OpenToClose
SELECT G2, G3, count(*) Cnt, AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5 FROM
(SELECT CAST(ROW_NUMBER() OVER(ORDER BY CloseToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G2,
CAST(ROW_NUMBER() OVER(ORDER BY OpenToClose ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G3,
* from vDayEoddata2013Extended) x GROUP BY G2, G3 ORDER BY 1,2;

-- CloseToWAvg, Close
SELECT G2, G4, count(*) Cnt, AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5 FROM
(SELECT CAST(ROW_NUMBER() OVER(ORDER BY CloseToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G2,
CAST(ROW_NUMBER() OVER(ORDER BY [Close] ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G4,
* from vDayEoddata2013Extended) x GROUP BY G2, G4 ORDER BY 1,2;

-- CloseToWAvg, DJI_ToWAvg
SELECT G2, G6, count(*) Cnt, AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5 FROM
(SELECT CAST(ROW_NUMBER() OVER(ORDER BY CloseToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G2,
CAST(ROW_NUMBER() OVER(ORDER BY DJI_ToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G6,
* from vDayEoddata2013Extended) x GROUP BY G2, G6 ORDER BY 1,2;

-- CloseToWAvg, GSPC_ToWAvg
SELECT G2, G7, count(*) Cnt, AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5 FROM
(SELECT CAST(ROW_NUMBER() OVER(ORDER BY CloseToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G2,
CAST(ROW_NUMBER() OVER(ORDER BY GSPC_ToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G7,
* from vDayEoddata2013Extended) x GROUP BY G2, G7 ORDER BY 1,2;

-- OpenToClose, Close
SELECT G3, G4, count(*) Cnt, AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5 FROM
(SELECT CAST(ROW_NUMBER() OVER(ORDER BY OpenToClose ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G3,
CAST(ROW_NUMBER() OVER(ORDER BY [Close] ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G4,
* from vDayEoddata2013Extended) x GROUP BY G3, G4 ORDER BY 1,2;

-- OpenToClose, DJI_ToWAvg
SELECT G3, G6, count(*) Cnt, AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5 FROM
(SELECT CAST(ROW_NUMBER() OVER(ORDER BY OpenToClose ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G3,
CAST(ROW_NUMBER() OVER(ORDER BY DJI_ToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G6,
* from vDayEoddata2013Extended) x GROUP BY G3, G6 ORDER BY 1,2;

-- OpenToClose, GSPC_ToWAvg
SELECT G3, G7, count(*) Cnt, AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5 FROM
(SELECT CAST(ROW_NUMBER() OVER(ORDER BY OpenToClose ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G3,
CAST(ROW_NUMBER() OVER(ORDER BY GSPC_ToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G7,
* from vDayEoddata2013Extended) x GROUP BY G3, G7 ORDER BY 1,2;*/

-- =======================================
-- Level 3
-- CloseToWAvg, OpenToClose, Close
SELECT G2, G3, G4, count(*) Cnt, 
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, CAST(ROUND(SUM(Sell_N1)*100.0/Count(*),1) as real) as Sell_N1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2, CAST(ROUND(SUM(Sell_N2)*100.0/Count(*),1) as real) as Sell_N2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3, CAST(ROUND(SUM(Sell_N3)*100.0/Count(*),1) as real) as Sell_N3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4, CAST(ROUND(SUM(Sell_N4)*100.0/Count(*),1) as real) as Sell_N4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5, CAST(ROUND(SUM(Sell_N5)*100.0/Count(*),1) as real) as Sell_N5 FROM
(SELECT CAST(ROW_NUMBER() OVER(ORDER BY CloseToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G2,
CAST(ROW_NUMBER() OVER(ORDER BY OpenToClose ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G3,
CAST(ROW_NUMBER() OVER(ORDER BY [Close] ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G4,
iif([Open_N1]>[CL_N1],1.0,0.0) as Sell_N1, iif([Open_N2]>[CL_N2],1.0,0.0) as Sell_N2, iif([Open_N3]>[CL_N3],1,0) as Sell_N3, iif([Open_N4]>[CL_N4],1,0) as Sell_N4, iif([Open_N5]>[CL_N5],1,0) as Sell_N5,
* from vDayEoddata2013Extended) x GROUP BY G2, G3, G4 ORDER BY 1,2,3;

-- Details WHERE G2=7 and G3=6 and G4=2
SELECT * FROM
(SELECT CAST(ROW_NUMBER() OVER(ORDER BY CloseToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G2,
CAST(ROW_NUMBER() OVER(ORDER BY OpenToClose ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G3,
CAST(ROW_NUMBER() OVER(ORDER BY [Close] ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G4,
* from vDayEoddata2013Extended) x WHERE G2=7 and G3=6 and G4=2 ORDER BY Date, Symbol;

-- Details WHERE G2=7 and G3=7 and G4=0
SELECT * FROM
(SELECT CAST(ROW_NUMBER() OVER(ORDER BY CloseToWAvg ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G2,
CAST(ROW_NUMBER() OVER(ORDER BY OpenToClose ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G3,
CAST(ROW_NUMBER() OVER(ORDER BY [Close] ASC) /(SELECT (count(*)+8)/8 FROM vDayEoddata2013Extended) as int) AS G4,
* from vDayEoddata2013Extended) x WHERE G2=7 and G3=7 and G4=0 ORDER BY Date, Symbol;

-- ==========================================
-- !!! G2=9 (CloseToWAvg>1.10)

select G0, G1, G2, G3, G4, count(*) as Cnt,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, 
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5
from
(select 
iif(VolToWAvg<2.087, 0, iif(VolToWAvg<2.19, 1, iif(VolToWAvg<2.32, 2, iif(VolToWAvg<2.48, 3, iif(VolToWAvg<2.69, 4, iif(VolToWAvg<2.99, 5, iif(VolToWAvg<3.435, 6, iif(VolToWAvg<4.22, 7, iif(VolToWAvg<6.01, 8, 9))))))))) as G0,
iif(MaxPVolToWAvg<1.3,0, iif(MaxPVolToWAvg<1.39,1, iif(MaxPVolToWAvg<1.47,2, iif(MaxPVolToWAvg<1.55,3, iif(MaxPVolToWAvg<1.645,4, iif(MaxPVolToWAvg<1.76,5, iif(MaxPVolToWAvg<1.91,6, iif(MaxPVolToWAvg<2.14,7, iif(MaxPVolToWAvg<2.585,8,9))))))))) as G1,
iif(CloseToWAvg<0.915,0, iif(CloseToWAvg<0.95,1, iif(CloseToWAvg<0.974,2, iif(CloseToWAvg<0.99,3, iif(CloseToWAvg<1,4, iif(CloseToWAvg<1.017,5, iif(CloseToWAvg<1.035,6, iif(CloseToWAvg<1.06,7, iif(CloseToWAvg<1.106,8,9))))))))) as G2,
iif(CloseToOpen<0.9523196,0, iif(CloseToOpen<0.9742948,1, iif(CloseToOpen<0.9866623,2, iif(CloseToOpen<0.9950334,3, iif(CloseToOpen<1.000579,4, iif(CloseToOpen<1.007083,5, iif(CloseToOpen<1.016453,6, iif(CloseToOpen<1.030835,7, iif(CloseToOpen<1.056931,8,9))))))))) as G3,
iif([Close]<3.01,0, iif([Close]<5.72,1, iif([Close]<9.07,2, iif([Close]<13.16,3, iif([Close]<17.82,4, iif([Close]<23.45,5, iif([Close]<30.23,6, iif([Close]<40.18,7, iif([Close]<56.64,8,9))))))))) as G4,
* from vDayEoddata2013Extended) x
group by G0, G1, G2, G3, G4
having avg(r1)>1.05
order by 6 desc, 1,2,3,4,5;

select count(*) as Cnt, 
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1, 
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5
from
(select 
iif(VolToWAvg<2.087, 0, iif(VolToWAvg<2.19, 1, iif(VolToWAvg<2.32, 2, iif(VolToWAvg<2.48, 3, iif(VolToWAvg<2.69, 4, iif(VolToWAvg<2.99, 5, iif(VolToWAvg<3.435, 6, iif(VolToWAvg<4.22, 7, iif(VolToWAvg<6.01, 8, 9))))))))) as G0,
iif(MaxPVolToWAvg<1.3,0, iif(MaxPVolToWAvg<1.39,1, iif(MaxPVolToWAvg<1.47,2, iif(MaxPVolToWAvg<1.55,3, iif(MaxPVolToWAvg<1.645,4, iif(MaxPVolToWAvg<1.76,5, iif(MaxPVolToWAvg<1.91,6, iif(MaxPVolToWAvg<2.14,7, iif(MaxPVolToWAvg<2.585,8,9))))))))) as G1,
iif(CloseToWAvg<0.915,0, iif(CloseToWAvg<0.95,1, iif(CloseToWAvg<0.974,2, iif(CloseToWAvg<0.99,3, iif(CloseToWAvg<1,4, iif(CloseToWAvg<1.017,5, iif(CloseToWAvg<1.035,6, iif(CloseToWAvg<1.06,7, iif(CloseToWAvg<1.106,8,9))))))))) as G2,
iif(CloseToOpen<0.9523196,0, iif(CloseToOpen<0.9742948,1, iif(CloseToOpen<0.9866623,2, iif(CloseToOpen<0.9950334,3, iif(CloseToOpen<1.000579,4, iif(CloseToOpen<1.007083,5, iif(CloseToOpen<1.016453,6, iif(CloseToOpen<1.030835,7, iif(CloseToOpen<1.056931,8,9))))))))) as G3,
iif([Close]<3.01,0, iif([Close]<5.72,1, iif([Close]<9.07,2, iif([Close]<13.16,3, iif([Close]<17.82,4, iif([Close]<23.45,5, iif([Close]<30.23,6, iif([Close]<40.18,7, iif([Close]<56.64,8,9))))))))) as G4,
* from vDayEoddata2013Extended) x
order by 1;

select * from
(select 
iif(VolToWAvg<2.087, 0, iif(VolToWAvg<2.19, 1, iif(VolToWAvg<2.32, 2, iif(VolToWAvg<2.48, 3, iif(VolToWAvg<2.69, 4, iif(VolToWAvg<2.99, 5, iif(VolToWAvg<3.435, 6, iif(VolToWAvg<4.22, 7, iif(VolToWAvg<6.01, 8, 9))))))))) as G0,
iif(MaxPVolToWAvg<1.3,0, iif(MaxPVolToWAvg<1.39,1, iif(MaxPVolToWAvg<1.47,2, iif(MaxPVolToWAvg<1.55,3, iif(MaxPVolToWAvg<1.645,4, iif(MaxPVolToWAvg<1.76,5, iif(MaxPVolToWAvg<1.91,6, iif(MaxPVolToWAvg<2.14,7, iif(MaxPVolToWAvg<2.585,8,9))))))))) as G1,
iif(CloseToWAvg<0.915,0, iif(CloseToWAvg<0.95,1, iif(CloseToWAvg<0.974,2, iif(CloseToWAvg<0.99,3, iif(CloseToWAvg<1,4, iif(CloseToWAvg<1.017,5, iif(CloseToWAvg<1.035,6, iif(CloseToWAvg<1.06,7, iif(CloseToWAvg<1.106,8,9))))))))) as G2,
iif(CloseToOpen<0.9523196,0, iif(CloseToOpen<0.9742948,1, iif(CloseToOpen<0.9866623,2, iif(CloseToOpen<0.9950334,3, iif(CloseToOpen<1.000579,4, iif(CloseToOpen<1.007083,5, iif(CloseToOpen<1.016453,6, iif(CloseToOpen<1.030835,7, iif(CloseToOpen<1.056931,8,9))))))))) as G3,
iif([Close]<3.01,0, iif([Close]<5.72,1, iif([Close]<9.07,2, iif([Close]<13.16,3, iif([Close]<17.82,4, iif([Close]<23.45,5, iif([Close]<30.23,6, iif([Close]<40.18,7, iif([Close]<56.64,8,9))))))))) as G4,
* from vDayEoddata2013Extended) x
where G0=4 and G1=8 and G2=0 and G3=1 and G4=0;


-- =============================================
select 1 Cnt, Open_N1/CL_N1 R1, Open_N1/CL_N2 R2, Open_N1/CL_N3 R3, Open_N1/CL_N4 R4, Open_N1/CL_N5 R5, 
Volume/AverVOL VolToWAvg, MaxPVol/AverVOL MaxPVolToWAvg, [Close]/ AverCl CloseToWAvg, [Close]/ [Open] CloseToOpen, a.*
from Temp_Query003 a
where [Close] >=1 and Volume > 300000  and Volume > 2* AverVOL and AverVOL > 50000-- all
-- where [Close] >=1 and Volume > 300000 and Volume > 5 * AverVOL and [MaxPVol]< 2* AverVOL and [Close] > 1.5 * AverCl and [Open]<[Close] -- 159 recs, open/CL_N1 average = 1.047, open/CL_N2 average = 1.082
--where [Close] >=1 and [Close]<5 and Volume > 300000 and Volume > 5 * AverVOL and [MaxPVol]< 2* AverVOL and [Close] > 1.5 * AverCl and [Open]<[Close] -- 86 recs, open/CL_N1 average = 1.080, open/CL_N2 average = 1.135, open/CL_N3 average = 1.157
-- where [Close] >=1 and [Close]<5 and Volume > 300000 and Volume > 3 * AverVOL and [MaxPVol]< 2* AverVOL and [Close] > 1.5 * AverCl and [Open]<[Close] and CL_N5 is not null -- 96 recs, open/CL_N1 average = 1.076, open/CL_N2 average = 1.132, open/CL_N3 average = 1.157
-- where [Close] >=1 and [Close]<5 and Volume > 300000 and Volume > 5 * AverVOL and [MaxPVol]< 2* AverVOL and [Close] < 0.7 * AverCl and [Open]>[Close] -- 134 recs, open/CL_N1 average = 1.036, open/CL_N2 average = 1.051, open/CL_N3 average = 1.058
-- where [Close] >=5 and Volume > 300000 and Volume > 5 * AverVOL and [MaxPVol]< 2* AverVOL and [Close] > 1.5 * AverCl and [Open]<[Close] -- 73 recs, open/CL_N1 average = 1.008
-- where [Close] >=5 and Volume > 300000 and Volume > 5 * AverVOL and [MaxPVol]< 2* AverVOL and [Close] > 1.2 * AverCl and [Open]<[Close] -- 700 recs, open/CL_N1 average = 0.9996

--=====================================================
--=====================================================
--=====================================================
--=====================================================
select * from vDayEoddata2013Extended
where WAvgVolatility>=5.3615 and WAvgCL>5.0 and [Close]>5.0
order by date, symbol;

SELECT G8, min(WAvgVolatility) MinValue, max(WAvgVolatility) MaxValue, count(*) Cnt,
cast(round(100.0*sum(iif([High]<[Open]+0.005,1,0))/count(*),2) as real) H0,
cast(round(100.0*sum(iif([Low]>[Open]-0.005,1,0))/count(*),2) as real) L0,
AVG(R1) as R1, ROUND(STDEV(R1)/AVG(R1)*100.0,1) as D1,
CAST(ROUND(SUM(iif([Open_N1]>[CL_N1],1.0,0.0))*100.0/SUM(K1),1) as real) as Sell_N1,
cast(round(SUM(100.0*iif([High_N1]<[Open_N1]+0.005,1.0,0.0)*K1)/SUM(K1),2) as real) H1,
cast(round(SUM(100.0*iif([Low_N1]>[Open_N1]-0.005,1.0,0.0)*K1)/SUM(K1),2) as real) L1,
AVG(R2) as R2, ROUND(STDEV(R2)/AVG(R2)*100.0,1) as D2,
CAST(ROUND(SUM(iif([Open_N2]>[CL_N2],1.0,0.0))*100.0/SUM(K2),1) as real) as Sell_N2,
cast(round(SUM(100.0*iif([High_N2]<[Open_N2]+0.005,1.0,0.0)*K2)/SUM(K2),2) as real) H2,
cast(round(SUM(100.0*iif([Low_N2]>[Open_N2]-0.005,1.0,0.0)*K2)/SUM(K2),2) as real) L2,
AVG(R3) as R3, ROUND(STDEV(R3)/AVG(R3)*100.0,1) as D3,
CAST(ROUND(SUM(iif([Open_N3]>[CL_N3],1.0,0.0))*100.0/SUM(K3),1) as real) as Sell_N3,
cast(round(SUM(100.0*iif([High_N3]<[Open_N3]+0.005,1.0,0.0)*K3)/SUM(K3),2) as real) H3,
cast(round(SUM(100.0*iif([Low_N3]>[Open_N3]-0.005,1.0,0.0)*K3)/SUM(K3),2) as real) L3,
AVG(R4) as R4, ROUND(STDEV(R4)/AVG(R4)*100.0,1) as D4,
CAST(ROUND(SUM(iif([Open_N4]>[CL_N4],1.0,0.0))*100.0/SUM(K4),1) as real) as Sell_N4,
cast(round(SUM(100.0*iif([High_N4]<[Open_N4]+0.005,1.0,0.0)*K4)/SUM(K4),2) as real) H4,
cast(round(SUM(100.0*iif([Low_N4]>[Open_N4]-0.005,1.0,0.0)*K4)/SUM(K4),2) as real) L4,
AVG(R5) as R5, ROUND(STDEV(R5)/AVG(R5)*100.0,1) as D5,
CAST(ROUND(SUM(iif([Open_N5]>[CL_N5],1.0,0.0))*100.0/SUM(K5),1) as real) as Sell_N5,
cast(round(SUM(100.0*iif([High_N5]<[Open_N5]+0.005,1.0,0.0)*K5)/SUM(K5),2) as real) H5,
cast(round(SUM(100.0*iif([Low_N5]>[Open_N5]-0.005,1.0,0.0)*K3)/SUM(K5),2) as real) L5
FROM (SELECT CAST(ROW_NUMBER() OVER(ORDER BY WAvgVolatility ASC) /(SELECT (count(*)+8)/8 FROM vBigVolume_Eoddata) as int) AS G8,
* from vBigVolume_Eoddata) x GROUP BY G8 ORDER BY 1;


select * from vBigVolume_Eoddata
where WAvgVolatility>=10.215 and WAvgCL>5.0 and [Close]>5.0
order by date, symbol
