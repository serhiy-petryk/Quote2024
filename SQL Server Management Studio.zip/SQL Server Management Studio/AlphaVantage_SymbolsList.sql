SELECT symbol, sum(volume*[close])/1000000 TradingValue, count(*) recs, min(Date) MinDate , max(Date) MaxDate 
FROM DayEoddata
where volume>=300000
and symbol not like '%.%' and symbol not like '%-%'
group by symbol
having sum(volume*[close])/1000000>=10.0 and count(*)>=10
order by 2 desc

SELECT symbol, sum(volume*[close])/1000000 TradingValue, count(*) recs, min(Date) MinDate , max(Date) MaxDate 
FROM DayEoddata
where volume>=300000
and symbol not like '%.%' and symbol not like '%-%'
group by symbol
having sum(volume*[close])/1000000>=10.0 and count(*)>=10 and min(date)<'2022-03-01'
order by 2 desc

SELECT symbol, sum(volume*[close])/1000000 TradingValue, count(*) recs, min(Date) MinDate , max(Date) MaxDate 
FROM DayEoddata
where volume>=300000
and symbol not like '%.%' and symbol not like '%-%'
group by symbol
having sum(volume*[close])/1000000>=10.0 and count(*)>=10 and min(date)<'2022-01-10'
order by 2 desc

SELECT  symbol, sum(volume*[close])/1000000 TradingValue, count(*) recs, min(Date) MinDate , max(Date) MaxDate 
FROM DayEoddata
where volume>=300000
and (symbol like '%.%' or symbol like '%-%')
group by symbol
having sum(volume*[close])/1000000>=10.0 and count(*)>=10 and min(date)<'2022-01-10'
order by 2 desc

-- temp investigation

SELECT y.AlphaVantageSymbol, * 
from 
(SELECT symbol, exchange, sum(volume*[close])/1000000 TradingValue, count(*) recs, min(Date) MinDate , max(Date) MaxDate 
FROM DayEoddata
where volume>=300000
and (symbol like '%.%' or symbol like '%-%')
group by symbol, exchange
having sum(volume*[close])/1000000>=10.0 and count(*)>=10 and max(date)>'2022-02-01') x
inner join SymbolsEoddata y on x.Symbol=y.Symbol and x.Exchange=y.Exchange
-- where y.symbol not like '%-[A-Z]' and y.symbol not like '%.[A-B]' and y.symbol not like '%.[W]'
--where y.symbol like '%.[A-Z]' and y.symbol not like '%.[W]'
order by 1 desc

/*
BAC-B -> BAC-P-B (/P -> -P-)
ALLG/W -> ALLG-WS, CANO/W -> CANO-WS (/W -> -WS)
BF.B -> BF-B
BRK.B -> BRK-B
TGR.U -> TGR-U
CEQP/P -> CEQP-P
*/

-- Live symbol list to download (symbol like '%.%' or symbol like '%-%')
SELECT y.AlphaVantageSymbol, x.TradingValue, x.recs, x.MinDate, x.MaxDate
from 
(SELECT symbol, exchange, sum(volume*[close])/1000000 TradingValue, count(*) recs, min(Date) MinDate , max(Date) MaxDate 
FROM DayEoddata
where volume>=300000
and (symbol like '%.%' or symbol like '%-%')
group by symbol, exchange
having sum(volume*[close])/1000000>=10.0 and count(*)>=10 and min(date)>='2022-01-10' and min(date)<'2022-04-01'
) x
inner join SymbolsEoddata y on x.Symbol=y.Symbol and x.Exchange=y.Exchange
order by 1

SELECT y.AlphaVantageSymbol, x.TradingValue, x.recs, x.MinDate, x.MaxDate
from 
(SELECT symbol, exchange, sum(volume*[close])/1000000 TradingValue, count(*) recs, min(Date) MinDate , max(Date) MaxDate 
FROM DayEoddata
where volume>=300000
and (symbol like '%.%' or symbol like '%-%')
group by symbol, exchange
having sum(volume*[close])/1000000>=10.0 and count(*)>=10 and min(date)>='2022-01-10' and min(date)<'2022-04-01'
) x
inner join SymbolsEoddata y on x.Symbol=y.Symbol and x.Exchange=y.Exchange
order by 1

-- Symbol list
SELECT y.AlphaVantageSymbol, x.TradingValue, x.recs, x.MinDate, x.MaxDate
from 
(SELECT symbol, sum(volume*[close])/1000000 TradingValue, count(*) recs, min(Date) MinDate , max(Date) MaxDate 
FROM DayEoddata
where volume>=300000
-- and not symbol like '%.%' and not symbol like '%-%'
group by symbol
having sum(volume*[close])/1000000>=10.0 and count(*)>=10 -- and min(date)>='2022-02-01' -- and min(date)<'2022-06-01'
) x
inner join vSymbolsLive y on x.Symbol=y.Symbol
order by 2 desc

-- Mising symbols
SELECT y.AlphaVantageSymbol, x.TradingValue, x.recs, x.MinDate, x.MaxDate
from 
(SELECT symbol, sum(volume*[close])/1000000 TradingValue, count(*) recs, min(Date) MinDate , max(Date) MaxDate 
FROM DayEoddata
where volume>=300000
-- and not symbol like '%.%' and not symbol like '%-%'
group by symbol
having sum(volume*[close])/1000000>=10.0 and count(*)>=10 -- and min(date)>='2022-02-01' -- and min(date)<'2022-06-01'
) x
inner join vSymbolsLive y on x.Symbol=y.Symbol
left join (SELECT a.symbol from FileLogMinuteAlphaVantage a
inner join SymbolsEoddata b on a.Symbol=b.AlphaVantageSymbol
group by a.symbol ) z on y.AlphaVantageSymbol=z.Symbol
WHERE z.Symbol is null
order by 1

select * from DayEoddata where symbol='BOND' order by date