use dbQuote2023

-- Compare data from all sources
select symbol, date, count(*), min(CountFull), max(CountFull), min(Volume), max(Volume)
from FileLogMinuteAlphaVantage
-- where [file] like '%202303%'
-- and count>100 and mintime>'09:35:00' and Position='Last'
group by symbol, date
having min(minTime)<>max(minTime) or min(CountFull)<>max(CountFull) or min(Volume)<>max(Volume)

-- Folder summary list
select substring([file],1, Charindex('\',[file])-1) folder, count(*), min(date), max(date) from FileLogMinuteAlphaVantage
group by substring([file],1, Charindex('\',[file])-1)
order by 3 desc, 4

-- ========  ZIP LOG  ========
-- difference between zip and csv
select *
from FileLogMinuteAlphaVantage a
inner join ZipLogMinuteAlphaVantage b on a.Symbol=b.Symbol and a.Date=b.Date
where a.CountFull<>b.Lines

-- Missing items in ZipLog (have to split data and save it to zip => update zip log)
select a.*
from FileLogMinuteAlphaVantage a
left join ZipLogMinuteAlphaVantage b on a.Symbol=b.Symbol and a.Date=b.Date
where b.Symbol is null

-- ===== OTHER SQLs =====
select * from FileLogMinuteAlphaVantage where [file] like '%202303%'
and count>100 and mintime>'09:35:00' and Position='Last'
order by MinTime desc;

select * from FileLogMinuteAlphaVantage where [file] like '%20230318%'
and count>100 and mintime>'09:35:00' and Position='Last'
order by MinTime desc;

-- Compare data from a few sources
select symbol, date, count(*), min(CountFull), max(CountFull) from FileLogMinuteAlphaVantage where [file] like '%202303%'
-- and count>100 and mintime>'09:35:00' and Position='Last'
group by symbol, date
having count(*)<>1 and (min(minTime)<>max(minTime) or min(CountFull)<>max(CountFull))


