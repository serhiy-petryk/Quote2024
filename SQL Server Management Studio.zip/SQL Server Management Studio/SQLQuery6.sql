;with data as
	(
		select ([Open]-[Close])/[Open]*100 PrevOpenRate, ([Open]-[Close])/([Open]+[Close])*200 PrevCOProfit,
		([High]-[Low])/(High+Low)*200 PrevHLProfit,
		a.* from dbQ2024..DayPolygon a 
		inner join dbQ2024..SymbolsPolygon b on a.Symbol=b.Symbol and a.Date between b.Date and isnull(b.[To],'2099-12-31')
		where a.IsTest is null and year(a.Date)>=2010 and
			a.Volume*a.[Close]>=50000000 and a.TradeCount>=10000 --and a.Low>=5.0
--			and FORMAT(a.Date, 'yyyy-MM')='2022-07'
	),
	data2 as (
		select c.Profit, (c.[Open]-c.[Close]) ProfitValue,
		c.[Open] NextOpen, a.*
		from data a
		inner join dbQ2024..TradingDays b on a.Date=b.Date
		inner join (select ([Open]-[Close])/[Open]*100 Profit, * from dbQ2024..DayPolygon where [Open]>=5.0)
		c on a.Symbol=c.Symbol and c.Date=b.Next1
		-- where 
		-- c.[open] between a.Low*1.02 and a.High*0.98-- and
		--PrevHLProfit between 10 and 4000
	),
	data3 as (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date ORDER BY PrevHLProfit DESC), *
	   FROM data2
	)

	-- select * from data3 where PrevHLProfit>15

	/*select RIGHT(Period,2), avg(Profit) Profit, min(Profit) MinProfit, max(Profit) MaxProfit,
	sum(Recs) Recs, avg(PrevHLProfit) PrevHLProfit,
	ROUND(sum(ProfitValue),0) ProfitValue
	FROM
	(select FORMAT(Date,'yyyy-MM-dd') Period, avg(Profit) Profit, count(*) Recs, avg(PrevHLProfit) PrevHLProfit, ROUND(sum(ProfitValue),0) ProfitValue from data3
    WHERE RN<=5 -- and PrevHLProfit>15 -- and [Open]<[Close]
	group by FORMAT(Date,'yyyy-MM-dd')) x 
	group by RIGHT(PERIOD,2) order by 1*/

	select FORMAT(Date,'yyyy-MM') Period, avg(Profit) Profit, count(*) Recs, avg(PrevHLProfit) PrevHLProfit, ROUND(sum(ProfitValue),0) ProfitValue from data3
    WHERE RN<=5 and PrevHLProfit>10 -- and [Open]<[Close]
	group by FORMAT(Date,'yyyy-MM')
	having avg(Profit)<-1.0 

	/*select RIGHT(Period,2), avg(Profit) Profit, min(Profit) MinProfit, max(Profit) MaxProfit,
	sum(Recs) Recs, avg(PrevHLProfit) PrevHLProfit,
	ROUND(sum(ProfitValue),0) ProfitValue
	FROM
	(select FORMAT(Date,'yyyy-MM') Period, avg(Profit) Profit, count(*) Recs, avg(PrevHLProfit) PrevHLProfit, ROUND(sum(ProfitValue),0) ProfitValue from data3
    WHERE RN<=5 and PrevHLProfit between 10 and 40-- >15 -- and [Open]<[Close]
	group by FORMAT(Date,'yyyy-MM')) x 
	group by RIGHT(PERIOD,2) order by 1*/
