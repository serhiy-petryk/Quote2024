select distinct symbol from 
(select symbol from DayEoddata
union select symbol from DayYahoo
union select symbol from DayEoddata2013
union select symbol from DayYahoo2013
) a
where symbol not like '%-%' and symbol not like '%.%' 
order by 1

-- select * from Splits order by date desc

