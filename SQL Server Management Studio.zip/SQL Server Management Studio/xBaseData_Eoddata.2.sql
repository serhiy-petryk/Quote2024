-- 22 secs: Insert Eoddata
-- 26 secs: Update Indexes
-- 1 min 22 secs: Update prev

-- 1 min 13 secs/1:24: INSERT Eoddata+prev
-- 2 secs: DELETE splits
-- 22 secs: UPDATE n1
-- 1 min 42 secs: Update next (many queries)
-- 1 min 30 secs: Update next (one query)
-- 11 secs: Update splits for next days

USE [dbQuote2022];
TRUNCATE TABLE DayEoddataExtended;

INSERT INTO DayEoddataExtended (Exchange, Symbol, Date, [Open], High, Low, CL, VLM,
DJI_ToAvg, DJI_ToWAvg, GSPC_ToAvg, GSPC_ToWAvg, AvgCL, WAvgCL, AvgVLM, WAvgVLM, AvgVolatility, WAvgVolatility,
MaxPVLM, MinPVLM, MaxPHigh, MinPLow, Open_P1, High_P1, Low_P1, CL_P1, VLM_P1)
-- NextDay1, NextDay2, NextDay3, NextDay4, NextDay5)
select a.Exchange, a.Symbol, a.Date, a.[Open], a.High, a.Low, a.[Close], a.Volume,
d.DJI/d.DJI_Avg DJI_ToAvg, d.DJI/d.DJI_WAvg DJI_ToWAvg, d.GSPC/d.GSPC_Avg GSPC_ToAvg, d.GSPC/d.GSPC_WAvg GSPC_ToWAvg,
(p1.[Close]+p2.[Close]+p3.[Close]+p4.[Close]+p5.[Close]+p6.[Close]+p7.[Close])/7.0 as AvgCL,
(p1.[Close]*7.0+p2.[Close]*6.0+p3.[Close]*5.0+p4.[Close]*4.0+p5.[Close]*3.0+p6.[Close]*2.0+p7.[Close])/28.0 as WAvgCL,
(p1.[Volume]+p2.[Volume]+p3.[Volume]+p4.[Volume]+p5.[Volume]+p6.[Volume]+p7.[Volume])/7.0 as AvgVLM,
(p1.[Volume]*7.0+p2.[Volume]*6.0+p3.[Volume]*5.0+p4.[Volume]*4.0+p5.[Volume]*3.0+p6.[Volume]*2.0+p7.[Volume])/28.0 as WAvgVLM,
((p1.High-p1.Low)/p1.[Close]+(p2.High-p2.Low)/p2.[Close]+(p3.High-p3.Low)/p3.[Close]+(p4.High-p4.Low)/p4.[Close]+
(p5.High-p5.Low)/p5.[Close]+(p6.High-p6.Low)/p6.[Close]+(p7.High-p7.Low)/p7.[Close])/7.0*100.0 as AvgVolatility,
((p1.High-p1.Low)/p1.[Close]*7.0+(p2.High-p2.Low)/p2.[Close]*6.0+(p3.High-p3.Low)/p3.[Close]*5.0+(p4.High-p4.Low)/p4.[Close]*4.0+
(p5.High-p5.Low)/p5.[Close]*3.0+(p6.High-p6.Low)/p6.[Close]*2.0+(p7.High-p7.Low)/p7.[Close])/28.0*100.0 as WAvgVolatility,
(SELECT Max(v) FROM (VALUES (p1.Volume),(p2.Volume),(p3.Volume),(p4.Volume),(p5.Volume),(p6.Volume),(p7.Volume)) AS value(v)) as [MaxPVLM],
(SELECT Min(v) FROM (VALUES (p1.Volume),(p2.Volume),(p3.Volume),(p4.Volume),(p5.Volume),(p6.Volume),(p7.Volume)) AS value(v)) as [MinPVLM],
(SELECT Max(v) FROM (VALUES (p1.High),(p2.High),(p3.High),(p4.High),(p5.High),(p6.High),(p7.High)) AS value(v)) as [MaxPHigh],
(SELECT Min(v) FROM (VALUES (p1.Low),(p2.Low),(p3.Low),(p4.Low),(p5.Low),(p6.Low),(p7.Low)) AS value(v)) as [MinPLow],
p1.[Open] Open_P1, p1.High High_P1, p1.Low Low_P1, p1.[Close] CL_P1, p1.Volume VLM_P1
-- d.Next1, d.Next2, d.Next3, d.Next4, d.Next5 
from DayEoddata a
inner join TradingDays d on d.Date=a.Date
inner join DayEoddata p1 on p1.Symbol=a.Symbol and p1.Date=d.Prev1
inner join DayEoddata p2 on p2.Symbol=a.Symbol and p2.Date=d.Prev2
inner join DayEoddata p3 on p3.Symbol=a.Symbol and p3.Date=d.Prev3
inner join DayEoddata p4 on p4.Symbol=a.Symbol and p4.Date=d.Prev4
inner join DayEoddata p5 on p5.Symbol=a.Symbol and p5.Date=d.Prev5
inner join DayEoddata p6 on p6.Symbol=a.Symbol and p6.Date=d.Prev6
inner join DayEoddata p7 on p7.Symbol=a.Symbol and p7.Date=d.Prev7

/*left join Splits s on s.Symbol=a.Symbol and s.Date=a.Date
left join Splits s1 on s1.Symbol=a.Symbol and s1.Date=d.Prev1
left join Splits s2 on s2.Symbol=a.Symbol and s2.Date=d.Prev2
left join Splits s3 on s3.Symbol=a.Symbol and s3.Date=d.Prev3
left join Splits s4 on s4.Symbol=a.Symbol and s4.Date=d.Prev4
left join Splits s5 on s5.Symbol=a.Symbol and s5.Date=d.Prev5
left join Splits s6 on s6.Symbol=a.Symbol and s6.Date=d.Prev6
left join Splits s7 on s7.Symbol=a.Symbol and s7.Date=d.Prev7
left join Splits sn1 on sn1.Symbol=a.Symbol and sn1.Date=d.Next1
left join Splits sn2 on sn2.Symbol=a.Symbol and sn2.Date=d.Next2
left join Splits sn3 on sn3.Symbol=a.Symbol and sn3.Date=d.Next3
left join Splits sn4 on sn4.Symbol=a.Symbol and sn4.Date=d.Next4
left join Splits sn5 on sn5.Symbol=a.Symbol and sn5.Date=d.Next5*/

-- inner join DayEoddata n1 on n1.Symbol=a.Symbol and n1.Date=d.Next1
/*left join DayEoddata n2 on n2.Symbol=a.Symbol and n2.Date=d.Next2
left join DayEoddata n3 on n3.Symbol=a.Symbol and n3.Date=d.Next3
left join DayEoddata n4 on n4.Symbol=a.Symbol and n4.Date=d.Next4
left join DayEoddata n5 on n5.Symbol=a.Symbol and n5.Date=d.Next5*/
WHERE a.Volume>0 and p1.Volume>0 and p2.Volume>0 and p3.Volume>0 and p4.Volume>0 and p5.Volume>0 and p6.Volume>0 and p7.Volume>0
-- and s.Symbol is null and s1.Symbol is null and s2.Symbol is null and s3.Symbol is null and s4.Symbol is null and s5.Symbol is null and s6.Symbol is null and s7.Symbol is null;

DELETE a FROM DayEoddataExtended a inner join Splits s on s.Symbol=a.Symbol and s.Date=a.Date;
DELETE a FROM DayEoddataExtended a inner join TradingDays d on d.Date=a.Date
inner join Splits s1 on s1.Symbol=a.Symbol and s1.Date=d.Prev1;
DELETE a FROM DayEoddataExtended a inner join TradingDays d on d.Date=a.Date
inner join Splits s1 on s1.Symbol=a.Symbol and s1.Date=d.Prev2;
DELETE a FROM DayEoddataExtended a inner join TradingDays d on d.Date=a.Date
inner join Splits s1 on s1.Symbol=a.Symbol and s1.Date=d.Prev3;
DELETE a FROM DayEoddataExtended a inner join TradingDays d on d.Date=a.Date
inner join Splits s1 on s1.Symbol=a.Symbol and s1.Date=d.Prev4;
DELETE a FROM DayEoddataExtended a inner join TradingDays d on d.Date=a.Date
inner join Splits s1 on s1.Symbol=a.Symbol and s1.Date=d.Prev5;
DELETE a FROM DayEoddataExtended a inner join TradingDays d on d.Date=a.Date
inner join Splits s1 on s1.Symbol=a.Symbol and s1.Date=d.Prev6;
DELETE a FROM DayEoddataExtended a inner join TradingDays d on d.Date=a.Date
inner join Splits s1 on s1.Symbol=a.Symbol and s1.Date=d.Prev7;

/*UPDATE a SET Open_N1=n1.[Open], High_N1=n1.High, Low_N1=n1.Low, CL_N1=n1.[Close], VLM_N1=n1.Volume
FROM DayEoddataExtended a
inner join DayEoddata n1 on n1.Symbol=a.Symbol and n1.Date=a.NextDay1;

UPDATE a SET Open_N2=n2.[Open], High_N2=n2.High, Low_N2=n2.Low, CL_N2=n2.[Close], VLM_N2=n2.Volume
FROM DayEoddataExtended a
inner join DayEoddata n2 on n2.Symbol=a.Symbol and n2.Date=a.NextDay2;

UPDATE a SET Open_N1=n1.[Open], High_N1=n1.High, Low_N1=n1.Low, CL_N1=n1.[Close], VLM_N1=n1.Volume
FROM DayEoddataExtended a inner join TradingDays d on d.Date=a.Date
inner join DayEoddata n1 on n1.Symbol=a.Symbol and n1.Date=d.Next1;

UPDATE a SET Open_N2=n2.[Open], High_N2=n2.High, Low_N2=n2.Low, CL_N2=n2.[Close], VLM_N2=n2.Volume
FROM DayEoddataExtended a inner join TradingDays d on d.Date=a.Date
inner join DayEoddata n2 on n2.Symbol=a.Symbol and n2.Date=d.Next2;

UPDATE a SET Open_N3=n3.[Open], High_N3=n3.High, Low_N3=n3.Low, CL_N3=n3.[Close], VLM_N3=n3.Volume
FROM DayEoddataExtended a inner join TradingDays d on d.Date=a.Date
inner join DayEoddata n3 on n3.Symbol=a.Symbol and n3.Date=d.Next3;

UPDATE a SET Open_N4=n4.[Open], High_N4=n4.High, Low_N4=n4.Low, CL_N4=n4.[Close], VLM_N4=n4.Volume
FROM DayEoddataExtended a inner join TradingDays d on d.Date=a.Date
inner join DayEoddata n4 on n4.Symbol=a.Symbol and n4.Date=d.Next4;

UPDATE a SET Open_N5=n5.[Open], High_N5=n5.High, Low_N5=n5.Low, CL_N5=n5.[Close], VLM_N5=n5.Volume
FROM DayEoddataExtended a inner join TradingDays d on d.Date=a.Date
inner join DayEoddata n5 on n5.Symbol=a.Symbol and n5.Date=d.Next5;*/



UPDATE a SET Open_N1=n1.[Open], High_N1=n1.High, Low_N1=n1.Low, CL_N1=n1.[Close], VLM_N1=n1.Volume,
Open_N2=n2.[Open], High_N2=n2.High, Low_N2=n2.Low, CL_N2=n2.[Close], VLM_N2=n2.Volume,
Open_N3=n3.[Open], High_N3=n3.High, Low_N3=n3.Low, CL_N3=n3.[Close], VLM_N3=n3.Volume,
Open_N4=n4.[Open], High_N4=n4.High, Low_N4=n4.Low, CL_N4=n4.[Close], VLM_N4=n4.Volume,
Open_N5=n5.[Open], High_N5=n5.High, Low_N5=n5.Low, CL_N5=n5.[Close], VLM_N5=n5.Volume
FROM DayEoddataExtended a inner join TradingDays d on d.Date=a.Date
inner join DayEoddata n1 on n1.Symbol=a.Symbol and n1.Date=d.Next1
left join DayEoddata n2 on n2.Symbol=a.Symbol and n2.Date=d.Next2
left join DayEoddata n3 on n3.Symbol=a.Symbol and n3.Date=d.Next3
left join DayEoddata n4 on n4.Symbol=a.Symbol and n4.Date=d.Next4
left join DayEoddata n5 on n5.Symbol=a.Symbol and n5.Date=d.Next5


UPDATE a SET Split_N1=s1.Split, Split_N2=s2.Split, Split_N3=s3.Split, Split_N4=s4.Split, Split_N5=s5.Split
FROM DayEoddataExtended a
inner join TradingDays d on d.Date=a.Date
left join Splits s1 on s1.Symbol=a.Symbol and s1.Date=d.Next1
left join Splits s2 on s2.Symbol=a.Symbol and s2.Date=d.Next2
left join Splits s3 on s3.Symbol=a.Symbol and s3.Date=d.Next3
left join Splits s4 on s4.Symbol=a.Symbol and s4.Date=d.Next4
left join Splits s5 on s5.Symbol=a.Symbol and s5.Date=d.Next5

