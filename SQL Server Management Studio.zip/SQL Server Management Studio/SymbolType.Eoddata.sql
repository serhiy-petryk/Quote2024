update SymbolsEoddata SET SaType=null where SaType is not null;

update a SET SaType='Stock' 
from SymbolsEoddata a
inner join Bfr_SymbolsStockanalysisStockExchanges b on a.Symbol=b.Symbol
WHERE a.Exchange<>'OTCBB';

update a SET SaType='Etf' 
from SymbolsEoddata a
inner join Bfr_SymbolsStockanalysisEtfExchanges b on a.Symbol=b.Symbol
WHERE a.Exchange<>'OTCBB';

update SymbolsEoddata SET SaType='%' WHERE SaType is null and exchange<>'OTCBB'
and len(symbol)<5 and symbol not like '%.%' and name like '%[%]';

update SymbolsEoddata SET SaType='Fund' WHERE SaType is null and exchange<>'OTCBB'
and len(symbol)<5 and symbol not like '%.%' and name like '%Fund' COLLATE Latin1_General_CS_AS;

update SymbolsEoddata SET SaType='PF' WHERE SaType is null and exchange<>'OTCBB'
and (symbol like '%-%' or symbol like '%.%') and name like '%\[%/P%\]%' ESCAPE '\' COLLATE Latin1_General_CS_AS;

update SymbolsEoddata SET SaType='ETF' where SaType is null and exchange<>'OTCBB'
and(name like '% ETF %' COLLATE Latin1_General_CS_AS or name like '% ETF' COLLATE Latin1_General_CS_AS or name like 'ETF %' COLLATE Latin1_General_CS_AS);

update SymbolsEoddata SET SaType='ETN' where SaType is null and exchange<>'OTCBB'
and(name like '% ETN %' COLLATE Latin1_General_CS_AS or name like '% ETN' COLLATE Latin1_General_CS_AS or name like 'ETN %' COLLATE Latin1_General_CS_AS);

-- update SymbolsEoddata SET SaType='Fund' where SaType is null and exchange<>'OTCBB'
-- and (name like '% Fund Inc' COLLATE Latin1_General_CS_AS or name like '% Fund Ltd' COLLATE Latin1_General_CS_AS or name like '% Fund I%' COLLATE Latin1_General_CS_AS);

update SymbolsEoddata SET SaType='Fund' where SaType is null and exchange<>'OTCBB'
and (name like '% Fund %' COLLATE Latin1_General_CS_AS or name like '% Fund' COLLATE Latin1_General_CS_AS);

update SymbolsEoddata SET SaType='Trust' where SaType is null and exchange<>'OTCBB'
and (name like '% Trust %' COLLATE Latin1_General_CS_AS or name like '% Trust' COLLATE Latin1_General_CS_AS);

update SymbolsEoddata SET SaType='Notes' where SaType is null and exchange<>'OTCBB'
and (name like '% Notes Due %' COLLATE Latin1_General_CS_AS or name like '% Notes Due' COLLATE Latin1_General_CS_AS or name like '% Notes' COLLATE Latin1_General_CS_AS);

select a.exchange, a.SaType, count(*), min(a.symbol), max(a.symbol) from 
SymbolsEoddata a
inner join (select distinct exchange, symbol
from DayEoddataExtended a
where CL>=1.0 and VLM>=1000000 and WAvgVLM>=1000000 and MinPVLM>=300000
and CL*VLM>10000000 and WAvgCL*WAvgVLM>10000000) b on a.Exchange=b.Exchange and a.Symbol=b.Symbol
--where (len(a.symbol)=5 and a.exchange='NASDAQ') or (a.symbol like '%.%' and a.exchange in ('AMEX','NYSE'))
group by a.exchange, a.SaType
order by 1,2


select count(*) from Bfr_SymbolsStockanalysisStockExchanges;
select count(*) from Bfr_SymbolsStockanalysisEtfExchanges;
/*(6225 row(s) affected)

(2990 row(s) affected)*/


-- ==================================
update SymbolsEoddata SET [Type]=null where [Type] is not null;

update SymbolsEoddata SET [Type]='Test' where symbol in ('NTEST.I');
update SymbolsEoddata SET [Type]='Units' where symbol like '%.U' and [Type] is null;
update SymbolsEoddata SET [Type]='WT' where symbol like '%.W' and [Type] is null;
update SymbolsEoddata SET [Type]='Units' where symbol like '%U' and exchange in('NASDAQ','OTCBB') and len(symbol)=5 and [Type] is null;
update SymbolsEoddata SET [Type]='WT' where symbol like '%W' and exchange in('NASDAQ','OTCBB') and len(symbol)=5 and [Type] is null;

update SymbolsEoddata SET [Type]='WT' where symbol like '%.T' and exchange in('NYSE','AMEX')
and (name like '%/W]' COLLATE Latin1_General_CS_AS or name like '% WT %' COLLATE Latin1_General_CS_AS) and [Type] is null;

update SymbolsEoddata SET [Type]='WT' where (symbol like '%.V' or symbol like '%.X' or symbol like '%.Y' or symbol like '%.Z')
and exchange in('NYSE','AMEX') and (name like '%.W]' COLLATE Latin1_General_CS_AS or name like '%/W]'
COLLATE Latin1_General_CS_AS or name like '% WT %' COLLATE Latin1_General_CS_AS) and [Type] is null;

update SymbolsEoddata SET [Type]='Units' where symbol like '%.S' and exchange in('NYSE','AMEX')
and name like '%.U]' COLLATE Latin1_General_CS_AS and [Type] is null;

update SymbolsEoddata SET [Type]='ETF' where (name like '% ETF %' COLLATE Latin1_General_CS_AS or name like '% ETF' COLLATE Latin1_General_CS_AS or name like 'ETF %' COLLATE Latin1_General_CS_AS) and [Type] is null
update SymbolsEoddata SET [Type]='ETFS' where (name like '% ETFS %' COLLATE Latin1_General_CS_AS or name like '% ETFS' COLLATE Latin1_General_CS_AS or name like 'ETFS %' COLLATE Latin1_General_CS_AS) and [Type] is null
update SymbolsEoddata SET [Type]='ETN' where (name like '% ETN %' COLLATE Latin1_General_CS_AS or name like '% ETN' COLLATE Latin1_General_CS_AS or name like 'ETN %' COLLATE Latin1_General_CS_AS) and [Type] is null
update SymbolsEoddata SET [Type]='SPDR' where (name like '% SPDR %' COLLATE Latin1_General_CS_AS or name like '% SPDR' COLLATE Latin1_General_CS_AS or name like 'SPDR %' COLLATE Latin1_General_CS_AS) and [Type] is null


select * from SymbolsEoddata where symbol like '%.U%' and [Type] is null;
select * from SymbolsEoddata where name like '% Units%' and [Type] is null;
select * from SymbolsEoddata where symbol like '%FTE%' and [Type] is null;

select * from SymbolsEoddata where symbol like '%.W%' and [Type] is null;

select * from SymbolsEoddata where name like '%WT%' and [Type] is null;

select * from SymbolsEoddata where symbol like '%U' and exchange<>'NASDAQ' and len(symbol)=5 and [Type] is null;


select * from SymbolsEoddata where name like 'Adial Pharmaceuticals%'

select exchange, type, count(*)
from SymbolsEoddata
-- where [Type] is not null
group by Exchange, type
order by 1, 2

select * from SymbolsEoddata where exchange='AMEX' and type is null


select * from SymbolsEoddata where symbol like '%-%' and [Type] is null;
select * from SymbolsEoddata where symbol like '%.%' and [Type] is null;

select * from SymbolsEoddata where symbol like '%.P' and [Type] is null;

select * from SymbolsEoddata where len(symbol)=5 and exchange='NASDAQ' and [Type] is null;


select a.exchange, a.type, count(*), min(a.symbol), max(a.symbol) from 
SymbolsEoddata a
inner join (select distinct exchange, symbol
from DayEoddataExtended a
where CL>=1.0 and VLM>=1000000 and WAvgVLM>=1000000 and MinPVLM>=300000
and CL*VLM>10000000 and WAvgCL*WAvgVLM>10000000) b on a.Exchange=b.Exchange and a.Symbol=b.Symbol
--where (len(a.symbol)=5 and a.exchange='NASDAQ') or (a.symbol like '%.%' and a.exchange in ('AMEX','NYSE'))
group by a.exchange, a.[type]
order by 1,2

select a.exchange, a.type, count(*), min(a.symbol), max(a.symbol) from 
SymbolsEoddata a
inner join (select distinct exchange, symbol
from DayEoddataExtended a
where CL>=1.0 and VLM>=1000000 and WAvgVLM>=1000000 and MinPVLM>=300000
and CL*VLM>10000000 and WAvgCL*WAvgVLM>10000000) b on a.Exchange=b.Exchange and a.Symbol=b.Symbol
where (len(a.symbol)=5 and a.exchange='NASDAQ') or (a.symbol like '%.%' and a.exchange in ('AMEX','NYSE'))
group by a.exchange, a.[type]
order by 1,2

select * from SymbolsEoddata where symbol in ('BNO', 'YINN')






