-- ===========  Name correction ================
SELECT *
FROM (select * from SymbolsPolygon where type is null) a
inner join (select * from SymbolsPolygon where type is not null) b on a.Symbol=b.Symbol and DATEADD(day,2,a.[To])=b.Date

select Type, count(*) Recs from SymbolsPolygon group by type order by 1


select * from SymbolsPolygon where name=symbol
-- 338 recs
UPDATE a SET Name=b.Name
-- SELECT b.name, b.cik, *
FROM (select * from SymbolsPolygon where name=symbol) a
inner join (select * from SymbolsPolygon where name<>symbol) b on a.Symbol=b.Symbol
and DATEADD(day,1,a.[To])=b.Date

UPDATE a SET Name=b.Name
--SELECT b.name, b.cik, *
FROM (select * from SymbolsPolygon where name=symbol) a
inner join (select * from SymbolsPolygon where name<>symbol) b on a.Symbol=b.Symbol
and DATEADD(day,-1,a.[Date])=b.[To]


SELECT b.name, b.cik, *
FROM (select * from SymbolsPolygon where name=symbol) a
inner join (select * from SymbolsPolygon where name<>symbol) b on a.Symbol=b.Symbol
 and (a.CIK is null or b.CIK is null) and DATEADD(day,1,a.[To])=b.Date


UPDATE a SET Name=b.Name
-- SELECT b.name, b.cik, *
FROM (select * from SymbolsPolygon where name=symbol) a
inner join (select * from SymbolsPolygon where name<>symbol and ((symbol='PYC.CL' and date='2014-06-12') or symbol='IUSV' and date='2015-01-30'))
b on a.Symbol=b.Symbol and a.[To]<b.Date

-- ===============================
-- ===============================
-- ===============================

select * from SymbolsPolygon where symbol='ORLY'
order by date desc

select * from SymbolsPolygon where symbol='AAL'
select * from SymbolsPolygon where symbol='FCFS' order by date desc


select * from TradingDays

select * from Temp_SymbolsPolygon

select datediff(day, a.Date, a.Next1), * from TradingDays a
order by 1 desc

select *
from SymbolsPolygon a
inner join SymbolsPolygon b on a.Symbol=b.Symbol and b.Date between a.Date and a.[To] and a.Date<>b.Date

select * from SymbolsPolygon where symbol='SPY'

select a.Symbol, a.Date, b.Date, b.[To]
select a.Symbol, count(*), min(a.Date), max(a.Date)
from SymbolsPolygon a
inner join SymbolsPolygon b on a.Symbol=b.Symbol and DATEADD(day,-1, a.[Date])=b.[To]
group by a.Symbol order by 2 desc

select b.Type, count(*), min(a.Symbol), max(a.Symbol), min(a.Date), max(a.Date) from 
(select * from SymbolsPolygon where Type='INDEX') a
inner join (select * from SymbolsPolygon where Type<>'INDEX') b on a.Symbol=b.Symbol and a.Exchange=b.Exchange
group by b.Type

select * from SymbolsPolygon where type='index' --3411
select * from SymbolsPolygon where type='index' and name like '% ETF' --1318
select * from SymbolsPolygon where type='index' and name like '% ETN' --1

select * from SymbolsPolygon where type='index' and name not like '% ETF' and name like '% ETF %' --351

select * from SymbolsPolygon where type='index' and name not like '% ETF' and name not like '% ETF %' and name like '%ETF%' --351

select b.MinType, b.MaxType, * from 
(select * from SymbolsPolygon WHERE Type='INDEX') a
left join 
(select symbol, CIK, min(Type) MinType, max(Type) MaxType
from SymbolsPolygon
where Type<>'INDEX'
group by symbol, CIK) b on a.Symbol=b.Symbol and a.CIK=b.CIK

select b.MinType, b.MaxType, * from 
(select * from SymbolsPolygon WHERE Type='INDEX') a
left join 
(select symbol, CIK, min(Type) MinType, max(Type) MaxType
from SymbolsPolygon
where Type<>'INDEX'
group by symbol, CIK) b on a.Symbol=b.Symbol and a.CIK=b.CIK
where b.MinType<>b.MaxType

select b.Type, * from 
(select * from SymbolsPolygon where type='INDEX') a
inner join (select * from SymbolsPolygon /*where type is not null and type<>'INDEX'*/) b on a.Symbol=b.Symbol and DATEADD(day,1,a.[To])=b.Date

inner join SymbolsPolygon b on a.CIK=b.CIK


-- select b.Type, * from 
UPDATE a SET Type=b.[Type]
FROM (select * from SymbolsPolygon where type is null) a
inner join (select * from SymbolsPolygon where type is not null) b on a.Symbol=b.Symbol and DATEADD(day,1,a.[To])=b.Date

-- select b.Type, * 
UPDATE a SET Type=b.[Type]
FROM (select * from SymbolsPolygon where type='INDEX') a
inner join (select * from SymbolsPolygon where type is not null and type<>'INDEX') b on a.Symbol=b.Symbol and DATEADD(day,1,a.[To])=b.Date

-- UPDATE A SET Type=b.MinType
select b.MinType, b.MaxType, *
FROM (select * from SymbolsPolygon WHERE Type='INDEX') a
inner join 
(select symbol, CIK, min(isnull(Type,'')) MinType, max(isnull(Type,'')) MaxType
from SymbolsPolygon
where isnull(Type,'')<>'INDEX'
group by symbol, CIK
having min(isnull(Type,''))<>max(isnull(Type,'')) and min(isnull(Type,''))<>'') b on a.Symbol=b.Symbol and a.CIK=b.CIK


UPDATE a SET Type=b.[Type]
SELECT *
FROM (select * from SymbolsPolygon where type is null) a
inner join (select * from SymbolsPolygon where type is not null) b on a.Symbol=b.Symbol and DATEADD(day,2,a.[To])=b.Date

