;with data as
	(
		select ([Open]-[Close])/[Open]*100 PrevOpenRate, ([Open]-[Close])/([Open]+[Close])*200 PrevCOProfit,
		([High]-[Low])/(High+Low)*200 PrevHLProfit,
		a.* from dbQ2024..DayPolygon a 
		inner join dbQ2024..SymbolsPolygon b on a.Symbol=b.Symbol and a.Date between b.Date and isnull(b.[To],'2099-12-31')
		where a.IsTest is null and year(a.Date)>=2022 and
			a.Volume*a.[Close]>=50000000 and a.TradeCount>=10000 --and a.Low>=5.0
--			and FORMAT(a.Date, 'yyyy-MM')='2022-07'
	),
	data2 as (
		select c.OpenIn, c.HighIn, c.LowIn, c.CloseIn,
		c.ProfitWithStop_1_005, c.CountWithStop_1_005,
		c.ProfitWithStop_1_01, c.CountWithStop_1_01,
		c.ProfitWithStop_1_015, c.CountWithStop_1_015,
		c.ProfitWithStop_1_02, c.CountWithStop_1_02,
		c.ProfitIn, c.ProfitCountIn, c.Profit, c.ProfitCount, (c.[Open]-c.[Close]) ProfitValue,
		c.[Open] NextOpen, a.*
		from data a
		inner join dbQ2024..TradingDays b on a.Date=b.Date
		inner join (select
			([OpenIn]-iif(HighIn>=[OpenIn]*1.005, [OpenIn]*1.005, [CloseIn]))/[OpenIn]*100 ProfitWithStop_1_005,
			cast(iif(HighIn>=[OpenIn]*1.005, 0.0, 1.0) as real) CountWithStop_1_005,
			([OpenIn]-iif(HighIn>=[OpenIn]*1.01, [OpenIn]*1.01, [CloseIn]))/[OpenIn]*100 ProfitWithStop_1_01,
			cast(iif(HighIn>=[OpenIn]*1.01, 0.0, 1.0) as real) CountWithStop_1_01,
			([OpenIn]-iif(HighIn>=[OpenIn]*1.015, [OpenIn]*1.015, [CloseIn]))/[OpenIn]*100 ProfitWithStop_1_015,
			cast(iif(HighIn>=[OpenIn]*1.015, 0.0, 1.0) as real) CountWithStop_1_015,
			([OpenIn]-iif(HighIn>=[OpenIn]*1.02, [OpenIn]*1.02, [CloseIn]))/[OpenIn]*100 ProfitWithStop_1_02,
			cast(iif(HighIn>=[OpenIn]*1.02, 0.0, 1.0) as real) CountWithStop_1_02,
			([OpenIn]-[CloseIn])/[OpenIn]*100 ProfitIn,
			cast(iif([OpenIn]<=[CloseIn], 0.0, 1.0) as real) ProfitCountIn,
			([Open]-[Close])/[Open]*100 Profit,
			cast(iif([Open]<=[Close], 0.0, 1.0) as real) ProfitCount,
			* from dbQ2024Minute..MinutePolygonLog where RowStatus in (2,5) AND [OpenIn]>=5.0)
		c on a.Symbol=c.Symbol and c.Date=b.Next1
		-- where 
		-- c.[open] between a.Low*1.02 and a.High*0.98-- and
		--PrevHLProfit between 10 and 4000
	),
	data3 as (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date ORDER BY PrevHLProfit DESC), *
	   FROM data2
	)

	-- select * from data3 where RN<=5 and PrevHLProfit>15 order by date, symbol
	-- select Symbol, Date, OpenIn, HighIn, LowIn, CloseIn from data3 where RN<=5 and PrevHLProfit>15 order by date, symbol

	select 'TOTAL' Year,
	ROUND(avg(ProfitWithStop_1_005), 3) ProfitWithStop_1_005,
	ROUND(sum(CountWithStop_1_005)/count(*)*100.0, 1) CountWithStop_1_005,
	ROUND(avg(ProfitWithStop_1_01), 3) ProfitWithStop_1_01,
	ROUND(sum(CountWithStop_1_01)/count(*)*100.0, 1) CountWithStop_1_01,
	ROUND(avg(ProfitWithStop_1_015), 3) ProfitWithStop_1_015,
	ROUND(sum(CountWithStop_1_015)/count(*)*100.0, 1) CountWithStop_1_015,
	ROUND(avg(ProfitWithStop_1_02), 3) ProfitWithStop_1_02,
	ROUND(sum(CountWithStop_1_02)/count(*)*100.0, 1) CountWithStop_1_02,
	ROUND(avg(ProfitIn),3) ProfitIn, ROUND(sum(ProfitCountIn)/count(*)*100.0, 1) ProfitCountIn,
	ROUND(avg(Profit),3) Profit, ROUND(sum(ProfitCount)/count(*)*100.0, 1) ProfitCount,
	count(*) Recs, ROUND(avg(PrevHLProfit),1) PrevHLProfit, ROUND(sum(ProfitValue),0) ProfitValue from data3
    WHERE RN<=5 and PrevHLProfit>15 -- and [Open]<[Close]
	UNION ALL
	select cast(YEAR(Date) as varchar) Year,
	ROUND(avg(ProfitWithStop_1_005), 3) ProfitWithStop_1_005,
	ROUND(sum(CountWithStop_1_005)/count(*)*100.0, 1) CountWithStop_1_005,
	ROUND(avg(ProfitWithStop_1_01), 3) ProfitWithStop_1_01,
	ROUND(sum(CountWithStop_1_01)/count(*)*100.0, 1) CountWithStop_1_01,
	ROUND(avg(ProfitWithStop_1_015), 3) ProfitWithStop_1_015,
	ROUND(sum(CountWithStop_1_015)/count(*)*100.0, 1) CountWithStop_1_015,
	ROUND(avg(ProfitWithStop_1_02), 3) ProfitWithStop_1_02,
	ROUND(sum(CountWithStop_1_02)/count(*)*100.0, 1) CountWithStop_1_02,
	ROUND(avg(ProfitIn),3) ProfitIn, ROUND(sum(ProfitCountIn)/count(*)*100.0, 1) ProfitCountIn,
	ROUND(avg(Profit),3) Profit, ROUND(sum(ProfitCount)/count(*)*100.0, 1) ProfitCount,
	count(*) Recs, ROUND(avg(PrevHLProfit),1) PrevHLProfit, ROUND(sum(ProfitValue),0) ProfitValue from data3
    WHERE RN<=5 and PrevHLProfit>15 -- and [Open]<[Close]
	group by YEAR(Date) order by 1

-- WHERE RN<=5 and PrevHLProfit>10 (year>=2010) => !!! ProfitWithStop_1_015 is the best
-- Year	ProfitWithStop_1_005	CountWithStop_1_005	ProfitWithStop_1_01	CountWithStop_1_01	ProfitWithStop_1_015	CountWithStop_1_015	ProfitWithStop_1_02	CountWithStop_1_02	Profit	ProfitCount	Recs	PrevHLProfit	ProfitValue
-- TOTAL	0,371	11,2	0,426	18,4	0,435	25	0,423	30,9	0,973	56,1	17559	26	4876


-- WHERE RN<=5 and PrevHLProfit>10
-- Year	Profit	Recs	PrevHLProfit	ProfitValue
-- 2022	1,01220897754431	1250	35,5919923835754	887
-- 2023	1,920326608463	1248	32,6432520594352	626
-- 2024	1,12192778425405	980	36,5583978010684	257

/*	select FORMAT(Date,'yyyy-MM') Period, avg(Profit) Profit, count(*) Recs, avg(PrevHLProfit) PrevHLProfit, ROUND(sum(ProfitValue),0) ProfitValue from data3
    WHERE RN<=5 and PrevHLProfit>10 -- and [Open]<[Close]
	group by FORMAT(Date,'yyyy-MM')*/
