-- Update
exec [pUpdateSymbolsPolygon1] -- 1 sec
exec [pTempSymbolsPolygon1] -- 107 secs/old: 89 secs
exec [pTempSymbolsPolygon2] -- 4 min 42 secs

-- select * into xx_SymbolsPolygon_2023_12_19 from SymbolsPolygon -- 47211 recs
insert into SymbolsPolygon (Symbol, Date, [To], Exchange, Updated, [TimeStamp])
select a.Symbol, a.EndDate, a.Date, 'DAY', a.Enddate, GETDATE()
from Temp_SymbolsPolygon23 a

exec [pTempSymbolsPolygon1] -- 2 min 40 secs

-- =====  Rollback update  =========
truncate table SymbolsPolygon;
insert into SymbolsPolygon SELECT * from SymbolsPolygon_2023_12_19
select * from SymbolsPolygon
-- =====
truncate table SymbolsPolygon;
insert into SymbolsPolygon SELECT * from xx_SymbolsPolygon_2023_12_19_310
-- =======================
drop table xx_SymbolsPolygon_2023_12_19;
select * into xx_SymbolsPolygon_2023_12_19 from SymbolsPolygon -- 47'000 records
drop table xx_SymbolsPolygon_2023_12_19_310;
select * into xx_SymbolsPolygon_2023_12_19_310 from SymbolsPolygon -- 310'000 records
--
drop table xx_SymbolsPolygonError;
select a.* into xx_SymbolsPolygonError from DayPolygon a
left join SymbolsPolygon b on a.Symbol=b.Symbol and a.Date between b.Date and isnull(b.[To], '2099-12-31')
where b.Symbol is null
-- ===========  Checking  ==========
-- 20 secs
select * from SymbolsPolygon a
inner join SymbolsPolygon b on a.Symbol=b.Symbol and b.Date>a.Date and b.Date<=isnull(a.[To], '2099-12-31')

-- 19 secs
select * from SymbolsPolygon a
inner join SymbolsPolygon b on a.Symbol=b.Symbol and b.[To]>=a.Date and b.[To]<isnull(a.[To], '2099-12-31')

-- 2 min 07 secs 
select * from DayPolygon a
left join SymbolsPolygon b on a.Symbol=b.Symbol and a.Date between b.Date and isnull(b.[To], '2099-12-31')
where b.Symbol is null

select isnull(c.days,0)-isnull(b.days,0) DayDifference, * from 
(select symbol, count(*) DayRecs from DayPolygon group by symbol) a
inner join (select symbol, sum(DATEDIFF(day, date,isnull([To],'2023-12-01'))+1) days, count(*) recs 
from SymbolsPolygon_2023_12_19_1
group by symbol) b on a.Symbol=b.Symbol
inner join (select symbol, sum(DATEDIFF(day, date,isnull([To],'2023-12-01'))+1) days, count(*) recs 
from SymbolsPolygon
group by symbol) c on a.Symbol=c.Symbol
order by 1 desc


-- =====================
select * from SymbolsPolygon
select * from Temp_SymbolsPolygon23
-- =====================
select * from Temp_SymbolsPolygon4 where symbol in ('AAXJ')
select * from SymbolsPolygon where symbol in ('AAXJ')
select * from Temp_SymbolsPolygon where symbol in ('AAXJ')
select * from SymbolsPolygon_2023_12_14 where symbol in ('AAXJ')
select * from DayPolygon where symbol in ('AAXJ')


select * from SymbolsPolygon where symbol='FTSD' -- 2013-11-12

select * from Temp_SymbolsPolygon4

select * from SymbolsPolygon where symbol='AABC'
select * from DayPolygon where symbol='AABC'
select * from Temp_SymbolsPolygon4 where symbol='AABC'

select * from TradingDays

select * from Temp_SymbolsPolygon4 where symbol in ('A.WD','AA^B','AABC')
select * from SymbolsPolygon where symbol in ('AAIT','AAXJ')
select * from SymbolsPolygon_2023_12_14 where symbol in ('AAIT','AAXJ')
select * from DayPolygon where symbol in ('AAXJ')

select b.Date, a.*
from (select * from SymbolsPolygon where [To] is not null) a
left join DayPolygon b on b.Symbol=a.Symbol and b.Date between a.[To] and a.[Date]
where a.symbol='A.WD'


select symbol, min(Exchange), max(Exchange) from SymbolsPolygon
group by symbol
having min(Exchange)='DAY'
