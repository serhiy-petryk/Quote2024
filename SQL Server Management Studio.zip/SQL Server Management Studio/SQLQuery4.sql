--  Execution duration: 82 seconds
;WITH Data AS
    (
SELECT
abs(d1.[Open]-d1.[Close])/(d1.[Open]+d1.[Close]) * 200.0 PrevChangeAbsOpenCLose,
(d1.[High]-d1.[Low])/(d1.[High]+d1.[Low]) * 200.0 PrevChangeHighLow,
(d2.[Open]-d2.[Close])/(d2.[Open]+d2.[Close]) * 200.0 Profit,
(d2.[Open]-d2.[Close])/(d2.[Open]) * 100.0 ProfitReal,
iif(d2.[Open]<d2.[Close], 1, 0) UpCount,
iif(d2.[Open]>d2.[Close], 1, 0) DownCount,
d1.[Close]*d1.[Volume]/1000000.0 Turnover,
case when d1.[Open]>d1.[Close] then d1.[Open]/d1.[Close] else d1.[Close]/d1.[Open] end K_OpenClose,
case when d1.[Open]>d1.[Close] then d1.[Close]/d1.[Open] else d1.[Open]/d1.[Close] end K_CloseOpen,
d2.[Open]/d2.[Close] NewK_OpenClose,
d2.[Close]/d2.[Open] NewK_CloseOpen,
d1.[open]/d1.[Close] PrevOpenClose,
d1.Symbol,
format(d2.date, 'yyyy-MM') as period, case when d1.[Open]>d1.[Close] then 'Down' else 'Up' end as UpDown,
d1.Date Date1, d1.[Open] Open1, d1.High High1, d1.Low Low1, d1.[Close] Close1, d1.Volume Volume1, d1.TradeCount TradeCnt1, d1.volume/1000000.0 * d1.[close] Turnover1,
d2.Date Date2, d2.[Open] Open2, d2.High High2, d2.Low Low2, d2.[Close] Close2, d2.Volume Volume2, d2.TradeCount TradeCnt2, d2.volume/1000000.0 * d2.[close] Turnover2
FROM dbQ2024..DayPolygon d1
inner join dbQ2024..TradingDays b on d1.Date=b.Date
left join dbQ2024..TradingShortened c1 on b.Next1=c1.Date
inner join dbQ2024..DayPolygon d2 on d1.Symbol=d2.Symbol and b.Next1=d2.Date
where d1.IsTest is null
and d1.tradecount>10000 and d1.[close]>5 and d1.volume/1000000.0 * d1.[close]>50
and d2.[Open]>5.0
and b.IsShortened is null and c1.Date is null
and year(d2.Date)>=2010
-- and year(d1.Date) in (2023)
),
CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date2 ORDER BY PrevChangeHighLow desc), *
	   FROM data 
    ),
CTE1 AS (
		SELECT * from CTE
		WHERE RN<=5 and PrevChangeHighLow>=15
--     WHERE   RN<=5 and PrevChangeHighLow>=18.2 and Year(date2)=2023
)

--	select Date1, RN, Symbol, ProfitReal, PrevChangeHighLow  from CTE1 order by Date1, RN;

    SELECT 'Total' Year, ROUND(avg(ProfitReal),3) ProfitReal,
	ROUND(cast(sum(UpCount)*1.0/count(*)*100.0 as real),2) UpPerc,
	ROUND(cast(sum(DownCount)*1.0/count(*)*100.0 as real),2) DownPerc,
	ROUND(avg(Profit),3) Profit, count(*) Recs
	FROM CTE1
	UNION ALL
    SELECT format(date1, 'yyyy') Year, ROUND(avg(ProfitReal),3) ProfitReal,
	ROUND(cast(sum(UpCount)*1.0/count(*)*100.0 as real),2) UpPerc,
	ROUND(cast(sum(DownCount)*1.0/count(*)*100.0 as real),2) DownPerc,
	ROUND(avg(Profit),3) Profit, count(*) Recs
	FROM CTE1
	GROUP by format(date1, 'yyyy') order by 1 desc

/* WHERE RN<=10 and PrevChangeHighLow>=10
Year	ProfitReal	UpPerc	DownPerc	Profit	Recs
Total	0,627	45,09	54,38	1,103	30634
2024	0,62	44,17	55,25	1,39	2040
2023	1,003	46,62	53,08	1,597	2385
2022	0,437	45,5	54,1	1,259	2466
2021	1,619	38,92	60,8	2,752	2500
2020	0,682	43,4	56,23	1,548	2470
2019	0,348	48,95	50,35	0,631	2153
2018	0,661	45,8	53,53	0,987	2225
2017	0,583	45,09	54,29	0,856	1923
2016	0,378	47,75	51,74	0,739	2178
2015	0,239	47,43	51,96	0,503	2163
2014	0,664	44,1	55,34	0,906	1993
2013	0,544	45,45	53,96	0,708	1540
2012	0,208	45,37	53,98	0,346	1532
2011	0,492	44,04	55,49	0,642	1721
2010	0,549	44,31	54,8	0,674	1345
*/

/* WHERE RN<=5 and PrevChangeHighLow>=18
Year	ProfitReal	UpPerc	DownPerc	Profit	Recs
Total	1,349	42,02	57,52	2,395	9804
2024	1,49	42,58	56,96	2,876	883
2023	2,522	40,55	59,12	3,761	910
2022	1,174	42,78	56,85	2,659	1073
2021	2,071	36,69	62,99	3,749	1243
2020	0,894	42,6	56,86	2,364	1122
2019	1,066	42,43	56,64	1,782	535
2018	1,234	43,52	55,75	1,912	687
2017	1,487	42,86	56,51	2,188	476
2016	0,75	47,08	52,44	1,602	616
2015	0,902	43,48	56,36	1,355	621
2014	1,187	42,77	56,84	1,673	512
2013	1,009	43,9	55,79	1,367	328
2012	0,719	38,91	60,36	0,962	275
2011	0,516	42,41	57,59	0,786	323
2010	1,636	42,5	56,5	1,97	200
*/

/* WHERE RN<=5 and PrevChangeHighLow>15
Year	ProfitReal	UpPerc	DownPerc	Profit	Recs
Total	1,137	42,97	56,51	1,994	12528
2024	1,365	42,84	56,65	2,64	978
2023	2,145	42,36	57,27	3,205	1093
2022	0,967	43,32	56,17	2,325	1191
2021	2,064	36,75	62,93	3,734	1249
2020	0,951	42,42	57,08	2,346	1200
2019	0,89	44,81	54,43	1,433	790
2018	0,992	43,84	55,62	1,552	917
2017	1,044	43,77	55,1	1,56	706
2016	0,587	47,51	52,13	1,278	823
2015	0,654	44,81	54,97	1,036	886
2014	1,153	41,99	57,74	1,543	762
2013	0,965	44,11	55,33	1,242	535
2012	0,541	42,21	56,76	0,744	488
2011	0,353	45,1	54,53	0,561	541
2010	1,17	42,82	55,83	1,398	369
*/
