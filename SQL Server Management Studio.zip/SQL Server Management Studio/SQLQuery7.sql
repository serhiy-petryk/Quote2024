use dbQ2023;
--drop table temp_OpenCloseIn
select avg(K_OpenClose), avg(NewK), avg(OldK), count(*), min(OldK) from 
(SELECT
case when d.[Open]>d.[Close] then d.[Open]/d.[Close] else d.[Close]/d.[Open] end K_OpenClose,
 e.[Open]/e.[Close] NewK, d.[open]/d.[Close] OldK,
format(e.date, 'yyyy-MM') as period, case when d.[Open]>d.[Close] then 'Down' else 'Up' end as UpDown,
1.0*d.TradeCount/a.TradeCount TradeK, a.Symbol, 
a.Date Date1, a.[Open] Open1, a.High High1, a.Low Low1, a.[Close] Close1, a.Final Final1, a.Volume Volume1, a.TradeCount TradeCnt1, a.volume/1000000.0 * a.[close] Turnover1,
d.Date Date2, d.[Open] Open2, d.High High2, d.Low Low2, d.[Close] Close2, d.Final Final2, d.Volume Volume2, d.TradeCount TradeCnt2, d.volume/1000000.0 * d.[close] Turnover2,
e.Date Date3, e.[Open] Open3, e.High High3, e.Low Low3, e.[Close] Close3, e.Final Final3, e.Volume Volume3, e.TradeCount TradeCnt3, e.volume/1000000.0 * e.[close] Turnover3
-- into temp_OpenCloseIn
 FROM DayPolygonIn a
inner join dbQ2023Others..TradingDays b on a.Date=b.Date
left join dbQ2023Others..TradingDaysSpecific c1 on a.Date=c1.Date
left join dbQ2023Others..TradingDaysSpecific c2 on b.Next1=c2.Date
left join dbQ2023Others..TradingDaysSpecific c3 on b.Next2=c3.Date
inner join DayPolygonIn d on a.Symbol=d.Symbol and b.Next1=d.Date
inner join DayPolygonIn e on a.Symbol=e.Symbol and b.Next2=e.Date
left join dbQ2023Others..Splits s1 on s1.Symbol=a.Symbol and s1.Date=a.Date
left join dbQ2023Others..Splits s2 on s2.Symbol=d.Symbol and s2.Date=d.Date
left join dbQ2023Others..Splits s3 on s3.Symbol=e.Symbol and s3.Date=e.Date
where d.[close] >= 5
and c1.Date is null and c2.Date is null and c3.Date is null
and s1.Symbol is null and s2.Symbol is null and s3.Symbol is null 
and (d.[Open]/d.[Close]<0.95 or d.[Open]/d.[Close]>1.05))x

;WITH CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date3 ORDER BY K_OpenClose desc), * FROM temp_OpenCloseIn
    )
    SELECT period, avg(NewK), count(*)
    FROM    CTE
    WHERE   RN <= 10 and K_OpenClose>=1.13
group by period

-- ==============================
-- ==============================
--drop table temp_OpenClose
select avg(K_OpenClose), avg(NewK), avg(OldK), count(*), min(OldK) from 
(SELECT
case when d.[Open]>d.[Close] then d.[Open]/d.[Close] else d.[Close]/d.[Open] end K_OpenClose,
 e.[Open]/e.[Close] NewK, d.[open]/d.[Close] OldK,
format(e.date, 'yyyy-MM') as period, case when d.[Open]>d.[Close] then 'Down' else 'Up' end as UpDown,
1.0*d.TradeCount/a.TradeCount TradeK, a.Symbol, 
a.Date Date1, a.[Open] Open1, a.High High1, a.Low Low1, a.[Close] Close1, a.Volume Volume1, a.TradeCount TradeCnt1, a.volume/1000000.0 * a.[close] Turnover1,
d.Date Date2, d.[Open] Open2, d.High High2, d.Low Low2, d.[Close] Close2, d.Volume Volume2, d.TradeCount TradeCnt2, d.volume/1000000.0 * d.[close] Turnover2,
e.Date Date3, e.[Open] Open3, e.High High3, e.Low Low3, e.[Close] Close3, e.Volume Volume3, e.TradeCount TradeCnt3, e.volume/1000000.0 * e.[close] Turnover3
-- into temp_OpenClose
 FROM DayPolygon a
inner join dbQ2023Others..TradingDays b on a.Date=b.Date
left join dbQ2023Others..TradingDaysSpecific c1 on a.Date=c1.Date
left join dbQ2023Others..TradingDaysSpecific c2 on b.Next1=c2.Date
left join dbQ2023Others..TradingDaysSpecific c3 on b.Next2=c3.Date
inner join DayPolygon d on a.Symbol=d.Symbol and b.Next1=d.Date
inner join DayPolygon e on a.Symbol=e.Symbol and b.Next2=e.Date
left join dbQ2023Others..Splits s1 on s1.Symbol=a.Symbol and s1.Date=a.Date
left join dbQ2023Others..Splits s2 on s2.Symbol=d.Symbol and s2.Date=d.Date
left join dbQ2023Others..Splits s3 on s3.Symbol=e.Symbol and s3.Date=e.Date
where d.tradecount>5000 and d.[close] >= 5 and d.volume/1000000.0 * d.[close]>10
and c1.Date is null and c2.Date is null and c3.Date is null
and s1.Symbol is null and s2.Symbol is null and s3.Symbol is null 
and (d.[Open]/d.[Close]<0.95 or d.[Open]/d.[Close]>1.05))x

;WITH CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date3 ORDER BY K_OpenClose desc), * FROM temp_OpenClose
    )
    SELECT *
    FROM    CTE
    WHERE   RN <= 5
	order by Date1, RN ;
