use dbQ2023Others;

select * from DayEoddata where [open]>high or [open]<low or [close]>high or [close]<low or low <=0;

select a.* from DayEoddata a left join TradingDays b on a.Date=b.Date where b.Date is null;

select symbol, date, count(*) records, min(Exchange), max(Exchange) from DayEoddata
group by symbol, date having count(*)<>1

/*select * from dbQuote2023..DayAlphaVantage
where ([open]>high or [open]<low or [close]>high or [close]<low or low <=0)
 and volume>0 and date>'2022-01-01';

select a.* from dbQuote2023..DayAlphaVantage a left join TradingDays b on a.Date=b.Date
where a.Date>'2002-01-01' and b.Date is null;*/
