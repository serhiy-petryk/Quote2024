;WITH Data AS
    (
SELECT
abs(d2.[Open]-d2.[Close])/(d2.[Open]+d2.[Close]) * 200.0 PrevChangeAbsOpenCLose,
(d2.[High]-d2.[Low])/(d2.[High]+d2.[Low]) * 200.0 PrevChangeHighLow,
(d3.[Open]-d3.[Close])/(d3.[Open]+d3.[Close]) * 200.0 Profit,
(d3.[Open]-d3.[Close])/(d3.[Open]) * 200.0 ProfitReal,
iif(d3.[Open]<d3.[Close], 1, 0) UpCount,
iif(d3.[Open]>d3.[Close], 1, 0) DownCount,
d2.[Close]*d2.[Volume]/1000000.0 Turnover,
case when d2.[Open]>d2.[Close] then d2.[Open]/d2.[Close] else d2.[Close]/d2.[Open] end K_OpenClose,
case when d2.[Open]>d2.[Close] then d2.[Close]/d2.[Open] else d2.[Open]/d2.[Close] end K_CloseOpen,
d3.[Open]/d3.[Close] NewK_OpenClose,
d3.[Close]/d3.[Open] NewK_CloseOpen,
d2.[open]/d2.[Close] PrevOpenClose, d1.[open]/d1.[Close] Prev2_OpenClose,
format(d3.date, 'yyyy-MM') as period, case when d2.[Open]>d2.[Close] then 'Down' else 'Up' end as UpDown,
1.0*d2.TradeCount/d1.TradeCount TradeK, d1.Symbol, 
d1.Date Date1, d1.[Open] Open1, d1.High High1, d1.Low Low1, d1.[Close] Close1, d1.Volume Volume1, d1.TradeCount TradeCnt1, d1.volume/1000000.0 * d1.[close] Turnover1,
d2.Date Date2, d2.[Open] Open2, d2.High High2, d2.Low Low2, d2.[Close] Close2, d2.Volume Volume2, d2.TradeCount TradeCnt2, d2.volume/1000000.0 * d2.[close] Turnover2,
d3.Date Date3, d3.[Open] Open3, d3.High High3, d3.Low Low3, d3.[Close] Close3, d3.Volume Volume3, d3.TradeCount TradeCnt3, d3.volume/1000000.0 * d3.[close] Turnover3
-- into temp_OpenCloseDay
FROM dbQ2024..DayPolygon d1
inner join dbQ2024..TradingDays b on d1.Date=b.Date
left join dbQ2024..TradingShortened c1 on b.Next1=c1.Date
left join dbQ2024..TradingShortened c2 on b.Next2=c2.Date
inner join dbQ2024..DayPolygon d2 on d1.Symbol=d2.Symbol and b.Next1=d2.Date
inner join dbQ2024..DayPolygon d3 on d1.Symbol=d3.Symbol and b.Next2=d3.Date
left join dbQ2024..Splits s1 on s1.Symbol=d1.Symbol and s1.Date=d1.Date
left join dbQ2024..Splits s2 on s2.Symbol=d2.Symbol and s2.Date=d2.Date
left join dbQ2024..Splits s3 on s3.Symbol=d3.Symbol and s3.Date=d3.Date
where d1.IsTest is null
-- and d1.tradecount>10000 and d1.[close]>5 and d1.volume/1000000.0 * d1.[close]>50
and d2.tradecount>10000 and d2.[close]>5 and d2.volume/1000000.0 * d2.[close]>50
and d3.[Open]>5.0
and b.IsShortened is null and c1.Date is null and c2.Date is null
and s1.Symbol is null and s2.Symbol is null and s3.Symbol is null 
and year(d3.Date)>=2010
-- and d3.Date between '2022-01-01' and '2024-01-01'
),
CTE AS
    (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date3 ORDER BY PrevChangeHighLow desc), *
	   FROM data
    )
    SELECT 'Total' Year, ROUND(avg(ProfitReal),3) ProfitReal,
	ROUND(cast(sum(UpCount)*1.0/count(*)*100.0 as real),2) UpPerc,
	ROUND(cast(sum(DownCount)*1.0/count(*)*100.0 as real),2) DownPerc,
	ROUND(avg(Profit),3) Profit, count(*) Recs
	FROM CTE
--     WHERE   RN<=5 and PrevChangeHighLow>=18.2 and Year(date3)=2023
    WHERE RN<=5 and PrevChangeHighLow>=18 --and Year(date3)=2023
	UNION ALL
--    SELECT ROUND(avg(ProfitReal),3) ProfitReal,
    SELECT format(date3, 'yyyy') Year, ROUND(avg(ProfitReal),3) ProfitReal,
	ROUND(cast(sum(UpCount)*1.0/count(*)*100.0 as real),2) UpPerc,
	ROUND(cast(sum(DownCount)*1.0/count(*)*100.0 as real),2) DownPerc,
	ROUND(avg(Profit),3) Profit, count(*) Recs
	FROM CTE
--     WHERE   RN<=5 and PrevChangeHighLow>=18.2 and Year(date3)=2023
    WHERE RN<=5 and PrevChangeHighLow>=18 --and Year(date3)=2023
	GROUP by format(date3, 'yyyy') order by 1 desc

-- 3,48739040092832	883 / 2023 year
-- 3,10897138641812	439 / 2023/ filter for d1 table and tradecount>=5000 and RN<=5
-- 3,06326995044947	437 / 2023/ filter for d1 table and d3.Open>5.0 and tradecount>=5000 and RN<=5
-- 3,03822976503221	435 / 2023/ filter for d1 table and d3.Open>5.0 and tradecount>10000 and RN<=5

-- ProfitReal	UpPerc	DownPerc	Profit	Recs
-- (PrevChangeHighLow>=10, 2023 year) filter for d1 table and RN<=5 and d3.Open>5.0 and tradecount>10000
-- 1,445	45,93	53,73	1,192	1193
-- (PrevChangeHighLow>=10, 2023 year) filter RN<=5 and d3.Open>5.0 and tradecount>10000
-- 3,333	43,51	56,16	2,543	1218

-- (PrevChangeHighLow>=14) filter RN<=5 and d3.Open>5.0 and tradecount>10000
/*
Year	ProfitReal	UpPerc	DownPerc	Profit	Recs
Total	1,955	43,6	55,84	1,751	13205
2024	2,4	43,03	56,46	2,412	990
2023	3,701	43,16	56,48	2,793	1119
2022	1,164	43,47	55,87	1,707	1210
2021	3,198	37,67	62,09	3,24	1245
2020	1,96	42,06	57,44	2,355	1203
2019	1,46	46,74	52,44	1,216	860
2018	2,023	44,21	55,17	1,503	968
2017	1,576	45,97	53,01	1,257	781
2016	1,249	48,12	51,55	1,236	904
2015	1,01	45,6	53,98	0,855	943
2014	2,346	42,56	57,32	1,538	813
2013	2,482	41,74	57,74	1,498	575
2012	1,072	42,86	56,24	0,725	553
2011	0,358	46,05	53,46	0,366	621
2010	2,091	44,05	54,29	1,254	420
*/

-- (PrevChangeHighLow>=18, 2023 year) filter RN<=5 and d3.Open>5.0 and tradecount>10000
/*
Year	ProfitReal	UpPerc	DownPerc	Profit	Recs
Total	2,434	42,32	57,21	2,23	9454
2024	2,716	42,94	56,6	2,703	871
2023	4,576	40,64	59,02	3,429	881
2022	1,454	43,05	56,48	1,979	1064
2021	3,19	37,7	62,06	3,247	1236
2020	1,895	42,03	57,42	2,432	1092
2019	1,994	42,75	56,27	1,706	510
2018	2,546	44,58	54,64	1,922	646
2017	2,94	43,57	55,77	2,175	459
2016	1,689	47,47	52,03	1,68	592
2015	1,51	44,07	55,76	1,194	590
2014	2,631	42,89	56,9	1,814	471
2013	2,492	43,3	56,36	1,616	291
2012	1,571	38,4	60,84	1,03	263
2011	0,352	43,75	56,25	0,435	304
2010	3,641	41,85	57,07	2,16	184
*/

-- (PrevChangeHighLow>=14) filter RN<=10 and d3.Open>5.0 and tradecount>10000
/*
Year	ProfitReal	UpPerc	DownPerc	Profit	Recs
Total	1,492	44,47	55,02	1,38	19608
2024	1,532	43,34	56,09	1,611	1733
2023	2,443	45,97	53,67	1,933	1677
2022	0,395	45,64	53,9	0,99	2156
2021	2,835	39,57	60,06	2,512	2469
2020	1,185	43,59	56	1,515	2232
2019	1,372	47,17	52,19	1,103	1094
2018	1,609	45,63	53,71	1,216	1361
2017	1,575	45,43	53,71	1,214	929
2016	0,967	47,23	52,37	0,99	1245
2015	0,312	47,61	51,93	0,485	1296
2014	1,962	44,43	55,46	1,339	970
2013	2,364	42,63	56,74	1,423	631
2012	0,889	43,56	55,46	0,625	613
2011	0,462	44,92	54,68	0,42	748
2010	2,095	43,17	55,29	1,245	454
*/

-- (PrevChangeHighLow>=10) filter RN<=10 and d3.Open>5.0 and tradecount>10000
/*
Year	ProfitReal	UpPerc	DownPerc	Profit	Recs
Total	1,144	45,19	54,27	1,029	30114
2024	1,137	44,21	55,2	1,315	2029
2023	1,764	46,55	53,07	1,427	2363
2022	0,375	45,97	53,58	0,905	2456
2021	2,816	39,64	60	2,494	2490
2020	1,24	43,47	56,16	1,475	2450
2019	0,631	49,12	50,17	0,592	2105
2018	1,303	46,15	53,21	0,961	2180
2017	1,162	45,13	54,24	0,852	1877
2016	0,807	47,83	51,65	0,755	2147
2015	0,347	47,83	51,6	0,432	2122
2014	1,418	43,91	55,57	0,948	1938
2013	1,289	44,41	54,97	0,806	1468
2012	0,464	45,18	54,15	0,366	1494
2011	0,835	44,15	55,37	0,567	1685
2010	1,109	44,2	54,89	0,679	1310
*/
