use dbQ2023Others;
exec pUpdateSymbolsXref;
exec pRefreshSymbols;

-- ============================== --
-- ===== Check Symbol Xref ====== --
-- ============================== --
-- Yahoo symbols check --
select * from SymbolsEoddata where YahooSymbol is null
-- 2023-02-18: 5 deleted/test symbols (BAM.P, BN.P, GE.P, MBC.P, NTEST.I)
-- 2023-02-18: 1 test symbol (NTEST.I)
-- 2024-01-20: 3 symbols (JNJ.W, MMM.W, NTEST.I)

-- Nasdaq Screener Xref check (no etfs, warrants, units, rights)
select b.* from SymbolsEoddata a
right join (select * from ScreenerNasdaqStock
where Deleted is null or Deleted>'2023-01-01') b on a.NasdaqSymbol=b.Symbol
where a.Symbol is null order by 1
-- 2023-02-18: 2 symbols from PINK exchange (CANB, IMCI)
-- 2023-03-04: 6 symbols (ACKIT, ASBA, CANB, CTRMV, IMCI, TOROV)
-- 2023-03-12: 4 symbols (ACKIT, CANB, IMCI)
-- 2023-03-18: 9 symbols (BLAC, BLACR, BLACW, CANB(PNK), CLCO, FORLU, IMCI(PNK), YS, YSBPW)
-- 2023-03-25: 6 symbols (CANB(PNK), CETU, CETUR, CETUW, IMCI(PNK), OAKUU)
-- 2023-04-01: 4 symbols (CANB(PNK), HKIT, HSHP, IMCI(PNK))
-- 2023-04-07: 3 symbols (CANB(PNK), IMCI(PNK), SHLT)
-- 2023-04-15: 3 symbols (BTDR, CANB(PNK), IMCI(PNK))
-- 2023-04-22: 3 symbols (CANB(PNK), IMCI(PNK), SPHR)
-- 2023-04-29: 3 symbols (CANB(PNK), IMCI(PNK), TRNR)
-- 2023-05-06: 3 symbols (CANB(PNK), IMCI(PNK), TPCS)
-- 2023-05-13: 4 symbols (CANB(PNK), FORL, FORLW, IMCI(PNK))
-- 2023-05-20: 5 symbols (CANB(PNK), FORL, FORLW, IMCI(PNK), OAKU, OAKUR, OAKUW)
-- 2023-05-27: 3 symbols (ATMU, CANB(PNK), IMCI(PNK))
-- 2023-06-10: 3 symbols (CANB(PNK), IMCI(PNK), NPWR)
-- 2023-06-17: 4 symbols (AZTR, CANB(PNK), IMCI(PNK), WKC)
-- 2023-06-24: 2 symbols (CANB(PNK), IMCI(PNK))
-- 2023-07-01: 5 symbols (AENT, AENTW, ALCYCANB(PNK), IMCI(PNK))
-- 2023-07-08: 2 symbols (CANB(PNK), IMCI(PNK))
-- 2023-07-22: 4 symbols (CANB(PNK), ESHA, ESHAR, IMCI(PNK))
-- 2023-08-05: 5 symbols (CANB(PNK), IMCI(PNK), LDWY, LLYVA, LLYVK)
-- 2023-08-12: 2 symbols (CANB(PNK), IMCI(PNK))
-- 2023-09-16: 9 symbols (CANB, CDP, CNFRZ, HYAC, IMCI, KVAC, KVACW, SHOT, SHOTW)
-- 2023-09-23: 3 symbols (CANB, CNFRZ, IMCI)
-- 2023-09-30: 6 symbols (ANL, BTCT, BTCTW, CANB, CNFRZ, IMCI)
-- 2023-10-14: 4 symbols (CANB, CNFRZ, IMCI, NNAG)
-- 2023-11-04: 5 symbols (CANB, CREV, CREVW, ET^I, IMCI)
-- 2023-11-11: 2 symbols (CANB, IMCI)

select b.* from SymbolsEoddata a
right join ScreenerNasdaqEtf b on a.NasdaqSymbol=b.Symbol
where a.Symbol is null order by 1
-- 2023-03-04: 0 symbols

/**select b.* from SymbolsEoddata a
right join dbQuote2023..ProfileYahoo b on a.YahooSymbol=b.Symbol
where a.Symbol is null order by 1
-- 2023-03-04: 0 symbols
-- 2023-03-12: 2 symbols (CANB, IMCI)

select a.* from SymbolsEoddata a
left join dbQuote2023..ProfileYahoo b on a.YahooSymbol=b.Symbol
where b.Symbol is null and a.Deleted is null order by 1
-- 2023-03-04: 1 symbol (NTEST.I)
-- 2023-03-18: 35 symbols*/

-- TradingView Xref check (no rights, warrants)
select b.* from SymbolsEoddata a
right join ScreenerTradingView b on a.TradingViewSymbol=b.Symbol
where a.Symbol is null order by 1
-- 2023-02-18: 2 symbols (IVRS, VTS/I(not valid in nasdaq/yahoo))
-- 2023-03-04: 4 symbols (CTRMV, EMDM, TOROV, VTS/I)
-- 2023-03-12: 1 symbol (VTS/I)
-- 2023-03-18: 5 symbols (BLAC, CLCO, FORLU, VTS/I, YS)
-- 2023-03-24: 5 symbols (CETU, OAKUU, VTS/I)
-- 2023-04-01: 4 symbols (HKIT, HSHP, SGLC, VTS/I)
-- 2023-04-07: 2 symbols (SHLT, VTS/I)
-- 2023-04-15: 2 symbols (BTDR, VTS/I)
-- 2023-04-22: 8 symbols (AACT.U, BBIB, BBLB, BBSB, FDAT, SPHR, VTS/I, ZIVB)
-- 2023-04-29: 3 symbols (SBXC, TRNR, VTS/I)
-- 2023-04-29: 3 symbols (INAQU, TPCS, VTS/I)
-- 2023-04-29: 3 symbols (FORL, INAQU, VTS/I)
-- 2023-05-20: 6 symbols (AMPD, FGDL, OAKU, PEMX, VTS/I, ZTAX)
-- 2023-05-27: 2 symbols (ATMI, VTS/I)
-- 2023-06-10: 3 symbols (NPWR, RMIF, VTS/I)
-- 2023-06-17: 3 symbols (AZTR, VTS/I, WKC)
-- 2023-06-24: 5 symbols (BILZ, HCMT, IBDY, LH/I, VTS/I)
-- 2023-07-01: 7 symbols (AENT, ALCY, BDVG, IVVB, IVVM, LH/I, VTS/I)
-- 2023-07-08: 3 symbols (LH/I, MUSQ, VTS/I)
-- 2023-07-15: 2 symbols (LH/I, VTS/I)
-- 2023-07-22: 3 symbols (ESHA, LH/I, VTS/I)
-- 2023-08-05: 7 symbols (FMST, LDWY, LH/I, LLYVA, LLYVK, MGOV, VTS/I)
-- 2023-08-12: 3 symbols (FMST, LH/I, VTS/I)
-- 2023-09-16: 8 symbols (BGIG, CDP, CNFRZ, HYAC, KVAC, LH/I, SHOT, VTS/I)
-- 2023-09-30: 6 symbols (ANL, ARMK/I, BTCT, CNFRZ, LH/I, VTS/I)
-- 2023-10-07: 18 symbols
-- 2023-10-14: 5 symbols
-- 2023-10-21: 16 symbols
-- 2023-10-28: 11 symbols
-- 2023-11-04: 6 symbols (ARMK/I, CREV, ET/PI, LH/I, VTS/I, WPC/I)

-- Exists in Eoddata and missing in TradingView
select a.* from (SELECT * from SymbolsEoddata WHERE YahooSymbol not like '%-WT%'
and  YahooSymbol not like '%-R%' and not (len(symbol)=5 and symbol not like '%-%'  and symbol not like '%.%' and exchange='NASDAQ')) a
left join ScreenerTradingView b on a.TradingViewSymbol=b.Symbol
where b.Symbol is null and a.Deleted is null order by 1
-- 2023-02-18: 1 symbols (NUZE)
-- 2023-03-12: 2 symbols (ASBA, NUZE)
-- 2023-03-22: 4 symbols (ASBA, MSG.P, NUZE, SPH.P)
-- 2023-05-20: 2 symbols (ASBA, NUZE)
-- 2023-05-27: 3 symbols (ASBA, NHS.P, NUZE)
-- 2023-06-24: 4 symbols (ASBA, ICOP, NHS.P, NUZE)
-- 2023-07-01: 4 symbols (ASBA, LH.P, NHS.P, NUZE)
-- 2023-07-15: 6 symbols (ASBA, CHPS, LH.P, NHS.P, NUZE, PSWD)
-- 2023-07-22: 3 symbols (ASBA, LH.P, NUZE)
-- 2023-08-05: 2 symbols (ASBA, NUZE)
-- 2023-09-30: 6 symbols (ASBA, BAMA, BAMO, BAMV, BAMY, NUZE)
-- 2023-10-14: 4 symbols (ASBA, LAA.P, LAC.P, NUZE)
-- 2023-11-04: 2 symbols (ASBA, NUZE)

select a.* from (SELECT * from SymbolsEoddata where isnull(TvType,'') not in ('warrant', 'right')) a
left join ScreenerTradingView b on a.TradingViewSymbol=b.Symbol
where b.Symbol is null and a.Deleted is null order by 1
-- 2023-03-04: 6 symbols (COWNL, GECCM, HYMCL, NTEST.I, NUZE, OXSQL)
-- 2023-03-12: 7 symbols (ASBA, COWNL, GECCM, HYMCL, NTEST.I, NUZE, OXSQL)
-- 2023-03-18: 5 symbols (ASBA, COWNL, HYMCL, NTEST.I, NUZE)
-- 2023-04-01: 5 symbols (ASBA, HYMCL, NTEST.I, NUZE, STHOV)
-- 2023-04-29: 4 symbols (ASBA, HYMCL, NTEST.I, NUZE)
-- 2023-04-29: 7 symbols (ASBA, HYMCL, LAESV, NHS.P, NTEST.I, NUZE, WKEYV)
-- 2023-06-17: 8 symbols (ASBA, CISSV, HYMCL, LAESV, NHS.P, NTEST.I, NUZE, WKEYV)
-- 2023-06-24: 7 symbols (ASBA, CISSV, HYMCL, ICOP, NHS.P, NTEST.I, NUZE)
-- 2023-07-01: 7 symbols (ASBA, CISSV, HYMCL, LH.P, NHS.P, NTEST.I, NUZE)
-- 2023-07-15: 9 symbols (ASBA, CHPS, CISSV, HYMCL, LH.P, NHS.P, NTEST.I, NUZE, PSWD)
-- 2023-07-22: 5 symbols (ASBA, HYMCL, LH.P, NTEST.I, NUZE)
-- 2023-08-05: 4 symbols (ASBA, HYMCL, NTEST.I, NUZE)
-- 2023-09-30: 8 symbols (ASBA, BAMA, BAMO, BAMV, BAMY, HYMCL, NTEST.I, NUZE)
-- 2023-10-14: 6 symbols (ASBA, HYMCL, LAA.P, LAC.P, NTEST.I, NUZE)
-- 2023-11-04: 4 symbols (ASBA, HYMCL, NTEST.I, NUZE)

select * from SymbolsEoddata where NasdaqSymbol is null;
-- 5 symbols (BAM.P, BN.P, GE.P, MBC.P, NTEST.I)/2023-02-18
-- 6 symbols (BAM.P, BN.P, GE.P, IGR.P, MBC.P, NTEST.I)/2023-03-18
-- 2023-04-01: 1 symbol (NTEST.I)
-- 2024-01-20: 3 symbols (JNJ.W, MMM.W, NTEST.I)

select * from SymbolsEoddata where TradingViewSymbol is null;
-- 6 symbols (BAM.P, BN.P, GE.P, IGR.P, MBC.P, NTEST.I)/2023-03-18
-- 2023-04-01: 1 symbol (NTEST.I)
-- 2024-01-20: 3 symbols (JNJ.W, MMM.W, NTEST.I)

select * from SymbolsEoddata where AlphaVantageSymbol is null;
-- 6 symbols (BAM.P, BN.P, GE.P, IGR.P, MBC.P, NTEST.I)/2023-03-18
-- 2023-04-01: 1 symbol (NTEST.I)
-- 2024-01-20: not supported

-- ====================================== --
-- ===== Check Type, Sector, etc.. ====== --
-- ====================================== --
select * from SymbolsEoddata where TvType is null and Deleted is null;
-- 578 records/2023-01-15, 128 records/2023-01-15, 35 rows/2023-01-28,
-- 25 rows/2023-02-04, 8 rows/2023-02-11
-- 6 rows/2023-03-04 (COWNL, GECCM, HYMCL, NTEST.I, NUZE, OXSQL)
-- 4 rows/2023-04-01 (ASBA, HYMCL, NTEST.I, STHOV)
-- 3 rows/2023-04-01 (ASBA, HYMCL, NTEST.I)
-- 5 rows/2023-05-27 (ASBA, HYMCL, LAESV, NTEST.I, WKEYV)
-- 6 rows/2023-06-17 (ASBA, CISSV, HYMCL, LAESV, NTEST.I, WKEYV)
-- 5 rows/2023-06-24 (ASBA, CISSV, HYMCL, ICOP, NTEST.I)
-- 4 rows/2023-07-01 (ASBA, CISSV, HYMCL, NTEST.I)
-- 6 rows/2023-07-15 (ASBA, CHPS, CISSV, HYMCL, NTEST.I, PSWD)
-- 3 rows/2023-07-22 (ASBA, HYMCL, NTEST.I)
-- 7 rows/2023-09-30 (ASBA, BAMA, BAMO, BAMV, BAMY, HYMCL, NTEST.I)
-- 3 rows/2023-10-14 (ASBA, HYMCL, NTEST.I)

select * from SymbolsEoddata where AltSymbol like '%/%'
and AltSymbol not like '%/P%' and AltSymbol not like '%/W%' and AltSymbol not like '%/R' and AltSymbol not like '%/I';
-- 4 records/2023-01-15, 4 records/2023-01-28 (BAM.P, BN.P, GE.P, MBC.P)
-- 0 records/2023-04-01

select * from SymbolsEoddata where AltSymbol like '%.%' and AltSymbol not like '%.U';
-- 2 records/2023-01-15, 2 records/2023-01-28 (CWE.A, UHA.B)
-- 4 records/2023-04-01 (CWE.A, IGR.P, PLM.P, UHA.B)
-- 5 records/2023-06-17 (AAC.T, CWE.A, IGR.P, PLM.P, UHA.B)

select * from SymbolsEoddata where AltSymbol not like '%/P%' and
AltSymbol not like '%/W%' and AltSymbol not like '%/R' and AltSymbol not like '%/I'
and AltSymbol not like '%.U';
-- 6 records/2023-01-15, 6 records/2023-03-04 (BAM.P, BN.P, CWE.A, GE.P, MBC.P, UHA.B)
-- 4 records/2023-04-01 (CWE.A, IGR.P, PLM.P, UHA.B)
-- 5 records/2023-06-17 (AAC.T, CWE.A, IGR.P, PLM.P, UHA.B)

select a.* from SymbolsEoddata a
left join ScreenerTradingView b on a.TradingViewSymbol=b.Symbol and a.Exchange=b.Exchange
where isnull(a.TvType,'') not in ('warrant','right') and  b.Symbol is null
order by a.LastSale desc
-- 1981 records/2023-01-15, 1954/2023-01-28, 1951/2023-02-04
-- 1950/2023-02-11, 1960/2023-02-18
-- 801/2023-03-04 (� ��������� deleted)
-- 794/2023-04-01 (� ��������� deleted)
-- 793/2023-05-13 (� ��������� deleted)
-- 796/2023-05-27 (� ��������� deleted)
-- 797/2023-06-17 (� ��������� deleted)
-- 798/2023-06-24 (� ��������� deleted)
-- 800/2023-07-15 (� ��������� deleted)
-- 798/2023-07-22 (� ��������� deleted)
-- 802/2023-09-30 (4 deleted)
-- 800/2023-10-14 (6 deleted)
-- 799/2023-11-04 (4 deleted)
-- 801/2023-11-18 (6 deleted)
-- 786/2024-01-13 - after update (5 deleted)

select b.* from SymbolsEoddata a
right join ScreenerTradingView b on a.TradingViewSymbol=b.Symbol and a.Exchange=b.Exchange
where a.Symbol is null;
-- 10 records/2023-01-15, 2 records/2023-01-28, 3 records/2023-01-28
-- 8 records/2023-02-18 (bad Exchange)
-- 4 records/2023-04-01 (CHAA, HKIT, HSHP, SGLC, VTS/I)
-- 2 records/2023-04-07 (SHLT, VTS/I)
-- 9 records/2023-04-22 (AACT.U, ACAQ.U, BBIB, BBLB, BBSB, FDAT, SPHR, VTS/I, ZIVB)
-- 4 records/2023-04-29 (ACAQ.U, SBXC, TRNR, VTS/I)
-- 3 records/2023-04-29 (INAQU, TPCS, VTS/I)
-- 3 records/2023-05-13 (FORL, INAQU, VTS/I)
-- 6 records/2023-05-20 (AMPD, FGDL, OAKU, PEMX, VTS/I, ZTAX)
-- 3 records/2023-05-27 (ATMU, COE, VTS/I)
-- 2 records/2023-06-03 (ATMU, VTS/I)
-- 3 records/2023-06-10 (NPWR, RMIF, VTS/I)
-- 3 records/2023-06-17 (AZTR, VTS/I, WKC)
-- 6 records/2023-06-24 (BILZ, BSAQ.U, HCMT, IBDY, LH/I, VTS/I)
-- 8 records/2023-07-01 (AENT, ALCY, BDVG, BSAQ.U, IVVB, IVVM, LH/I, VTS/I)
-- 4 records/2023-07-08 (BSAQ.U, LH/I, MUSQ, VTS/I)
-- 3 records/2023-07-15 (BSAQ.U, LH/I, VTS/I)
-- 4 records/2023-07-22 (ATEK, ESHA, LH/I, VTS/I)
-- 7 records/2023-08-05 (FMST, LDWY, LH/I, LLYVA, LLYVK, MGOV, VTS/I)
-- 3 records/2023-08-12 (FMST, LH/I, VTS/I)
-- 8 records/2023-09-16 (BGIG, CDP, CNFRZ, HYAC, KVAC, LH/I, SHOT, VTS/I)
-- 6 records/2023-09-30 (ANL, ARMK/I, BTCT, CNFRZ, LH/I, VTS/I)
-- 19 records/2023-10-07
-- 6 records/2023-10-14 (ARMK/I, CNFRZ, LH/I, NNAG, VCXB.U, VTS/I)
-- 17 records/2023-10-21
-- 11 records/2023-10-28
-- 6 records/2023-11-04

select b.* from SymbolsEoddata a
right join ScreenerTradingView b on a.TradingViewSymbol=b.Symbol
where a.Symbol is null
-- 2 records/2023-02-18
-- 4 records/2023-04-01 (HKIT, HSHP, SGLC, VTS/I)
-- 2 records/2023-04-07 (SHLT, VTS/I)
-- 8 records/2023-04-22 (AACT.U, BBIB, BBLB, BBSB, FDAT, SPHR, VTS/I, ZIVB)
-- 3 records/2023-04-22 (SBXC, TRNR, VTS/I)
-- 3 records/2023-04-29 (INAQU, TPCS, VTS/I)
-- 3 records/2023-05-13 (FORL, INAQU, VTS/I)
-- 6 records/2023-05-20 (AMPD, FGDL, OAKU, PEMX, VTS/I, ZTAX)
-- 2 records/2023-05-20 (ATMU, VTS/I)
-- 3 records/2023-06-10 (NPWR, RMIF, VTS/I)
-- 3 records/2023-06-17 (AZTR, VTS/I, WKC)
-- 5 records/2023-06-24 (BILZ, HCMT, IBDY, LH/I, VTS/I)
-- 7 records/2023-07-01 (AENT, ALCY, BDVG, IVVB, IVVM, LH/I, VTS/I)
-- 3 records/2023-07-08 (LH/I, MUSQ, VTS/I)
-- 2 records/2023-07-15 (LH/I, VTS/I)
-- 3 records/2023-07-15 (ESHA, LH/I, VTS/I)
-- 7 records/2023-08-05 (FMST, LDWY, LH/I, LLYVA, LLYVK, MGOV, VTS/I)
-- 3 records/2023-08-12 (FMST, LH/I, VTS/I)
-- 8 records/2023-09-16 (BGIG, CDP, CNFRZ, HYAC, KVAC, LH/I, SHOT, VTS/I)
-- 6 records/2023-09-30 (ANL, ARMK/I, BTCT, CNFRZ, LH/I, VTS/I)
-- 18 records/2023-10-07
-- 5 records/2023-10-14 (ARMK/I, CNFRZ, LH/I, NNAG, VTS/I)
-- 16 records/2023-10-21
-- 11 records/2023-10-28
-- 6 records/2023-11-04

-- ============================================
select Exchange, TvType, TvSubtype, count(*) Recs, min(symbol) MinSymbol, max(symbol) MaxSymbol, min([timestamp]) MinCreated
from SymbolsEoddata group by Exchange, TvType, TvSubtype order by 1,2;
-- 38 records/2023-01-15
-- 36 records/2023-04-01
-- 37 records/2023-04-29
-- 39 records/2023-11-18
-- 37 records/2023-11-25
-- 39 records/2023-12-02
-- 37 records/2023-12-09
-- 39 records/2023-12-16
-- 37 records/2023-12-23
-- 39 records/2024-01-20
-- 37 records/2024-01-27

select TvType, TvSubtype, count(*) Recs, min(symbol) MinSymbol, max(symbol) MaxSymbol, min(Exchange) MinExchange, Max(Exchange) MaxExchange,
min([timestamp]) MinCreated
from SymbolsEoddata group by TvType, TvSubtype order by 1,2;
-- 13 records/2023-01-15
-- 14 records/2023-04-29
-- 15 records/2023-11-18
-- 14 records/2023-11-25
-- 15 records/2023-12-02
-- 14 records/2023-12-09
-- 15 records/2023-12-16
-- 14 records/2023-12-23
-- 15 records/2024-01-20
-- 14 records/2024-01-27

select * from SymbolsEoddata -- 12746 records/2023-01-15, 12875/2023-02-18
select * from ScreenerTradingView -- 10775 records/2023-01-15, 10923/2023-02-18

