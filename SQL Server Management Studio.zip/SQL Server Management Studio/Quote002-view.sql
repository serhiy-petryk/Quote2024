select * from (
select a.*,
(p1.[Close]+p2.[Close]+p3.[Close]+p4.[Close]+p5.[Close]+p6.[Close]+p7.[Close])/7.0 as AverCL, 
(p1.[Volume]+p2.[Volume]+p3.[Volume]+p4.[Volume]+p5.[Volume]+p6.[Volume]+p7.[Volume])/7.0 as AverVOL,
p1.[Open] Open_P1, p1.High High_P1, p1.Low Low_P1, p1.[Close] Close_P1, p1.Volume Volume_P1, 
n1.[Open] Open_N1, n1.High High_N1, n1.Low Low_N1, n1.[Close] Close_N1, n1.Volume Volume_N1
-- select count(*)
from vDayYahoo2013 a

inner join TradingDays d on d.Date=a.Date
inner join vDayYahoo2013 p1 on p1.Symbol=a.Symbol and p1.Date=d.Prev1
inner join vDayYahoo2013 p2 on p2.Symbol=a.Symbol and p2.Date=d.Prev2
inner join vDayYahoo2013 p3 on p3.Symbol=a.Symbol and p3.Date=d.Prev3
inner join vDayYahoo2013 p4 on p4.Symbol=a.Symbol and p4.Date=d.Prev4
inner join vDayYahoo2013 p5 on p5.Symbol=a.Symbol and p5.Date=d.Prev5
inner join vDayYahoo2013 p6 on p6.Symbol=a.Symbol and p6.Date=d.Prev6
inner join vDayYahoo2013 p7 on p7.Symbol=a.Symbol and p7.Date=d.Prev7

inner join vDayYahoo2013 n1 on n1.Symbol=a.Symbol and n1.Date=d.Next1

where a.[Close] >=5 and a.Volume > 300000
and (a.High - a.[Low]) between 0.05*a.[Close] and 0.1*a.[Close]
--and a.High - a.[close] between 0.1*a.[Close] and 0.15*a.[Close]
and (a.[Open] - a.Low) < 0.1 * (a.High - a.[Low])
and (a.[High] - a.[Close]) < 0.1 * (a.High - a.[Low])
and (p1.[High] - p1.[Close]) < 0.1 * (a.High - a.[Low])
and abs(a.[Open] - p1.[Close]) < 0.1 * (a.High - a.[Low])
) x

where Volume > 1.2 * AverVOL and [Close] < AverCl

