-- Missing index + Nasdaq Screener
select distinct symbol from (
select 'MTL-P' symbol union all
select distinct replace(replace(a.Symbol, '^', '-P-'), '/', '-P-') Symbol from 
(select symbol, exchange, count(*) recs from [HScreenerNasdaqStockAll]
where volume*LastSale>=5
group by symbol, exchange
) a
left join dbQuote2022..SymbolsEoddata b on a.Symbol=b.NasdaqSymbol
where b.Symbol is null
and a.Symbol not like '%^'
UNION ALL
select distinct replace(a.Symbol,'.','-P-') from 
(select * from indices where deleted is null or deleted>'2020-01-01') a
left join dbQuote2022..SymbolsEoddata b on a.Symbol=b.TradingViewSymbol
where b.Symbol is null
--and a.Symbol not like '[A-Z]' and a.Symbol not like '[A-Z][A-Z]' and a.Symbol not like '[A-Z][A-Z][A-Z]' and a.Symbol not like '[A-Z][A-Z][A-Z][A-Z]' and a.Symbol not like '[A-Z][A-Z][A-Z][A-Z][A-Z]' 
) x
order by 1

-- Missing Nasdaq screener
-- 973
select 'MTL-P' symbol union all
select distinct replace(replace(a.Symbol, '^', '-P-'), '/', '-P-') Symbol from 
(select symbol, exchange, count(*) recs from [HScreenerNasdaqStockAll]
where volume*LastSale>=5
group by symbol, exchange
) a
left join dbQuote2022..SymbolsEoddata b on a.Symbol=b.NasdaqSymbol
where b.Symbol is null
and a.Symbol not like '%^'
-- and a.Symbol not like '[A-Z]' and a.Symbol not like '[A-Z][A-Z]' and a.Symbol not like '[A-Z][A-Z][A-Z]' and a.Symbol not like '[A-Z][A-Z][A-Z][A-Z]' and a.Symbol not like '[A-Z][A-Z][A-Z][A-Z][A-Z]' 
-- and a.Symbol not like '%^[A-Z]'
order by 1

select symbol, exchange, count(*) from [HScreenerNasdaqStockAll]
where volume*LastSale>=5
group by symbol, exchange
order by 1,2

-- Missing indices
select distinct replace(a.Symbol,'.','-') from 
(select * from indices where deleted is null or deleted>'2020-01-01') a
left join dbQuote2022..SymbolsEoddata b on a.Symbol=b.TradingViewSymbol
where 
b.Symbol is null
order by 1

-- Missing by trading value
select distinct a.AlphaVantageSymbol
from (select b.AlphaVantageSymbol, count(*) recs from dbQuote2022..DayEoddata a
inner join dbQuote2022..SymbolsEoddata b on a.Symbol=b.Symbol and a.Exchange=b.Exchange
where [close]*volume>=5000000 and b.AlphaVantageSymbol is not null
group by b.AlphaVantageSymbol) a
left join (select symbol from FileLogMinuteAlphaVantage where [file] like '%Y2%' group by symbol) b on a.AlphaVantageSymbol=b.Symbol
where b.Symbol is null
order by 1

/*a.Symbol not like '[A-Z]' and a.Symbol not like '[A-Z][A-Z]'
and a.Symbol not like '[A-Z][A-Z][A-Z]' and a.Symbol not like '[A-Z][A-Z][A-Z][A-Z]'
and a.Symbol not like '[A-Z][A-Z][A-Z][A-Z][A-Z]'*/

select * from dbQuote2022..SymbolsEoddata where symbol like 'JW%'

select * from indices a 
where deleted is null or deleted>'2020-01-01'
--[Timestamp] >'2020-01-01'
a.Symbol not like '[A-Z]' and a.Symbol not like '[A-Z][A-Z]'
and a.Symbol not like '[A-Z][A-Z][A-Z]' and a.Symbol not like '[A-Z][A-Z][A-Z][A-Z]'
and a.Symbol not like '[A-Z][A-Z][A-Z][A-Z][A-Z]'

