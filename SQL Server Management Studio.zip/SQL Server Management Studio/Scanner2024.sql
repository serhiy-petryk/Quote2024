use dbQ2023Others

-- Define start/end entry point from xx_scanner table
select * from xx_scanner where [open]>high or [open]<low or [close]>high or [close]<low
select min([Date]), max(Date), count(*) from xx_scanner

SELECT [From], [To], count(*) Recs,
sum (iif([Open]>(High-0.00995),1,0)) HighCount,
sum (iif([Open]>(High-0.00995),[Open]-[Final],-0.01)) HighAmt,
avg (iif([Open]>(High-0.00995),([Open]-[Final])/[Open],-0.01/[Open]))*100.0 HighAmtPerc,
sum (iif([Open]<(Low+0.00995),1,0)) LowCount,
sum (iif([Open]<(Low+0.00995),[Final]-[Open],-0.01)) LowAmt,
avg (iif([Open]<(Low+0.00995),([Final]-[Open])/[Open],-0.01/[Open]))*100.0 LowAmtPerc,
sum (iif([Open]>(High-0.00995),1.0,0.0))/count(*)*100 HighCountPerc,
sum (iif([Open]<(Low+0.00995),1.0,0.0))/count(*)*100 LowCountPerc
FROM [dbQ2023Others].[dbo].[xx_scanner]
where finaltime is not null and [Open]>5.0 and Final is not null
group by [From], [To]
order by 2,1

SELECT [From], count(*) Recs,
sum (iif([Open]>(High-0.00995),1,0)) HighCount,
sum (iif([Open]>(High-0.00995),[Open]-[Final],-0.01)) HighAmt,
avg (iif([Open]>(High-0.00995),([Open]-[Final])/[Open],-0.01/[Open]))*100.0 HighAmtPerc,
sum (iif([Open]<(Low+0.00995),1,0)) LowCount,
sum (iif([Open]<(Low+0.00995),[Final]-[Open],-0.01)) LowAmt,
avg (iif([Open]<(Low+0.00995),([Final]-[Open])/[Open],-0.01/[Open]))*100.0 LowAmtPerc,
sum (iif([Open]>(High-0.00995),1.0,0.0))/count(*)*100 HighCountPerc,
sum (iif([Open]<(Low+0.00995),1.0,0.0))/count(*)*100 LowCountPerc
FROM [dbQ2023Others].[dbo].[xx_scanner]
where finaltime is not null and [Open]>5 and Final is not null
group by [From]
order by 1

SELECT [To], count(*) Recs,
sum (iif([Open]>(High-0.00995),1,0)) HighCount,
sum (iif([Open]>(High-0.00995),[Open]-[Final],-0.01)) HighAmt,
avg (iif([Open]>(High-0.00995),([Open]-[Final])/[Open],-0.01/[Open]))*100.0 HighAmtPerc,
sum (iif([Open]<(Low+0.00995),1,0)) LowCount,
sum (iif([Open]<(Low+0.00995),[Final]-[Open],-0.01)) LowAmt,
avg (iif([Open]<(Low+0.00995),([Final]-[Open])/[Open],-0.01/[Open]))*100.0 LowAmtPerc,
sum (iif([Open]>(High-0.00995),1.0,0.0))/count(*)*100 HighCountPerc,
sum (iif([Open]<(Low+0.00995),1.0,0.0))/count(*)*100 LowCountPerc
FROM [dbQ2023Others].[dbo].[xx_scanner]
where finaltime is not null and [Open]>5 and Final is not null
group by [To]
order by 1

--=====================
-- Analyze dbQ2024..HourPolygon
--=====================
-- One hour
select [Time],[To], count(*) Recs,
sum (iif([Open]>(High-0.00995),1,0)) HighCount,
sum (iif([Open]>(High-0.00995),[Open]-[Close],-0.01)) HighAmt,
avg (iif([Open]>(High-0.00995),([Open]-[Close])/[Open],-0.01/[Open]))*100.0 HighAmtPerc,
sum (iif([Open]<(Low+0.00995),1,0)) LowCount,
sum (iif([Open]<(Low+0.00995),[Close]-[Open],-0.01)) LowAmt,
avg (iif([Open]<(Low+0.00995),([Close]-[Open])/[Open],-0.01/[Open]))*100.0 LowAmtPerc,
sum (iif([Open]>(High-0.00995),1.0,0.0))/count(*)*100 HighCountPerc,
sum (iif([Open]<(Low+0.00995),1.0,0.0))/count(*)*100 LowCountPerc
from dbQ2024..HourPolygon
where [Open] >5 and year(date)=2022 and time<>'09:30:00'
group by [Time],[To]
order by 1,2

select high-[open],
iif([Open]>(High-0.00995),[Open]-[Close],-0.01) HighAmt,
[Open]-ROUND(High-0.01,4), iif([Open]>(High-0.01001),1,0) HighCount,
dbo.AmountUp([Open], [High], [Close], 0.01) xx, 
dbo.AmountUp([Open], [High], [CloseAtAverage], 0.01) xx1, *
from dbQ2024..HourPolygon
where [Open] >5 and year(date)=2023 and time<>'09:30:00' and Average>[Open] and CloseAtAverage is not null
-- and iif([High]<=([Open] +0.009999),-0.01, [Open]-[Close])<> dbo.AmountUp([Open], [High], [Close], 0.01)
-- and Symbol='A'
order by [high]-[open], Symbol, Date, Time

select -0.01+0.00005
-- 0.00995

-- Two hours
select a1.[Time], a2.[To], count(*) Recs,
sum (iif(a1.[Open]>(a1.High-0.00995) and a1.[Open]>(a2.High-0.00995),1,0)) HighCount,
sum (iif(a1.[Open]>(a1.High-0.00995) and a1.[Open]>(a2.High-0.00995),a1.[Open]-a2.[Close],-0.01)) HighAmt,
avg (iif(a1.[Open]>(a1.High-0.00995) and a1.[Open]>(a2.High-0.00995),(a1.[Open]-a2.[Close])/a1.[Open],-0.01/a1.[Open]))*100.0 HighAmtPerc,
sum (iif(a1.[Open]<(a1.Low+0.00995) and a1.[Open]<(a2.Low+0.00995),1,0)) LowCount,
sum (iif(a1.[Open]<(a1.Low+0.00995) and a1.[Open]<(a2.Low+0.00995),a2.[Close]-a1.[Open],-0.01)) LowAmt,
avg (iif(a1.[Open]<(a1.Low+0.00995) and a1.[Open]<(a2.Low+0.00995),(a2.[Close]-a1.[Open])/a1.[Open],-0.01/a1.[Open]))*100.0 LowAmtPerc,
sum (iif(a1.[Open]>(a1.High-0.00995) and a1.[Open]>(a2.High-0.00995),1.0,0.0))/count(*)*100 HighCountPerc,
sum (iif(a1.[Open]<(a1.Low+0.00995) and a1.[Open]<(a2.Low+0.00995),1.0,0.0))/count(*)*100 LowCountPerc
from dbQ2024..HourPolygon a1
inner join dbQ2024..HourPolygon a2 on a1.Symbol=a2.Symbol and a1.Date=a2.Date and a1.[To]=a2.[Time]
where a1.[Open] >5 and year(a1.date)=2022 and a1.time<>'09:30:00'
group by a1.[Time],a2.[To]
order by 1,2

--=====================
-- dbQ2024..HourPolygon: CloseAtAverage
--=====================
-- One hour
select [Time],[To], count(*) Recs,
sum (iif([Open]>(CloseAtAverage-0.00995),1,0)) HighCount,
sum (iif([Open]>(CloseAtAverage-0.00995),[Open]-[CloseAtAverage],-0.01)) HighAmt,
avg (iif([Open]>(CloseAtAverage-0.00995),([Open]-[CloseAtAverage])/[Open],-0.01/[Open]))*100.0 HighAmtPerc,
--sum (iif([Open]<(Low+0.00995),1,0)) LowCount,
--sum (iif([Open]<(Low+0.00995),[Close]-[Open],-0.01)) LowAmt,
--avg (iif([Open]<(Low+0.00995),([Close]-[Open])/[Open],-0.01/[Open]))*100.0 LowAmtPerc,
sum (iif([Open]>(CloseAtAverage-0.00995),1.0,0.0))/count(*)*100 HighCountPerc
--sum (iif([Open]<(Low+0.00995),1.0,0.0))/count(*)*100 LowCountPerc
from dbQ2024..HourPolygon
where [Open] >5 and year(date)=2023 and time<>'09:30:00' and PrevAverage>([Open]+0.5)
group by [Time],[To]
order by 1,2

select [Time],[To], count(*) Recs,
sum (iif([Open]<(CloseAtAverage+0.00995),1,0)) LowCount,
sum (iif([Open]<(CloseAtAverage+0.00995),[CloseAtAverage]-[Open],-0.01)) LowAmt,
avg (iif([Open]<(CloseAtAverage+0.00995),([CloseAtAverage]-[Open])/[Open],-0.01/[Open]))*100.0 LowAmtPerc,
sum (iif([Open]<(CloseAtAverage+0.00995),1.0,0.0))/count(*)*100 LowCountPerc
from dbQ2024..HourPolygon
where [Open] >5 and year(date)=2023 and time<>'09:30:00' and Average<([Open]-0.1)
group by [Time],[To]
order by 1,2

select [Time],[To], count(*) Recs,
sum (iif([Open]<(CloseAtAverage+0.00995),1,0)) LowCount,
sum (iif([Open]<(CloseAtAverage+0.00995),[CloseAtAverage]-[Open],-0.01)) LowAmt,
avg (iif([Open]<(CloseAtAverage+0.00995),([CloseAtAverage]-[Open])/[Open],-0.01/[Open]))*100.0 LowAmtPerc,
sum (iif([Open]<(CloseAtAverage+0.00995),1.0,0.0))/count(*)*100 LowCountPerc
from dbQ2024..HourPolygon
where [Open] >5 and year(date)=2023 and time<>'09:30:00' and PrevAverage<([Open]-0.1)
group by [Time],[To]
order by 1,2

select [Time],[To], count(*) Recs,
sum (iif([Open]<(CloseAtAverage+0.00995),1,0)) LowCount,
sum (iif([Open]<(CloseAtAverage+0.00995),[CloseAtAverage]-[Open],-0.01)) LowAmt,
avg (iif([Open]<(CloseAtAverage+0.00995),([CloseAtAverage]-[Open])/[Open],-0.01/[Open]))*100.0 LowAmtPerc,
sum (iif([Open]<(CloseAtAverage+0.00995),1.0,0.0))/count(*)*100 LowCountPerc
from dbQ2024..HourPolygon
where [Open] >5 and year(date)=2023 and time<>'09:30:00' and PrevAverage<([Average]-0.1) and Average<([Open]-0.1)
group by [Time],[To]
order by 1,2

select top 10000
([Open] -PrevAverage)/[Open]*100, 
iif([Open]<(CloseAtAverage+0.00995),1,0) LowCount,
iif([Open]<(CloseAtAverage+0.00995),[CloseAtAverage]-[Open],-0.01) LowAmt,
iif([Open]<(CloseAtAverage+0.00995),([CloseAtAverage]-[Open])/[Open],-0.01/[Open])*100.0 LowAmtPerc,
--iif([Open]<(CloseAtAverage+0.00995),1.0,0.0)/count(*)*100 LowCountPerc
* from dbQ2024..HourPolygon
where [Open] >5 and year(date)=2023 and time<>'09:30:00' and PrevAverage<Average and Average<[Open] and PrevAverage<>0
order by 1 desc

