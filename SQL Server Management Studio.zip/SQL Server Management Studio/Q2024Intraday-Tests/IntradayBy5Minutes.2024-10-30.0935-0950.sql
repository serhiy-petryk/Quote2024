
;with data as
(
select (PrevHigh-PrevLow)/(PrevHigh+PrevLow)*200.0 PrevHL, * from (
	select O0935 PrevOpen, C0950 PrevClose,
	dbQ2024.dbo.Max(H0935, dbQ2024.dbo.Max(H0940, dbQ2024.dbo.Max(H0945, H0950))) PrevHigh,
	dbQ2024.dbo.Min(L0935, dbQ2024.dbo.Min(L0940, dbQ2024.dbo.Min(L0945, L0950))) PrevLow,
	((H0935+L0935)*V0935+(H0940+L0940)*V0940+(H0945+L0945)*V0945+(H0950+L0950)*V0950)/2000000/4 PrevTurnover,
	 (N0935+N0940+N0945+N0950)/4 PrevTradeCount,
	 O0955 [Open], C0955[Close], *
	 from dbQ2024MinuteScanner..IntradayBy5Minutes a 
	where O0935 is not null and O0940 is not null and O0945 is not null and O0950 is not null) x
WHERE PrevTurnover>1.0 and PrevTradeCount>200 and [Open]>5.0
),
	data2 as (
       SELECT * FROM data 
--	   WHERE [Open]>0.95*PrevHigh
--	   WHERE [Open]<1.05*PrevLow -- and PrevOpen<PrevClose
	WHERE O0935<O0940 and O0940<O0945 and O0945<O0950 and O0950<O0955 and C0950<O0955
	and (H0950-L0950)>(H0945-L0945)
--	WHERE O0935>=O0940 and O0940>=O0945 and O0945>=O0950 -- and O0950>O0955
--		WHERE O0930 is not null and O0930>=O0935 and O0935<=O0940 and O0940<=O0945 and O0945<=O0950 -- and O0950>O0955
--		WHERE O0940<=O0945 and O0945<=O0950
-- 		WHERE O0940>=O0945 and O0945>=O0950 and O0955<1.05*PrevLow
-- 		WHERE O0930 is not null and O0930>=O0935 and O0935>=O0940 and O0940>=O0945 and O0945>=O0950
	),
	data3 as (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date ORDER BY PrevHL DESC), *
	   FROM data2
	)

-- select * from data3;
 select year(date) Year,
 cast(ROUND(avg(([Open]-[Close])/[Open]*100),4) as real) Profit,
 cast(ROUND(sum(iif ([Open]>[Close],1.00,0.00))/count(*)*100,2) as real) Cnt,
 cast(ROUND(sum(iif ([O0955]>[O1000],1.0,0.0))/count(*)*100,2) as real) Cnt1000,
cast(ROUND(sum(iif ([O0955]>[O1005],1.0,0.0))/count(*)*100,2) as real) Cnt1005,
cast(ROUND(sum(iif ([O0955]>[O1010],1.0,0.0))/count(*)*100,2) as real) Cnt1010,
cast(ROUND(avg(([O0955]-[O1000])/[O0955]*100),4) as real) Profit1000,
cast(ROUND(avg(([O0955]-[O1005])/[O0955]*100),4) as real) Profit1005,
cast(ROUND(avg(([O0955]-[O1010])/[O0955]*100),4) as real) Profit1010,
cast(ROUND(avg([Open]/[Close]),4) as real) OpenToClose,
count(*) Recs from data3
WHERE RN<=5 and PrevHL>5 group by year(date) order by 1 desc -- and [Open]<[Close]
