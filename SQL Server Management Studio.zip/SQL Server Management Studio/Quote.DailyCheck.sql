select min(date), max(date), count(*) from DayYahoo2013;
--2010-01-04	2013-09-06	6944435
select distinct symbol from DayYahoo2013; -- 9500

select min(date), max(date), count(*)  from DayYahoo
where date between '2010-01-04' and '2013-09-06';
-- 2010-01-04	2013-09-06	2910593
select distinct symbol from DayYahoo
where date between '2010-01-04' and '2013-09-06'; -- 3423

select b.Exchange, min(date), max(date), count(*) from DayYahoo2013 a
inner join SymbolsEoddata2013 b on a.Symbol=b.Symbol
group by b.Exchange;

select distinct a.Symbol, count(*) from DayYahoo2013 a
left join SymbolsEoddata2013 b on a.Symbol=b.Symbol
where b.Symbol is null
and a.Symbol not like '%.%'
group by a.Symbol; -- 727 recs (ABBV)

select distinct a.Symbol, count(*) from DayYahoo2013 a
left join SymbolsEoddata2013 b on a.Symbol=b.Symbol
where b.Symbol is null
and a.Symbol not like '%.%'
group by a.Symbol; -- 228 recs (ABII)

select distinct a.Symbol, count(*) from DayYahoo2013 a
left join SymbolsNanex2013 b on a.Symbol=b.Symbol
where b.Symbol is null
-- and a.Symbol not like '%.%'
group by a.Symbol; -- 0 recs

select symbol, count(*) from SymbolsEoddata2013
group by Symbol having count(*)<>1;

-- =========================
select count(*)
from DayYahoo a inner join DayYahoo2013 b on a.Symbol=b.Symbol and a.Date=b.Date; -- 2422536

select count(*)
from (select * from DayYahoo where date between '2010-01-04' and '2013-09-06') a
left join DayYahoo2013 b on a.Symbol=b.Symbol and a.Date=b.Date
where b.Symbol is null; -- 488057

select distinct a.symbol
from (select * from DayYahoo where date between '2010-01-04' and '2013-09-06') a
left join DayYahoo2013 b on a.Symbol=b.Symbol and a.Date=b.Date
where b.Symbol is null; -- 735 symbols

select distinct a.symbol
from DayYahoo2013 a
left join (select * from DayYahoo where date between '2010-01-04' and '2013-09-06') b on a.Symbol=b.Symbol and a.Date=b.Date
where b.Symbol is null; -- 6676 symbols

select * from 
SymbolsNanex2013 x 
inner join (select distinct a.symbol
from DayYahoo2013 a
left join (select * from DayYahoo where date between '2010-01-04' and '2013-09-06') b on a.Symbol=b.Symbol and a.Date=b.Date
where b.Symbol is null) y on x.Symbol=y.Symbol order by x.Symbol


select * from DayYahoo2013 where symbol='AAIT'