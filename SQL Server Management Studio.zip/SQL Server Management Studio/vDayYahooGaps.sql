INSERT into DayYahooGaps (Symbol, Date, [Close], PrevClose)
select a.Symbol, a.Date, p1.[Close] PrevClose, a.[Close]
-- into DayYahooGaps
from DayYahoo a
inner join (select * from TradingDays where Prev7 is not null and Next5 is not null) b on a.Date=b.Date
inner join DayYahoo p1 on a.Symbol=p1.Symbol and b.Prev1=p1.Date
where (p1.[Close]*1.2<=a.Low or p1.[Close]*0.8>=a.High);

drop view vDayYahooGaps;

create view vDayYahooGaps as
select -- count(*)
YEAR(a.Date) Year, a.Symbol, a.Date, p1.[Close] PrevClose,
a.[Open], a.High, a.Low, a.[Close], a.Volume,
n1.[Open] D1_O, n1.High D1_H, n1.Low D1_L, n1.[Close] D1_CL, n1.Volume D1_Vol,
n2.[Open] D2_O, n2.High D2_H, n2.Low D2_L, n2.[Close] D2_CL, n2.Volume D2_Vol,
n3.[Open] D3_O, n3.High D3_H, n3.Low D3_L, n3.[Close] D3_CL, n3.Volume D3_Vol,
n4.[Open] D4_O, n4.High D4_H, n4.Low D4_L, n4.[Close] D4_CL, n4.Volume D4_Vol,
n5.[Open] D5_O, n5.High D5_H, n5.Low D5_L, n5.[Close] D5_CL, n5.Volume D5_Vol,

(p1.[Close] + isnull(p2.[Close],0) + isnull(p3.[Close],0) + isnull(p4.[Close],0) + isnull(p5.[Close],0) + isnull(p6.[Close],0) + isnull(p7.[Close],0))/
(1 + case when p2.[Close] is null then 0 else 1 end + case when p3.[Close] is null then 0 else 1 end +
 case when p4.[Close] is null then 0 else 1 end + case when p5.[Close] is null then 0 else 1 end +
 case when p6.[Close] is null then 0 else 1 end + case when p7.[Close] is null then 0 else 1 end)
 AverCL,

(p1.Volume*1.0 + isnull(p2.Volume,0) + isnull(p3.Volume,0) + isnull(p4.Volume,0) + isnull(p5.Volume,0) + isnull(p6.Volume,0) + isnull(p7.Volume,0))/
(1 + case when p2.volume is null then 0 else 1 end + case when p3.volume is null then 0 else 1 end +
case when p4.volume is null then 0 else 1 end + case when p5.volume is null then 0 else 1 end +
case when p6.volume is null then 0 else 1 end + case when p7.volume is null then 0 else 1 end) AverVOL,
-- p1.Volume P1_V, p2.Volume P2_V, p3.Volume P3_V, p4.Volume P4_V, p5.Volume P5_V, p6.Volume P6_V, p7.Volume P7_V
n1.[Open]/n1.[Close] D1C, n1.[Open]/n2.[Close] D2C, n1.[Open]/n3.[Close] D3C, n1.[Open]/n4.[Close] D4C, n1.[Open]/n5.[Close] D5C,
(n4.[Close]-n1.[Open])/n1.[Open]*100.0 Profit,
1.0*a.[Close]/p1.[Close] ClToPrevCl,
1.0*a.[Volume]/p1.[Volume] VolToPrevVol,
case when g.PrevClose < g.[Close] then (a.Low-g.PrevClose)/g.PrevClose * 100 else (a.High-g.PrevClose)/g.PrevClose * 100 end Gap

from DayYahooGaps g
inner join DayYahoo a on a.Symbol=g.Symbol and a.Date=g.Date
inner join (SELECT * from TradingDays WHERE Prev7 is not null and Next5 is not null) b on g.Date=b.Date

left join DayYahoo p1 on g.Symbol=p1.Symbol and b.Prev1=p1.Date
left join DayYahoo p2 on g.Symbol=p2.Symbol and b.Prev2=p2.Date
left join DayYahoo p3 on g.Symbol=p3.Symbol and b.Prev3=p3.Date
left join DayYahoo p4 on g.Symbol=p4.Symbol and b.Prev4=p4.Date
left join DayYahoo p5 on g.Symbol=p5.Symbol and b.Prev5=p5.Date
left join DayYahoo p6 on g.Symbol=p6.Symbol and b.Prev6=p6.Date
left join DayYahoo p7 on g.Symbol=p7.Symbol and b.Prev7=p7.Date

left join DayYahoo n1 on g.Symbol=n1.Symbol and b.Next1=n1.Date
left join DayYahoo n2 on g.Symbol=n2.Symbol and b.Next2=n2.Date
left join DayYahoo n3 on g.Symbol=n3.Symbol and b.Next3=n3.Date
left join DayYahoo n4 on g.Symbol=n4.Symbol and b.Next4=n4.Date
left join DayYahoo n5 on g.Symbol=n5.Symbol and b.Next5=n5.Date
where n1.[Open]>=0.01 and g.[PrevClose]>0.01 and p1.Volume>0;


select count(*)
/* top 5 a.Symbol, a.Date, p1.[Close] PrevClose,
a.[Open], a.High, a.Low, a.[Close], a.Volume,
n1.[Open] D1_O, n1.High D1_H, n1.Low D1_L, n1.[Close] D1_CL, n1.Volume D1_Vol,
n2.[Open] D2_O, n2.High D2_H, n2.Low D2_L, n2.[Close] D2_CL, n2.Volume D2_Vol,
n3.[Open] D3_O, n3.High D3_H, n3.Low D3_L, n3.[Close] D3_CL, n3.Volume D3_Vol,
n4.[Open] D4_O, n4.High D4_H, n4.Low D4_L, n4.[Close] D4_CL, n4.Volume D4_Vol,
n5.[Open] D5_O, n5.High D5_H, n5.Low D5_L, n5.[Close] D5_CL, n5.Volume D5_Vol,

(p1.[Close] + isnull(p2.[Close],0) + isnull(p3.[Close],0) + isnull(p4.[Close],0) + isnull(p5.[Close],0) + isnull(p6.[Close],0) + isnull(p7.[Close],0))/
(1 + case when p2.[Close] is null then 0 else 1 end + case when p3.[Close] is null then 0 else 1 end +
 case when p4.[Close] is null then 0 else 1 end + case when p5.[Close] is null then 0 else 1 end +
 case when p6.[Close] is null then 0 else 1 end + case when p7.[Close] is null then 0 else 1 end)
 AverCL,

(p1.Volume*1.0 + isnull(p2.Volume,0) + isnull(p3.Volume,0) + isnull(p4.Volume,0) + isnull(p5.Volume,0) + isnull(p6.Volume,0) + isnull(p7.Volume,0))/
(1 + case when p2.volume is null then 0 else 1 end + case when p3.volume is null then 0 else 1 end +
case when p4.volume is null then 0 else 1 end + case when p5.volume is null then 0 else 1 end +
case when p6.volume is null then 0 else 1 end + case when p7.volume is null then 0 else 1 end) AverVOL,
p1.Volume P1_V, p2.Volume P2_V, p3.Volume P3_V, p4.Volume P4_V, p5.Volume P5_V, p6.Volume P6_V, p7.Volume P7_V*/

from DayYahoo a
inner join (select * from TradingDays where Prev7 is not null and Next5 is not null) b on a.Date=b.Date

left join DayYahoo p1 on a.Symbol=p1.Symbol and b.Prev1=p1.Date
left join DayYahoo p2 on a.Symbol=p2.Symbol and b.Prev2=p2.Date
left join DayYahoo p3 on a.Symbol=p3.Symbol and b.Prev3=p3.Date
left join DayYahoo p4 on a.Symbol=p4.Symbol and b.Prev4=p4.Date
left join DayYahoo p5 on a.Symbol=p5.Symbol and b.Prev5=p5.Date
left join DayYahoo p6 on a.Symbol=p6.Symbol and b.Prev6=p6.Date
left join DayYahoo p7 on a.Symbol=p7.Symbol and b.Prev7=p7.Date

left join DayYahoo n1 on a.Symbol=n1.Symbol and b.Next1=n1.Date
left join DayYahoo n2 on a.Symbol=n2.Symbol and b.Next2=n2.Date
left join DayYahoo n3 on a.Symbol=n3.Symbol and b.Next3=n3.Date
left join DayYahoo n4 on a.Symbol=n4.Symbol and b.Next4=n4.Date
left join DayYahoo n5 on a.Symbol=n5.Symbol and b.Next5=n5.Date

/*inner join DayYahoo p1 on a.Symbol=p1.Symbol and b.Prev1=p1.Date
inner join DayYahoo p2 on a.Symbol=p2.Symbol and b.Prev2=p2.Date
inner join DayYahoo p3 on a.Symbol=p3.Symbol and b.Prev3=p3.Date
inner join DayYahoo p4 on a.Symbol=p4.Symbol and b.Prev4=p4.Date
inner join DayYahoo p5 on a.Symbol=p5.Symbol and b.Prev5=p5.Date
inner join DayYahoo p6 on a.Symbol=p6.Symbol and b.Prev6=p6.Date
inner join DayYahoo p7 on a.Symbol=p7.Symbol and b.Prev7=p7.Date

inner join DayYahoo n1 on a.Symbol=n1.Symbol and b.Next1=n1.Date
inner join DayYahoo n2 on a.Symbol=n2.Symbol and b.Next2=n2.Date
inner join DayYahoo n3 on a.Symbol=n3.Symbol and b.Next3=n3.Date
inner join DayYahoo n4 on a.Symbol=n4.Symbol and b.Next4=n4.Date
inner join DayYahoo n5 on a.Symbol=n5.Symbol and b.Next5=n5.Date*/

where p1.[Close]*1.2<a.Low 
