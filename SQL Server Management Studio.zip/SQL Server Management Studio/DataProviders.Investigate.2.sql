select substring(symbol, charindex('.', symbol), 20), count(*) from DayFmpCloud
where symbol like '%.%'
and symbol not like '^%'
group by substring(symbol, charindex('.', symbol), 20)
order by 1

select substring(symbol, charindex('.', symbol), 20), count(*),
min(a.ExchangeShortName), max(a.ExchangeShortName)
from SymbolsFmpCloud a
inner join ExchangesFmpCloud b on b.Exchange=a.Exchange
where symbol like '%.%'
and symbol not like '^%'
and symbol not like '%&%'
-- and b.Live=1
group by substring(symbol, charindex('.', symbol), 20)
order by 1

select *
from SymbolsFmpCloud a
inner join ExchangesFmpCloud b on b.Exchange=a.Exchange
where symbol like '%.%'
and symbol not like '^%' and b.Live=1
order by 1

-- Missing symbols
select a.Symbol, count(*), min(a.Date), max(a.Date)
from DayFmpCloud a
left join SymbolsFmpCloud b on a.Symbol=b.Symbol
where b.Symbol is null
group by a.Symbol order by 1

-- 68848
select * from SymbolsFmpCloud
select * from dbQuote2022..SymbolsFmpCloud -- 46994

select *
from SymbolsFmpCloud a
where a.Symbol like 'AACQ%'

select * from DayFmpCloud where symbol like '%.NYB'

-- truncate table DayFmpCloud

-- 3198846/1921778(minus other) 
select count(*) from DayFmpCloud

-- Missing symbols by year
select a.year, count(*) Recs, 
sum(case when b.Symbol is null then 1 else 0 end) Missing
from (select symbol, YEAR(date) year from DayFmpCloud
where [Close]*[Volume]>5000000 group by symbol, YEAR(date)) a
left join SymbolsFmpCloud b on a.Symbol=b.Symbol
where a.Symbol not like '^%' and a.Symbol not like '%.%'
group by a.year order by 1


select *
from DayFmpCloud a
left join SymbolsFmpCloud b on a.Symbol=b.Symbol
where b.Symbol is null and a.Symbol not like '^%'  and a.Symbol not like '%.%' 
and YEAR(a.date)=2021

