-- High/Low
select round(a.High-b.High,2) H1, round(b.Low-a.Low,2) L1, b.Volume/a.Volume V1, a.*, b.[Open], b.High, b.Low, b.[Close], b.Volume
from (select * from DayEoddata WHERE volume<>0) a
inner join FileLogMinuteYahoo b on a.Symbol=b.Symbol and a.Date=b.Date
inner join vSymbolsAndDatesLive c on a.Symbol=c.Symbol and a.Exchange=c.Exchange and a.Date=c.Date
where 
abs((a.High-b.High)/a.High)>0.001 or abs((a.Low-b.Low)/a.Low)>0.001;

select round(a.High-b.High,2) H1, round(b.Low-a.Low,2) L1, b.Volume/a.Volume V1, a.*, b.[Open], b.High, b.Low, b.[Close], b.Volume
from (select * from DayEoddata WHERE volume<>0) a
inner join FileLogMinuteAlphaVantage b on a.Symbol=b.Symbol and a.Date=b.Date
inner join vSymbolsAndDatesLive c on a.Symbol=c.Symbol and a.Exchange=c.Exchange and a.Date=c.Date
where a.Date>='2023-02-06' and b.[File] like 'MinuteAlphaVantage_20230211\%' and
(abs((a.High-b.High)/a.High)>0.001 or abs((a.Low-b.Low)/a.Low)>0.001);

-- Open/Close
select round(a.[Open]-b.[Open],2) O1, round(a.High-b.High,2) H1, round(b.Low-a.Low,2) L1, round(b.[Close]-a.[Close],2) C1, b.Volume/a.Volume V1,
a.*, b.[Open], b.High, b.Low, b.[Close], b.Volume
from (select * from DayEoddata WHERE volume<>0) a
inner join FileLogMinuteYahoo b on a.Symbol=b.Symbol and a.Date=b.Date
inner join vSymbolsAndDatesLive c on a.Symbol=c.Symbol and a.Exchange=c.Exchange and a.Date=c.Date
where a.Date>='2023-02-06' and
(abs((a.[Open]-b.[Open])/a.[Open])>0.001 or abs((a.[Close]-b.[Close])/a.[Close])>0.001);

select round(a.[Open]-b.[Open],2) O1, round(a.High-b.High,2) H1, round(b.Low-a.Low,2) L1, round(b.[Close]-a.[Close],2) C1, b.Volume/a.Volume V1,
a.*, b.[Open], b.High, b.Low, b.[Close], b.Volume
from (select * from DayEoddata WHERE volume<>0) a
inner join FileLogMinuteAlphaVantage b on a.Symbol=b.Symbol and a.Date=b.Date
inner join vSymbolsAndDatesLive c on a.Symbol=c.Symbol and a.Exchange=c.Exchange and a.Date=c.Date
where a.Date>='2023-02-06' and b.[File] like 'MinuteAlphaVantage_20230211\%' and
(abs((a.[Open]-b.[Open])/a.[Open])>0.001 or abs((a.[Close]-b.[Close])/a.[Close])>0.001);

-- Volume
select b.Volume/a.Volume, a.*, b.[Open], b.High, b.Low, b.[Close], b.Volume
from DayEoddata a
inner join FileLogMinuteYahoo b on a.Symbol=b.Symbol and a.Date=b.Date
inner join vSymbolsAndDatesLive c on a.Symbol=c.Symbol and a.Exchange=c.Exchange and a.Date=c.Date
order by b.Volume/a.Volume;

select b.VolumeFull/a.Volume, a.*, b.[Open], b.High, b.Low, b.[Close], b.Volume
from (select * from DayEoddata WHERE volume<>0) a
inner join FileLogMinuteAlphaVantage b on a.Symbol=b.Symbol and a.Date=b.Date
inner join vSymbolsAndDatesLive c on a.Symbol=c.Symbol and a.Exchange=c.Exchange and a.Date=c.Date
where a.Date>='2023-02-06' and b.[File] like 'MinuteAlphaVantage_20230211\%'
order by 1;
