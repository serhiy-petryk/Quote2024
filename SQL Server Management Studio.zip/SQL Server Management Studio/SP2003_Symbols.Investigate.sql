-- select count(*) from SymbolsPolygon -- 180390
-- select * from SymbolsPolygon where symbol=name -- 433
select * from SymbolsPolygon where symbol in ('AAN', 'ADY', 'AG', 'AGI') order by symbol

select * from SymbolsPolygon where symbol in ('M')

select * from SymbolsPolygon a 
left join TradingDays b on a.[To]=b.Date
where b.Date is null and a.[To] is not null



-- update SymbolsPolygon SET name=replace(name,'''''', '''') where name like '%''''%';
--exec pRefreshTradingDays
select * from TradingDays

select b.[Type], b.[To], * from dbPolygon2003..SymbolsPolygon a
inner join dbPolygon2003..SymbolsPolygon b on a.Symbol=b.Symbol and a.Date<>b.Date and a.[Date] between dateadd(day, 1, b.[To]) and dateadd(day, 7, b.[To])

where a.Exchange=b.Exchange and a.Name=b.Name and isnull(a.Type,'')<>isnull(b.Type,'')
and isnull(a.CIK,'')=isnull(b.CIK,'') and isnull(a.Figi,'')=isnull(b.Figi,'')
and isnull(a.ClassFigi,'')=isnull(b.ClassFigi,'')
and a.Symbol='AAN'

select b.Prev2, * from dbPolygon2003..SymbolsPolygon a
inner join TradingDays b on a.Date=b.Date
inner join dbPolygon2003..SymbolsPolygon c on a.Symbol=c.Symbol and b.Prev1 between c.Date and c.[To]
-- where a.symbol='M'
where a.Exchange=c.Exchange and (a.Name=c.Name or a.Name+'.'=c.Name or a.Name=c.Name+'.') and isnull(a.Type,'')=isnull(c.Type,'')
and isnull(a.CIK,'')=isnull(c.CIK,'') and isnull(a.Figi,'')=isnull(c.Figi,'')
and isnull(a.ClassFigi,'')=isnull(c.ClassFigi,'')
and a.Symbol='M'

select * from SymbolsPolygon where symbol in ('M')

-- exec [pUpdateSymbolsPolygon]
select * from TradingDays

-- =====================
select c.Date, * from dbPolygon2003..SymbolsPolygon a
inner join TradingDays b on a.Date=b.Date
inner join dbPolygon2003..SymbolsPolygon c on a.Symbol=c.Symbol and b.Prev2 = c.[To]
left join dbPolygon2003..SymbolsPolygon d on a.Symbol=d.Symbol and b.Prev1 = d.[To]
where a.Exchange=c.Exchange and (a.Name=c.Name or a.Name+'.'=c.Name or a.Name=c.Name+'.') and isnull(a.Type,'')=isnull(c.Type,'')
and isnull(a.CIK,'')=isnull(c.CIK,'') and isnull(a.Figi,'')=isnull(c.Figi,'')
and isnull(a.ClassFigi,'')=isnull(c.ClassFigi,'')
and d.Symbol is null
and a.Symbol='ADBE' order by 3

-- ========================
UPDATE SymbolsPolygon set [To]='2099-12-31' where [To] is null
-- 1 day ==============
truncate table temp_symbolsPolygon;
INSERT into Temp_SymbolsPolygon (Symbol, Date, NewTo)
--select a.Symbol, a.Date, c.[To]
--select c.[Date], b.Next1, a.*, c.*
select b.Next1, a.*
from dbPolygon2003..SymbolsPolygon a
inner join dbPolygon2003..TradingDays b on a.Date=b.Date
where a.Symbol='ORLY' and a.Date='2020-09-09' order by 3
--inner join dbPolygon2003..SymbolsPolygon c on a.Symbol=c.Symbol and b.Next1 = c.[Date]
--where a.Exchange=c.Exchange and (a.Name=c.Name or a.Name+'.'=c.Name or a.Name=c.Name+'.') and isnull(a.Type,'')=isnull(c.Type,'')
--and isnull(a.CIK,'')=isnull(c.CIK,'') and isnull(a.Figi,'')=isnull(c.Figi,'')
--and isnull(a.ClassFigi,'')=isnull(c.ClassFigi,'')
and a.Symbol='ORLY' and a.Date='2020-09-09' order by 3


select a.Symbol, count(*), min(a.Date), max(a.Date)
from dbPolygon2003..SymbolsPolygon a
inner join TradingDays b on a.Date=b.Date
inner join dbPolygon2003..SymbolsPolygon c on a.Symbol=c.Symbol and b.Prev1 = c.[To]
where a.Exchange=c.Exchange and (a.Name=c.Name or a.Name+'.'=c.Name or a.Name=c.Name+'.') and isnull(a.Type,'')=isnull(c.Type,'')
and isnull(a.CIK,'')=isnull(c.CIK,'') and isnull(a.Figi,'')=isnull(c.Figi,'')
and isnull(a.ClassFigi,'')=isnull(c.ClassFigi,'')
group by a.Symbol order by 2 desc

if exists (select * from Temp_SymbolsPolygon a
inner join Temp_SymbolsPolygon b on a.Symbol=b.Symbol and a.NewDate=b.Date)
begin
UPDATE a SET a.NewDate=b.NewDate
from Temp_SymbolsPolygon a
inner join Temp_SymbolsPolygon b on a.Symbol=b.Symbol and a.NewDate=b.Date
end

select * from Temp_SymbolsPolygon a
inner join Temp_SymbolsPolygon b on a.Symbol=b.Symbol and a.NewDate=b.Date

-- 2 days ==============
truncate table temp_symbolsPolygon;
INSERT into Temp_SymbolsPolygon (Symbol, Date, NewDate)
select a.Symbol, a.Date, c.Date as NewDate 
from dbPolygon2003..SymbolsPolygon a
inner join TradingDays b on a.Date=b.Date
inner join dbPolygon2003..SymbolsPolygon c on a.Symbol=c.Symbol and b.Prev2 = c.[To]
left join dbPolygon2003..SymbolsPolygon d on a.Symbol=d.Symbol and b.Prev1 = d.[To]
where a.Exchange=c.Exchange and (a.Name=c.Name or a.Name+'.'=c.Name or a.Name=c.Name+'.') and isnull(a.Type,'')=isnull(c.Type,'')
and isnull(a.CIK,'')=isnull(c.CIK,'') and isnull(a.Figi,'')=isnull(c.Figi,'')
and isnull(a.ClassFigi,'')=isnull(c.ClassFigi,'')
and d.Symbol is null
and a.Symbol='ADBE' order by 3

if exists (select * from Temp_SymbolsPolygon a
inner join Temp_SymbolsPolygon b on a.Symbol=b.Symbol and a.NewDate=b.Date)
begin
UPDATE a SET a.NewDate=b.NewDate
from Temp_SymbolsPolygon a
inner join Temp_SymbolsPolygon b on a.Symbol=b.Symbol and a.NewDate=b.Date
end

select * from Temp_SymbolsPolygon a
inner join Temp_SymbolsPolygon b on a.Symbol=b.Symbol and a.NewDate=b.Date

