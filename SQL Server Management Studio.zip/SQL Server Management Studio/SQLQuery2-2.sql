-- truncate table DayEoddataExtended3;

/*INSERT INTO DayEoddataExtended2 (Exchange, Symbol, Date, [Open], High, Low, CL, VLM,
DJI_ToAvg, DJI_ToWAvg, GSPC_ToAvg, GSPC_ToWAvg)
SELECT a.Exchange, a.Symbol, a.Date, a.[Open], a.High, a.Low, a.[Close], a.Volume,
b.DJI/b.DJI_Avg DJI_ToAvg, b.DJI/b.DJI_WAvg DJI_ToWAvg, b.GSPC/b.GSPC_Avg GSPC_ToAvg, b.GSPC/b.GSPC_WAvg GSPC_ToWAvg
from DayEoddata a
inner join TradingDays b on b.Date=a.Date

-- 
--truncate table TradingDays2
--insert into TradingDays2 select * from TradingDays where date>='2009-12-01'

-- 24/31 sec: tradDays2
-- 36 sec: tradDays*/

INSERT INTO DayEoddataExtended3 (Exchange, Symbol, Date, [Open], High, Low, CL, VLM,
Open_N1, High_N1, Low_N1, CL_N1, VLM_N1,
DJI_ToAvg, DJI_ToWAvg, GSPC_ToAvg, GSPC_ToWAvg)
SELECT a.Exchange, a.Symbol, a.Date, a.[Open], a.High, a.Low, a.[Close], a.Volume,
n1.[Open], n1.High, n1.Low, n1.[Close], n1.Volume,
b.DJI/b.DJI_Avg DJI_ToAvg, b.DJI/b.DJI_WAvg DJI_ToWAvg, b.GSPC/b.GSPC_Avg GSPC_ToAvg, b.GSPC/b.GSPC_WAvg GSPC_ToWAvg
from DayEoddata a
inner join TradingDays2 b on b.Date=a.Date
inner join DayEoddata n1 on n1.Symbol=a.Symbol and n1.Date=b.Next1
-- 2:53
UPDATE a SET Open_N2=n2.[Open], High_N2=n2.High, Low_N2=n2.Low, CL_N2=n2.[Close], VLM_N2=n2.Volume
FROM DayEoddataExtended3 a inner join TradingDays2 d on d.Date=a.Date
inner join DayEoddata n2 on n2.Symbol=a.Symbol and n2.Date=d.Next2
-- 0:26
UPDATE a SET Open_N2=n2.[Open], High_N2=n2.High, Low_N2=n2.Low, CL_N2=n2.[Close], VLM_N2=n2.Volume,
Open_N3=n3.[Open], High_N3=n3.High, Low_N3=n3.Low, CL_N3=n3.[Close], VLM_N3=n3.Volume,
Open_N4=n4.[Open], High_N4=n4.High, Low_N4=n4.Low, CL_N4=n4.[Close], VLM_N4=n4.Volume,
Open_N5=n5.[Open], High_N5=n5.High, Low_N5=n5.Low, CL_N5=n5.[Close], VLM_N5=n5.Volume
FROM DayEoddataExtended3 a inner join TradingDays2 d on d.Date=a.Date
left join DayEoddata n2 on n2.Symbol=a.Symbol and n2.Date=d.Next2
left join DayEoddata n3 on n3.Symbol=a.Symbol and n3.Date=d.Next3
left join DayEoddata n4 on n4.Symbol=a.Symbol and n4.Date=d.Next4
left join DayEoddata n5 on n5.Symbol=a.Symbol and n5.Date=d.Next5
-- 1:18/0:52
UPDATE a SET Open_N2=n2.[Open], High_N2=n2.High, Low_N2=n2.Low, CL_N2=n2.[Close], VLM_N2=n2.Volume,
Open_N3=n3.[Open], High_N3=n3.High, Low_N3=n3.Low, CL_N3=n3.[Close], VLM_N3=n3.Volume,
Open_N4=n4.[Open], High_N4=n4.High, Low_N4=n4.Low, CL_N4=n4.[Close], VLM_N4=n4.Volume,
Open_N5=n5.[Open], High_N5=n5.High, Low_N5=n5.Low, CL_N5=n5.[Close], VLM_N5=n5.Volume,
Open_P1=p1.[Open], High_P1=p1.High, Low_P1=p1.Low, CL_P1=p1.[Close], VLM_P1=p1.Volume,
Open_P2=p2.[Open], High_P2=p2.High, Low_P2=p2.Low, CL_P2=p2.[Close], VLM_P2=p2.Volume,
Open_P3=p3.[Open], High_P3=p3.High, Low_P3=p3.Low, CL_P3=p3.[Close], VLM_P3=p3.Volume,
Open_P4=p4.[Open], High_P4=p4.High, Low_P4=p4.Low, CL_P4=p4.[Close], VLM_P4=p4.Volume,
Open_P5=p5.[Open], High_P5=p5.High, Low_P5=p5.Low, CL_P5=p5.[Close], VLM_P5=p5.Volume,
Open_P6=p6.[Open], High_P6=p6.High, Low_P6=p6.Low, CL_P6=p6.[Close], VLM_P6=p6.Volume,
Open_P7=p7.[Open], High_P7=p7.High, Low_P7=p7.Low, CL_P7=p7.[Close], VLM_P7=p7.Volume
FROM DayEoddataExtended3 a inner join TradingDays2 d on d.Date=a.Date
left join DayEoddata n2 on n2.Symbol=a.Symbol and n2.Date=d.Next2
left join DayEoddata n3 on n3.Symbol=a.Symbol and n3.Date=d.Next3
left join DayEoddata n4 on n4.Symbol=a.Symbol and n4.Date=d.Next4
left join DayEoddata n5 on n5.Symbol=a.Symbol and n5.Date=d.Next5
left join DayEoddata p1 on p1.Symbol=a.Symbol and p1.Date=d.Prev1
left join DayEoddata p2 on p2.Symbol=a.Symbol and p2.Date=d.Prev2
left join DayEoddata p3 on p3.Symbol=a.Symbol and p3.Date=d.Prev3
left join DayEoddata p4 on p4.Symbol=a.Symbol and p4.Date=d.Prev4
left join DayEoddata p5 on p5.Symbol=a.Symbol and p5.Date=d.Prev5
left join DayEoddata p6 on p6.Symbol=a.Symbol and p6.Date=d.Prev6
left join DayEoddata p7 on p7.Symbol=a.Symbol and p7.Date=d.Prev7
-- 
UPDATE a SET Split_N1=s1.Ratio, Split_N2=s2.Ratio, Split_N3=s3.Ratio, Split_N4=s4.Ratio, Split_N5=s5.Ratio
FROM DayEoddataExtended3 a
inner join TradingDays2 d on d.Date=a.Date
left join Splits s1 on s1.Symbol=a.Symbol and s1.Date=d.Next1
left join Splits s2 on s2.Symbol=a.Symbol and s2.Date=d.Next2
left join Splits s3 on s3.Symbol=a.Symbol and s3.Date=d.Next3
left join Splits s4 on s4.Symbol=a.Symbol and s4.Date=d.Next4
left join Splits s5 on s5.Symbol=a.Symbol and s5.Date=d.Next5
-- 0:17

UPDATE a SET Open_N2=n2.[Open], High_N2=n2.High, Low_N2=n2.Low, CL_N2=n2.[Close], VLM_N2=n2.Volume,
Open_N3=n3.[Open], High_N3=n3.High, Low_N3=n3.Low, CL_N3=n3.[Close], VLM_N3=n3.Volume,
Open_N4=n4.[Open], High_N4=n4.High, Low_N4=n4.Low, CL_N4=n4.[Close], VLM_N4=n4.Volume,
Open_N5=n5.[Open], High_N5=n5.High, Low_N5=n5.Low, CL_N5=n5.[Close], VLM_N5=n5.Volume
FROM DayEoddataExtended3 a inner join TradingDays2 d on d.Date=a.Date
left join DayEoddata p1 on p1.Symbol=a.Symbol and p1.Date=d.Prev1
left join DayEoddata p2 on p2.Symbol=a.Symbol and p2.Date=d.Prev2
left join DayEoddata p3 on p3.Symbol=a.Symbol and p3.Date=d.Prev3
left join DayEoddata p4 on p4.Symbol=a.Symbol and p4.Date=d.Prev4
left join DayEoddata p5 on p5.Symbol=a.Symbol and p5.Date=d.Prev5
left join DayEoddata p6 on p6.Symbol=a.Symbol and p6.Date=d.Prev6
left join DayEoddata p7 on p7.Symbol=a.Symbol and p7.Date=d.Prev7


UPDATE a SET Split_Prev=1
FROM DayEoddataExtended2 a
inner join TradingDays2 d on d.Date=a.Date
left join Splits s1 on s1.Symbol=a.Symbol and s1.Date=d.Prev1
left join Splits s2 on s2.Symbol=a.Symbol and s2.Date=d.Prev2
left join Splits s3 on s3.Symbol=a.Symbol and s3.Date=d.Prev3
left join Splits s4 on s4.Symbol=a.Symbol and s4.Date=d.Prev4
left join Splits s5 on s5.Symbol=a.Symbol and s5.Date=d.Prev5
left join Splits s6 on s6.Symbol=a.Symbol and s6.Date=d.Prev6
left join Splits s7 on s7.Symbol=a.Symbol and s7.Date=d.Prev7
WHERE s1.Symbol IS NOT NULL OR s2.Symbol IS NOT NULL OR
s3.Symbol IS NOT NULL OR s4.Symbol IS NOT NULL OR
s5.Symbol IS NOT NULL OR s6.Symbol IS NOT NULL OR
s7.Symbol IS NOT NULL;
-- 8 secs
UPDATE a SET Open_P1=p1.[Open], High_P1=p1.High, Low_P1=p1.Low, CL_P1=p1.[Close], VLM_P1=p1.Volume
FROM DayEoddataExtended2 a inner join TradingDays2 d on d.Date=a.Date
inner join DayEoddata p1 on p1.Symbol=a.Symbol and p1.Date=d.Prev1
-- 37 secs


UPDATE a SET 
AvgCL = (p1.[Close]+p2.[Close]+p3.[Close]+p4.[Close]+p5.[Close]+p6.[Close]+p7.[Close])/7.0,
WAvgCL = (p1.[Close]*7.0+p2.[Close]*6.0+p3.[Close]*5.0+p4.[Close]*4.0+p5.[Close]*3.0+p6.[Close]*2.0+p7.[Close])/28.0,
AvgVLM = (p1.[Volume]+p2.[Volume]+p3.[Volume]+p4.[Volume]+p5.[Volume]+p6.[Volume]+p7.[Volume])/7.0,
WAvgVLM = (p1.[Volume]*7.0+p2.[Volume]*6.0+p3.[Volume]*5.0+p4.[Volume]*4.0+p5.[Volume]*3.0+p6.[Volume]*2.0+p7.[Volume])/28.0,
AvgVolatility = ((p1.High-p1.Low)/p1.[Close]+(p2.High-p2.Low)/p2.[Close]+(p3.High-p3.Low)/p3.[Close]+(p4.High-p4.Low)/p4.[Close]+
(p5.High-p5.Low)/p5.[Close]+(p6.High-p6.Low)/p6.[Close]+(p7.High-p7.Low)/p7.[Close])/7.0*100.0,
WAvgVolatility = ((p1.High-p1.Low)/p1.[Close]*7.0+(p2.High-p2.Low)/p2.[Close]*6.0+(p3.High-p3.Low)/p3.[Close]*5.0+(p4.High-p4.Low)/p4.[Close]*4.0+
(p5.High-p5.Low)/p5.[Close]*3.0+(p6.High-p6.Low)/p6.[Close]*2.0+(p7.High-p7.Low)/p7.[Close])/28.0*100.0,

AvgVolatility2 = (dbo.fVolat(p1.[Open], p1.High, p1.Low, p1.[Close]) + dbo.fVolat(p2.[Open], p2.High, p2.Low, p2.[Close])+
dbo.fVolat(p3.[Open], p3.High, p3.Low, p3.[Close]) + dbo.fVolat(p4.[Open], p4.High, p4.Low, p4.[Close])+
dbo.fVolat(p5.[Open], p5.High, p5.Low, p5.[Close]) + dbo.fVolat(p6.[Open], p6.High, p6.Low, p6.[Close])+
dbo.fVolat(p7.[Open], p7.High, p7.Low, p7.[Close]))/7.0*100.0,

WAvgVolatility2 = (dbo.fVolat(p1.[Open], p1.High, p1.Low, p1.[Close])*7 + dbo.fVolat(p2.[Open], p2.High, p2.Low, p2.[Close])*6 +
dbo.fVolat(p3.[Open], p3.High, p3.Low, p3.[Close])*5 + dbo.fVolat(p4.[Open], p4.High, p4.Low, p4.[Close])*4 +
dbo.fVolat(p5.[Open], p5.High, p5.Low, p5.[Close])*3 + dbo.fVolat(p6.[Open], p6.High, p6.Low, p6.[Close])*2 +
dbo.fVolat(p7.[Open], p7.High, p7.Low, p7.[Close]))/28.0*100.0,

[MaxPVLM] = (SELECT Max(v) FROM (VALUES (p1.Volume),(p2.Volume),(p3.Volume),(p4.Volume),(p5.Volume),(p6.Volume),(p7.Volume)) AS value(v)),
[MinPVLM] = (SELECT Min(v) FROM (VALUES (p1.Volume),(p2.Volume),(p3.Volume),(p4.Volume),(p5.Volume),(p6.Volume),(p7.Volume)) AS value(v)),
[MaxPHigh] = (SELECT Max(v) FROM (VALUES (p1.High),(p2.High),(p3.High),(p4.High),(p5.High),(p6.High),(p7.High)) AS value(v)),
[MinPLow] = (SELECT Min(v) FROM (VALUES (p1.Low),(p2.Low),(p3.Low),(p4.Low),(p5.Low),(p6.Low),(p7.Low)) AS value(v))

FROM DayEoddataExtended2 a inner join TradingDays2 d on d.Date=a.Date
INNER JOIN DayEoddata p1 on p1.Symbol=a.Symbol and p1.Date=d.Prev1
INNER JOIN DayEoddata p2 on p2.Symbol=a.Symbol and p2.Date=d.Prev2
INNER JOIN DayEoddata p3 on p3.Symbol=a.Symbol and p3.Date=d.Prev3
INNER JOIN DayEoddata p4 on p4.Symbol=a.Symbol and p4.Date=d.Prev4
INNER JOIN DayEoddata p5 on p5.Symbol=a.Symbol and p5.Date=d.Prev5
INNER JOIN DayEoddata p6 on p6.Symbol=a.Symbol and p6.Date=d.Prev6
INNER JOIN DayEoddata p7 on p7.Symbol=a.Symbol and p7.Date=d.Prev7
-- 02:03/03:15















select a.Exchange, a.Symbol, a.Date, a.[Open], a.High, a.Low, a.[Close], a.Volume,
d.DJI/d.DJI_Avg DJI_ToAvg, d.DJI/d.DJI_WAvg DJI_ToWAvg, d.GSPC/d.GSPC_Avg GSPC_ToAvg, d.GSPC/d.GSPC_WAvg GSPC_ToWAvg,
(p1.[Close]+p2.[Close]+p3.[Close]+p4.[Close]+p5.[Close]+p6.[Close]+p7.[Close])/7.0 as AvgCL,
(p1.[Close]*7.0+p2.[Close]*6.0+p3.[Close]*5.0+p4.[Close]*4.0+p5.[Close]*3.0+p6.[Close]*2.0+p7.[Close])/28.0 as WAvgCL,
(p1.[Volume]+p2.[Volume]+p3.[Volume]+p4.[Volume]+p5.[Volume]+p6.[Volume]+p7.[Volume])/7.0 as AvgVLM,
(p1.[Volume]*7.0+p2.[Volume]*6.0+p3.[Volume]*5.0+p4.[Volume]*4.0+p5.[Volume]*3.0+p6.[Volume]*2.0+p7.[Volume])/28.0 as WAvgVLM,
((p1.High-p1.Low)/p1.[Close]+(p2.High-p2.Low)/p2.[Close]+(p3.High-p3.Low)/p3.[Close]+(p4.High-p4.Low)/p4.[Close]+
(p5.High-p5.Low)/p5.[Close]+(p6.High-p6.Low)/p6.[Close]+(p7.High-p7.Low)/p7.[Close])/7.0*100.0 as AvgVolatility,
((p1.High-p1.Low)/p1.[Close]*7.0+(p2.High-p2.Low)/p2.[Close]*6.0+(p3.High-p3.Low)/p3.[Close]*5.0+(p4.High-p4.Low)/p4.[Close]*4.0+
(p5.High-p5.Low)/p5.[Close]*3.0+(p6.High-p6.Low)/p6.[Close]*2.0+(p7.High-p7.Low)/p7.[Close])/28.0*100.0 as WAvgVolatility,

(dbo.fVolat(p1.[Open], p1.High, p1.Low, p1.[Close]) + dbo.fVolat(p2.[Open], p2.High, p2.Low, p2.[Close])+
dbo.fVolat(p3.[Open], p3.High, p3.Low, p3.[Close]) + dbo.fVolat(p4.[Open], p4.High, p4.Low, p4.[Close])+
dbo.fVolat(p5.[Open], p5.High, p5.Low, p5.[Close]) + dbo.fVolat(p6.[Open], p6.High, p6.Low, p6.[Close])+
dbo.fVolat(p7.[Open], p7.High, p7.Low, p7.[Close]))/7.0*100.0 as AvgVolatility2,

(dbo.fVolat(p1.[Open], p1.High, p1.Low, p1.[Close])*7 + dbo.fVolat(p2.[Open], p2.High, p2.Low, p2.[Close])*6 +
dbo.fVolat(p3.[Open], p3.High, p3.Low, p3.[Close])*5 + dbo.fVolat(p4.[Open], p4.High, p4.Low, p4.[Close])*4 +
dbo.fVolat(p5.[Open], p5.High, p5.Low, p5.[Close])*3 + dbo.fVolat(p6.[Open], p6.High, p6.Low, p6.[Close])*2 +
dbo.fVolat(p7.[Open], p7.High, p7.Low, p7.[Close]))/28.0*100.0 as WAvgVolatility2,

(SELECT Max(v) FROM (VALUES (p1.Volume),(p2.Volume),(p3.Volume),(p4.Volume),(p5.Volume),(p6.Volume),(p7.Volume)) AS value(v)) as [MaxPVLM],
(SELECT Min(v) FROM (VALUES (p1.Volume),(p2.Volume),(p3.Volume),(p4.Volume),(p5.Volume),(p6.Volume),(p7.Volume)) AS value(v)) as [MinPVLM],
(SELECT Max(v) FROM (VALUES (p1.High),(p2.High),(p3.High),(p4.High),(p5.High),(p6.High),(p7.High)) AS value(v)) as [MaxPHigh],
(SELECT Min(v) FROM (VALUES (p1.Low),(p2.Low),(p3.Low),(p4.Low),(p5.Low),(p6.Low),(p7.Low)) AS value(v)) as [MinPLow],
p1.[Open] Open_P1, p1.High High_P1, p1.Low Low_P1, p1.[Close] CL_P1, p1.Volume VLM_P1
from DayEoddata a
inner join TradingDays d on d.Date=a.Date
inner join DayEoddata p1 on p1.Symbol=a.Symbol and p1.Date=d.Prev1
inner join DayEoddata p2 on p2.Symbol=a.Symbol and p2.Date=d.Prev2
inner join DayEoddata p3 on p3.Symbol=a.Symbol and p3.Date=d.Prev3
inner join DayEoddata p4 on p4.Symbol=a.Symbol and p4.Date=d.Prev4
inner join DayEoddata p5 on p5.Symbol=a.Symbol and p5.Date=d.Prev5
inner join DayEoddata p6 on p6.Symbol=a.Symbol and p6.Date=d.Prev6
inner join DayEoddata p7 on p7.Symbol=a.Symbol and p7.Date=d.Prev7
WHERE a.Volume>0 and p1.Volume>0 and p2.Volume>0 and p3.Volume>0 and p4.Volume>0 and p5.Volume>0 and p6.Volume>0 and p7.Volume>0



