select symbol, date, count(*)
from DayPolygon 
group by symbol, date
having count(*)<>1
order by 1,2

select *
from DayPolygon 
where symbol like '%-%' or  symbol like '%/%';

-- truncate table DayPolygon


select * from dbQuote2022..SymbolsEoddata where symbol like 'AACQ%'

select top 10000 * from dbQ2023..Daypolygon where symbol like 'AACQ%'
order by date, symbol;


select symbol, min(Date) MinDate, max(Date) MaxDate  from dbQ2023..Daypolygon where [Close]*Volume>5000000 group by symbol


-- total symbols: 17651/13401(>5000000)
