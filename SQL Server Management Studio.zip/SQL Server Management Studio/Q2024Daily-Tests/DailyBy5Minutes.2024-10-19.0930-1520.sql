-- see result in E:\Quote\Result-Q2024Daily-Tests\DailyBy5Minutes.2024-10-19.xlsx
;with data as
(
	select (a.[Open]-a.[Close])/a.[Open]*100 PrevOpenRate,
		(a.[Open]-a.[Close])/(a.[Open]+a.[Close])*200 PrevCOProfit,
		(a.[High]-a.[Low])/(a.High+a.Low)*200 PrevHL,
		a.* from dbQ2024..DayPolygon a 
	inner join dbQ2024..TradingDays b on a.Date=b.Prev1
	where a.IsTest is null and year(a.Date)/*>=2010 --*/ in (2022,2023)
		and b.IsShortened is null
		and a.Volume*a.[Close]>=50000000 and a.TradeCount>=10000 --and a.Low>=5.0
-- !!?? and a.[Close] between a.Low*1.05 and a.High*0.95  -- !!?? is worse
),
data2 as (
	select OpenIn, HighIn, LowIn, CloseIn,
		(OpenIn-CloseIn)/OpenIn*100 Profit, (OpenIn-CloseIn) ProfitValue,
		iif (HighIn-OpenIn<0.00999,OpenIn-CloseIn,-0.01)/OpenIn*100 Amt1,
		iif (HighIn-OpenIn<0.01999,OpenIn-CloseIn,-0.02)/OpenIn*100 Amt2,
		iif (HighIn-OpenIn<0.04999,OpenIn-CloseIn,-0.05)/OpenIn*100 Amt5,
		iif (HighIn-OpenIn<0.09999,OpenIn-CloseIn,-0.1)/OpenIn*100 Amt10,
		iif (HighIn-OpenIn<OpenIn*0.01,OpenIn-CloseIn,-OpenIn*0.01)/OpenIn*100 Perc1,
		iif (HighIn-OpenIn<OpenIn*0.02,OpenIn-CloseIn,-OpenIn*0.02)/OpenIn*100 Perc2,
		iif (HighIn-OpenIn<OpenIn*0.05,OpenIn-CloseIn,-OpenIn*0.05)/OpenIn*100 Perc5,
		iif (HighIn-OpenIn<OpenIn*0.1,OpenIn-CloseIn,-OpenIn*0.1)/OpenIn*100 Perc10,
		iif ((HighIn-OpenIn)<0.00999,1,0) Cnt1,
		iif (HighIn-OpenIn<0.01999,1,0) Cnt2,
		iif (HighIn-OpenIn<0.04999,1,0) Cnt5,
		iif (HighIn-OpenIn<0.0999,1,0) Cnt10,
		iif (HighIn-OpenIn<OpenIn*0.01,1,0) Cnt1P,
		iif (HighIn-OpenIn<OpenIn*0.02,1,0) Cnt2P,
		iif (HighIn-OpenIn<OpenIn*0.05,1,0) Cnt5P,
		iif (HighIn-OpenIn<OpenIn*0.1,1,0) Cnt10P,
	a.* from data a
	inner join (select * from 
		(select *, O0930 OpenIn, HG0930 HighIn, LG0930 LowIn, ISNULL(O1520, ISNULL(O1525, ISNULL(O1530, ISNULL(O1535, ISNULL(O1540, ISNULL(O1545, ISNULL(O1550, ISNULL(O1555, O1600)))))))) CloseIn
			from dbQ2024MinuteScanner..DailyBy5Minutes
			WHERE HG1025 is not null and O0930 is not null) x
	where OpenIn>=5.0 and CloseIn is not null) c on a.Symbol=c.Symbol and a.Date=c.PrevDate
-- 1,356	2298	35,11	783	0,282	0,27	0,239	0,145	0,209	0,308	0,37	0,454	2,7	3,7	6,2	9,5	12	21,9	48,6	71,9
--	and O0930>=C0930
--1,03	1732	30,38	-466	0,333	0,341	0,353	0,249	0,24	0,287	0,329	0,404	3,3	4,3	6,8	10	12,3	23	51,6	76,4
--	 and O0930>=O0935
-- 1,006	1725	30,41	-468	0,331	0,343	0,349	0,247	0,242	0,315	0,375	0,454	3,4	4,3	6,8	10,1	12,5	23,5	51,9	76,3
--	  and H0930>O0935
--	and (H0930-L0930)/(H0930+L0930)*200>5
-- 2,38	1313	41,83	853	0,383	0,402	0,35	0,192	0,332	0,447	0,503	0,704	2,4	3,4	5,6	8,1	9,8	17,1	38,3	60,8
		--and c.OpenIn between a.Low and a.High -- is worse
		--and (c.OpenIn <= a.Low or c.[Open]>=a.High) -- is worse
),
data3 as (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY Date ORDER BY PrevHL DESC), *
   FROM data2
)

--select RN, Symbol, Date, PrevHL, OpenIn, HighIn, LowIn, CloseIn,
--Amt1, Cnt1, Amt2, Cnt2, Amt5, Cnt5, Amt10, Cnt10,
--Perc1, Cnt1P, Perc2, Cnt2P, Perc5, Cnt5P, Perc10, Cnt10P
--from data3 WHERE RN<=5 and PrevHL>15 ORDER BY Date, RN;

select cast(ROUND(avg(Profit),3) as real) Profit, count(*) Recs, ROUND(avg(PrevHL),2) PrevHL,
	ROUND(sum(ProfitValue),0) ProfitValue,
	ROUND(avg(Amt1),3) Amt1,
	ROUND(avg(Amt2),3) Amt2,
	ROUND(avg(Amt5),3) Amt5,
	ROUND(avg(Amt10),3) Amt10,
	ROUND(avg(Perc1),3) Perc1,
	ROUND(avg(Perc2),3) Perc2,
	ROUND(avg(Perc5),3) Perc5,
	ROUND(avg(Perc10),3) Perc10,
	cast(ROUND(100.0*sum(Cnt1)/count(*),1) as real) Cnt1,
	cast(ROUND(100.0*sum(Cnt2)/count(*),1) as real) Cnt2,
	cast(ROUND(100.0*sum(Cnt5)/count(*),1) as real) Cnt5,
	cast(ROUND(100.0*sum(Cnt10)/count(*),1) as real) Cnt10,
	cast(ROUND(100.0*sum(Cnt1P)/count(*),1) as real) Cnt1P,
	cast(ROUND(100.0*sum(Cnt2P)/count(*),1) as real) Cnt2P,
	cast(ROUND(100.0*sum(Cnt5P)/count(*),1) as real) Cnt5P,
	cast(ROUND(100.0*sum(Cnt10P)/count(*),1) as real) Cnt10P
from data3 WHERE RN<=5 and PrevHL>15

/*select 'Total' Period,
	cast(ROUND(avg(Profit),3) as real) Profit, count(*) Recs, ROUND(avg(PrevHL),2) PrevHL,
	ROUND(sum(ProfitValue),0) ProfitValue,
	ROUND(avg(Amt1),3) Amt1,
	ROUND(avg(Amt2),3) Amt2,
	ROUND(avg(Amt5),3) Amt5,
	ROUND(avg(Amt10),3) Amt10,
	ROUND(avg(Perc1),3) Perc1,
	ROUND(avg(Perc2),3) Perc2,
	ROUND(avg(Perc5),3) Perc5,
	ROUND(avg(Perc10),3) Perc10,
	cast(ROUND(100.0*sum(Cnt1)/count(*),1) as real) Cnt1,
	cast(ROUND(100.0*sum(Cnt2)/count(*),1) as real) Cnt2,
	cast(ROUND(100.0*sum(Cnt5)/count(*),1) as real) Cnt5,
	cast(ROUND(100.0*sum(Cnt10)/count(*),1) as real) Cnt10,
	cast(ROUND(100.0*sum(Cnt1P)/count(*),1) as real) Cnt1P,
	cast(ROUND(100.0*sum(Cnt2P)/count(*),1) as real) Cnt2P,
	cast(ROUND(100.0*sum(Cnt5P)/count(*),1) as real) Cnt5P,
	cast(ROUND(100.0*sum(Cnt10P)/count(*),1) as real) Cnt10P
from data3 WHERE RN<=5 and PrevHL>15
UNION ALL
select format(date,'yyyy') Period,
	cast(ROUND(avg(Profit),3) as real) Profit, count(*) Recs, ROUND(avg(PrevHL),2) PrevHL,
	ROUND(sum(ProfitValue),0) ProfitValue,
	ROUND(avg(Amt1),3) Amt1,
	ROUND(avg(Amt2),3) Amt2,
	ROUND(avg(Amt5),3) Amt5,
	ROUND(avg(Amt10),3) Amt10,
	ROUND(avg(Perc1),3) Perc1,
	ROUND(avg(Perc2),3) Perc2,
	ROUND(avg(Perc5),3) Perc5,
	ROUND(avg(Perc10),3) Perc10,
	cast(ROUND(100.0*sum(Cnt1)/count(*),1) as real) Cnt1,
	cast(ROUND(100.0*sum(Cnt2)/count(*),1) as real) Cnt2,
	cast(ROUND(100.0*sum(Cnt5)/count(*),1) as real) Cnt5,
	cast(ROUND(100.0*sum(Cnt10)/count(*),1) as real) Cnt10,
	cast(ROUND(100.0*sum(Cnt1P)/count(*),1) as real) Cnt1P,
	cast(ROUND(100.0*sum(Cnt2P)/count(*),1) as real) Cnt2P,
	cast(ROUND(100.0*sum(Cnt5P)/count(*),1) as real) Cnt5P,
	cast(ROUND(100.0*sum(Cnt10P)/count(*),1) as real) Cnt10P
from data3 WHERE RN<=5 and PrevHL>10
group by format(date,'yyyy') order by 1 DESC*/

/*select format(date,'yyyy-MM') Period,
	cast(ROUND(avg(Profit),3) as real) Profit, count(*) Recs, ROUND(avg(PrevHL),2) PrevHL,
	ROUND(sum(ProfitValue),0) ProfitValue,
	ROUND(avg(Amt1),3) Amt1,
	ROUND(avg(Amt2),3) Amt2,
	ROUND(avg(Amt5),3) Amt5,
	ROUND(avg(Perc1),3) Perc1,
	ROUND(avg(Perc2),3) Perc2,
	ROUND(avg(Perc5),3) Perc5,
	cast(ROUND(100.0*sum(Cnt1)/count(*),1) as real) Cnt1,
	cast(ROUND(100.0*sum(Cnt2)/count(*),1) as real) Cnt2,
	cast(ROUND(100.0*sum(Cnt5)/count(*),1) as real) Cnt5,
	cast(ROUND(100.0*sum(Cnt1P)/count(*),1) as real) Cnt1P,
	cast(ROUND(100.0*sum(Cnt2P)/count(*),1) as real) Cnt2P,
	cast(ROUND(100.0*sum(Cnt5P)/count(*),1) as real) Cnt5P
from data3 WHERE RN<=5 and PrevHL>15
group by format(date,'yyyy-MM') order by 1*/

-- select iif(17.05-17.04<0.010001,1,0) A